/*
 * Kelime Yolculuğu – uygulama katmanı (ekranlar, girdi, animasyon, kayıt bağlama).
 * Oyun kuralları engine.js'tedir; bu dosya yalnızca arayüz ve akışı yönetir.
 */
(function () {
  'use strict';
  var E = window.CWEngine, T = window.CWi18n.t, I18N = window.CWi18n, ICON = window.CWIcon;
  var A = window.CWAudio, FX = window.CWFx, ART = window.CWArt, ST = window.CWStorage;
  var VERSION = '1.0.0';

  // ---------- Ekonomi ayarları ----------
  var ECON = {
    startCoins: 100, startHints: 2,
    hintCost: 50, brushCost: 150,
    levelBase: 5, perStar: 3, galleryBonus: 15, replayBonus: 2,
    jarSize: 10, jarReward: 15,
    dailyWordCoins: 40, rushPerLetter: 5,
    goldenReward: 8, challengeReward: 12, giftCoins: 20, giftHints: 1,
  };
  var LOOSE_LEVELS = 50; // ilk 50 bölümde kutuya uyan her geçerli kelime sayılır
  var UNLOCK = { daily: 5, rush: 15 };
  var TILE_COLORS = ['coral', 'teal', 'purple', 'yellow', 'pink', 'blue', 'green', 'orange'];

  // ---------- Yardımcılar ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function h(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function on(el, ev, fn, opt) { el.addEventListener(ev, fn, opt); return el; }

  // ---------- Kayıt ----------
  function defaultSave() {
    return {
      v: 1, lang: 'tr',
      settings: { sfx: true, music: true, vib: true, lowFx: false },
      coins: ECON.startCoins, hints: ECON.startHints,
      progress: { tr: { cur: 0, stars: {} }, en: { cur: 0, stars: {} } },
      session: null,
      stats: { words: 0, bonus: 0, levels: 0, long: 0, perfect: 0, daily: 0, rush: 0, rushBest: 0, maxLen: 0, shuffles: 0, hints: 0, coinsEarned: 0 },
      today: { key: '', tasks: [], metrics: {} },
      reward: { last: null, streak: 0 },
      dailyWord: { key: '', done: false, session: null, streak: 0, lastDone: null },
      ach: {}, jar: 0, tutorialDone: false, notified: {},
      week: { key: '', tasks: [], metrics: {} }, intros: {}, ads: {}, seenTier: 0,
    };
  }
  function migrate(s) {
    var d = defaultSave();
    if (!s || typeof s !== 'object') return d;
    // Eksik alanları varsayılanlarla tamamla (ileriye dönük uyumluluk)
    (function fill(dst, src) {
      for (var k in src) {
        if (!(k in dst)) dst[k] = src[k];
        else if (src[k] && typeof src[k] === 'object' && !Array.isArray(src[k]) && dst[k] && typeof dst[k] === 'object') fill(dst[k], src[k]);
      }
    })(s, d);
    return s;
  }
  var S = migrate(ST.load());
  var saveTimer = null;
  function save(now) {
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
    if (now) { ST.save(S); return; }
    saveTimer = setTimeout(function () { saveTimer = null; ST.save(S); }, 250);
  }

  // ---------- Dil ve bölümler ----------
  var dicts = {}, levelCache = {};
  var LANG_SWITCH = false; // Yalnızca Türkçe yayın; İngilizce hazır olunca true yapın
  function dict(lang) {
    if (!dicts[lang]) {
      var U = lang.toUpperCase();
      dicts[lang] = new E.Dictionary(window['CW_WORDS_' + U] || '', lang, window['CW_WORDS_' + U + '_EXCLUDE'] || '');
    }
    return dicts[lang];
  }
  function levels(lang) {
    if (levelCache[lang]) return levelCache[lang];
    var pre = window['CW_LEVELS_' + lang.toUpperCase()];
    if (pre) {
      levelCache[lang] = pre.map(function (c) {
        return { letters: E.chars(c[0]), targets: c[1].split(','), bonus: c[2] ? c[2].split(',') : [] };
      });
    } else {
      levelCache[lang] = E.generateLevels(dict(lang), 300, 'colorwords-' + lang + '-v1');
    }
    return levelCache[lang];
  }
  function prog() { return S.progress[S.lang] || (S.progress[S.lang] = { cur: 0, stars: {} }); }
  function totalStars() {
    var n = 0, st = prog().stars; for (var k in st) n += st[k]; return n;
  }
  function tierOf(i) { return i < 100 ? 0 : i < 250 ? 1 : i < 400 ? 2 : 3; }
  function tierName(t) { return T(['easy', 'medium', 'hard', 'expert'][t]); }
  function galleryPainted(g) {
    var st = prog().stars, n = 0;
    for (var i = g * ART.PER; i < (g + 1) * ART.PER; i++) if (st[i]) n++;
    return n;
  }
  function galleriesDone() {
    var total = Math.ceil(levels(S.lang).length / ART.PER), n = 0;
    for (var g = 0; g < total; g++) if (galleryPainted(g) >= ART.PER) n++;
    return n;
  }

  // ---------- Günlük durum ----------
  function rollDay() {
    var key = E.dayKey();
    if (S.today.key !== key) {
      S.today = { key: key, tasks: E.dailyTasks(key, prog().cur >= UNLOCK.rush).map(function (t) { t.claimed = false; return t; }), metrics: {} };
      save();
    }
    if (S.dailyWord.key !== key) { S.dailyWord.key = key; S.dailyWord.done = false; S.dailyWord.session = null; save(); }
    var wk = E.weekKey();
    if (S.week.key !== wk) {
      var p = prog();
      S.week = { key: wk, tasks: E.weeklyTasks(wk, { rush: p.cur >= UNLOCK.rush, daily: p.cur >= UNLOCK.daily, golden: p.cur >= E.MECHANICS.golden }).map(function (t) { t.claimed = false; return t; }), metrics: {} };
      save();
    }
  }
  function track(metric, n) {
    rollDay();
    S.today.metrics[metric] = (S.today.metrics[metric] || 0) + (n || 1);
    S.week.metrics[metric] = (S.week.metrics[metric] || 0) + (n || 1);
    updateBadges();
  }
  function taskProgress(t, weekly) { return Math.min(t.goal, (weekly ? S.week : S.today).metrics[t.metric] || 0); }
  function claimableTasks() {
    return S.today.tasks.filter(function (t) { return !t.claimed && taskProgress(t) >= t.goal; }).length +
      S.week.tasks.filter(function (t) { return !t.claimed && taskProgress(t, true) >= t.goal; }).length;
  }

  // ---------- Başarımlar ----------
  var ACH = [
    { id: 'w1', icon: 'feather', c: 'teal', goal: 1, m: function () { return S.stats.words; }, tr: ['İlk Fırça', 'İlk kelimeni bul'], en: ['First Stroke', 'Find your first word'] },
    { id: 'w100', icon: 'feather', c: 'blue', goal: 100, m: function () { return S.stats.words; }, tr: ['Kelime Avcısı', '100 kelime bul'], en: ['Word Hunter', 'Find 100 words'] },
    { id: 'w500', icon: 'feather', c: 'purple', goal: 500, m: function () { return S.stats.words; }, tr: ['Söz Ustası', '500 kelime bul'], en: ['Word Master', 'Find 500 words'] },
    { id: 'w2000', icon: 'crown', c: 'gold', goal: 2000, m: function () { return S.stats.words; }, tr: ['Yaşayan Sözlük', '2.000 kelime bul'], en: ['Living Dictionary', 'Find 2,000 words'] },
    { id: 'l10', icon: 'map', c: 'green', goal: 10, m: function () { return S.stats.levels; }, tr: ['Yola Çıkış', '10 bölüm tamamla'], en: ['On the Road', 'Complete 10 levels'] },
    { id: 'l50', icon: 'map', c: 'teal', goal: 50, m: function () { return S.stats.levels; }, tr: ['Gezgin', '50 bölüm tamamla'], en: ['Traveler', 'Complete 50 levels'] },
    { id: 'l150', icon: 'map', c: 'blue', goal: 150, m: function () { return S.stats.levels; }, tr: ['Kaşif', '150 bölüm tamamla'], en: ['Explorer', 'Complete 150 levels'] },
    { id: 'l300', icon: 'crown', c: 'purple', goal: 300, m: function () { return S.stats.levels; }, tr: ['Renk Efsanesi', '300 bölüm tamamla'], en: ['Color Legend', 'Complete 300 levels'] },
    { id: 'b25', icon: 'jar', c: 'yellow', goal: 25, m: function () { return S.stats.bonus; }, tr: ['Meraklı Göz', '25 bonus kelime bul'], en: ['Curious Eye', 'Find 25 bonus words'] },
    { id: 'b150', icon: 'jar', c: 'orange', goal: 150, m: function () { return S.stats.bonus; }, tr: ['Hazine Kavanozu', '150 bonus kelime bul'], en: ['Treasure Jar', 'Find 150 bonus words'] },
    { id: 'p10', icon: 'star', c: 'yellow', goal: 10, m: function () { return S.stats.perfect; }, tr: ['Yıldız Toplayıcı', '10 bölümü 3 yıldızla bitir'], en: ['Star Collector', '3-star 10 levels'] },
    { id: 'p50', icon: 'star', c: 'pink', goal: 50, m: function () { return S.stats.perfect; }, tr: ['Kusursuz', '50 bölümü 3 yıldızla bitir'], en: ['Flawless', '3-star 50 levels'] },
    { id: 'g1', icon: 'palette', c: 'pink', goal: 1, m: galleriesDone, tr: ['İlk Durak', 'İlk ili tamamla'], en: ['First Stop', 'Complete a province'] },
    { id: 'g5', icon: 'palette', c: 'purple', goal: 5, m: galleriesDone, tr: ['Gezgin', '5 ili tamamla'], en: ['Traveler', 'Complete 5 provinces'] },
    { id: 'd1', icon: 'calendar', c: 'coral', goal: 1, m: function () { return S.stats.daily; }, tr: ['Günün Kelimesi', 'Günlük kelimeyi çöz'], en: ['Word of the Day', 'Solve a daily word'] },
    { id: 'd7', icon: 'flame', c: 'orange', goal: 7, m: function () { return S.stats.daily; }, tr: ['Sadık Oyuncu', '7 günlük kelime çöz'], en: ['Loyal Player', 'Solve 7 daily words'] },
    { id: 'r1', icon: 'bolt', c: 'blue', goal: 1, m: function () { return S.stats.rush; }, tr: ['Hız Tutkunu', 'Renk Koşusu oyna'], en: ['Speed Fan', 'Play Color Rush'] },
    { id: 'r400', icon: 'bolt', c: 'red', goal: 400, m: function () { return S.stats.rushBest; }, tr: ['Şimşek', 'Renk Koşusunda 400 puan'], en: ['Lightning', 'Score 400 in Color Rush'] },
    { id: 's7', icon: 'gift', c: 'green', goal: 7, m: function () { return S.reward.streak; }, tr: ['Haftanın Yıldızı', '7 gün üst üste ödül al'], en: ['Star of the Week', 'Claim rewards 7 days in a row'] },
    { id: 'gold20', icon: 'star', c: 'gold', goal: 20, m: function () { return S.stats.golden || 0; }, tr: ['Altın Avcısı', '20 altın kelime bul'], en: ['Gold Hunter', 'Find 20 golden words'] },
    { id: 'ch15', icon: 'target', c: 'coral', goal: 15, m: function () { return S.stats.challenges || 0; }, tr: ['Görev Adamı', '15 bölüm görevini tamamla'], en: ['Goal Getter', 'Complete 15 level goals'] },
    { id: 'len7', icon: 'trophy', c: 'gold', goal: 7, m: function () { return S.stats.maxLen; }, tr: ['Uzun Soluklu', '7 harfli bir kelime bul'], en: ['Long Breath', 'Find a 7-letter word'] },
  ];
  var ACH_REWARD = 50;
  function checkAchievements() {
    ACH.forEach(function (a) {
      if (S.ach[a.id]) return;
      if (a.m() >= a.goal) {
        S.ach[a.id] = Date.now();
        S.coins += ACH_REWARD; S.stats.coinsEarned += ACH_REWARD;
        var txt = a[S.lang] || a.tr;
        toast(ICON(a.icon), T('achievementUnlocked'), txt[0] + ' · +' + ACH_REWARD + ' ' + T('coins'), a.c);
        A.play('reward');
      }
    });
    save(); refreshCoins();
  }

  // ---------- Geri bildirim ----------
  function vibrate(ms) {
    if (!S.settings.vib) return;
    var C = window.Capacitor, H = C && C.Plugins && C.Plugins.Haptics;
    try {
      if (H && C.isNativePlatform()) H.impact({ style: ms > 30 ? 'MEDIUM' : 'LIGHT' });
      else if (navigator.vibrate) navigator.vibrate(ms);
    } catch (e) {}
  }
  function toast(iconHtml, title, sub, color) {
    var el = h('<div class="toast"><div class="ti c-' + (color || 'purple') + '" style="background:var(--c)">' + iconHtml + '</div><div>' + esc(title) + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div></div>');
    $('#toastRoot').appendChild(el);
    setTimeout(function () { el.remove(); }, 3000);
  }
  function coinPill() { return '<button class="pill coin-pill" data-act="shop">' + ICON('coin') + '<span class="coin-val">' + fmt(S.coins) + '</span></button>'; }
  function refreshCoins(bump) {
    $$('.coin-val').forEach(function (e) { e.textContent = fmt(S.coins); });
    if (bump) $$('.coin-pill').forEach(function (e) { e.classList.remove('bump'); void e.offsetWidth; e.classList.add('bump'); });
  }
  function visibleCoinPill() {
    var cur = $('.screen.active .coin-pill');
    return cur;
  }
  function addCoins(n, fromEl) {
    S.coins += n; S.stats.coinsEarned += n; save();
    var target = visibleCoinPill();
    if (fromEl && target) {
      var a = fromEl.getBoundingClientRect(), b = target.getBoundingClientRect();
      FX.coinFly(a.left + a.width / 2, a.top + a.height / 2, b.left + 22, b.top + b.height / 2, Math.min(10, 3 + Math.floor(n / 15)), function (i) {
        if (i === 0) A.play('coin');
        refreshCoins(true);
      });
    } else refreshCoins(true);
  }

  // ---------- Bölüm geçişi: renkli boya perdesi ----------
  function transition(mid) {
    var low = S.settings.lowFx;
    var el = h('<div class="wipe' + (low ? ' low' : '') + '"></div>');
    document.body.appendChild(el);
    var dur = low ? 140 : 280;
    setTimeout(function () { try { mid(); } finally { el.classList.add('out'); setTimeout(function () { el.remove(); }, dur + 120); } }, dur);
  }

  // ---------- Pencere yönetimi ----------
  var modalStack = [];
  function modal(html, opts) {
    opts = opts || {};
    var m = h('<div class="modal"><div class="shade"></div><div class="mbox">' + (opts.closable !== false ? '<button class="ibtn x" data-close>' + ICON('close') + '</button>' : '') + html + '</div></div>');
    $('#modalRoot').appendChild(m);
    var api = {
      el: m, closable: opts.closable !== false,
      close: function () { if (!m.parentNode) return; m.remove(); modalStack.splice(modalStack.indexOf(api), 1); if (opts.onClose) opts.onClose(); },
    };
    modalStack.push(api);
    on(m, 'click', function (e) {
      var t = e.target.closest('[data-close]');
      if (t || (e.target.classList.contains('shade') && api.closable)) { A.play('button'); api.close(); }
    });
    return api;
  }
  function confirmBox(text, yes) {
    var m = modal('<h3>' + ICON('info') + '</h3><p>' + esc(text) + '</p><div class="actions"><button class="btn white sm" data-close>' + T('no') + '</button><button class="btn coral sm" data-yes>' + T('yes') + '</button></div>');
    on($('[data-yes]', m.el), 'click', function () { m.close(); yes(); });
  }
  function notEnoughCoins() {
    A.play('wrong');
    var m = modal('<div style="font-size:64px;color:var(--yellow)">' + ICON('coin') + '</div><h3>' + T('notEnough') + '</h3><p>' + T('getCoins') + '</p>' +
      '<div class="actions"><button class="btn purple sm" data-go="tasks">' + ICON('tasks') + T('tasks') + '</button><button class="btn yellow sm" data-go="rewards">' + ICON('gift') + T('rewards') + '</button></div>');
    $$('[data-go]', m.el).forEach(function (b) { on(b, 'click', function () { m.close(); Game.leave(); show(b.dataset.go); }); });
  }

  // ---------- Ekran yönlendirme ----------
  var current = null, history = [];
  var SCREENS = {};
  function show(name, params, opts) {
    if (!SCREENS[name]) return;
    if (current && current !== name && !(opts && opts.noHistory)) history.push(current);
    while (modalStack.length) modalStack[modalStack.length - 1].close();
    if (current && SCREENS[current].leave) SCREENS[current].leave();
    $$('.screen').forEach(function (s) { s.classList.remove('active'); });
    var el = $('#scr-' + name);
    current = name;
    document.body.classList.toggle('ingame', name === 'game');
    SCREENS[name].render(el, params || {});
    el.classList.add('active');
    updateBadges();
  }
  function back() {
    if (modalStack.length) { var m = modalStack[modalStack.length - 1]; if (m.closable) m.close(); return true; }
    if (current === 'game') { Game.leave(); show(Game.mode === 'level' ? 'map' : 'menu', {}, { noHistory: true }); history = ['menu']; return true; }
    if (current === 'menu' || current === 'splash') return false;
    var prev = history.pop() || 'menu';
    if (prev === 'game' || prev === 'splash') prev = 'menu';
    show(prev, {}, { noHistory: true });
    return true;
  }
  function updateBadges() {
    if (current !== 'menu') return;
    var t = $('#scr-menu [data-go="tasks"] .dot'), r = $('#scr-menu [data-go="rewards"] .dot');
    if (t) t.style.display = claimableTasks() ? '' : 'none';
    if (r) r.style.display = E.dailyRewardState(S.reward.last ? { lastRewardDay: S.reward.last, rewardStreak: S.reward.streak } : {}, E.dayKey()).canClaim ? '' : 'none';
  }
  // Ekranlardaki data-act / data-go düğmeleri için ortak işleyici
  on(document, 'click', function (e) {
    var b = e.target.closest('[data-go],[data-act]');
    if (!b || b.closest('.modal')) return;
    A.play('button');
    if (b.dataset.go) show(b.dataset.go);
    else if (b.dataset.act === 'back') back();
    else if (b.dataset.act === 'shop') { if (current !== 'game') show('shop'); }
  });
  function topbar(title, extra) {
    return '<div class="topbar"><button class="ibtn" data-act="back" aria-label="' + T('back') + '">' + ICON('back') + '</button><h2>' + esc(title) + '</h2>' + (extra || coinPill()) + '</div>';
  }

  // =========================================================
  // 1. Açılış ekranı
  // =========================================================
  function logoHtml(small) {
    var w1 = 'KELİME', w2 = 'YOLCULUĞU', cols = ['coral', 'yellow', 'teal', 'purple', 'pink'], cols2 = ['blue', 'green', 'orange', 'pink', 'purple'];
    function row(w, cs, d0) { return '<div class="logo-row">' + w.split('').map(function (c, i) { return '<div class="ltile c-' + cs[i % cs.length] + '" style="animation-delay:' + (d0 + i * 0.07) + 's">' + c + '</div>'; }).join('') + '</div>'; }
    return '<div class="logo' + (small ? ' small' : '') + '">' + row(w1, cols, 0) + row(w2, cols2, 0.35) + '</div>';
  }
  SCREENS.splash = {
    render: function (el) {
      // Açılış: tam görsel (başlık, slogan, yükleme çubuğu ve "Başlamak için dokun" görselin içinde).
      el.innerHTML = '<div class="splash-bg"></div><div class="splash-art" role="img" aria-label="' + T('tagline') + '"></div>';
      var hint = { style: {} };
      setTimeout(function () {
        dict(S.lang); levels(S.lang); // ön yükleme
        setTimeout(function () {
          hint.style.visibility = 'visible';
          var go = function () {
            el.removeEventListener('pointerup', go);
            A.unlock();
            if (!S.tutorialDone && prog().cur === 0) { history = ['menu']; Game.start({ mode: 'level', index: 0 }); }
            else show('menu', {}, { noHistory: true });
          };
          on(el, 'pointerup', go);
        }, 450);
      }, 500);
    },
  };

  // =========================================================
  // 2. Ana menü
  // =========================================================
  SCREENS.menu = {
    render: function (el) {
      rollDay();
      history = [];
      var p = prog(), total = levels(S.lang).length, cur = Math.min(p.cur, total - 1);
      var g = ART.gallery(cur), painted = galleryPainted(g);
      var dailyLocked = p.cur < UNLOCK.daily, rushLocked = p.cur < UNLOCK.rush;
      var allDone = p.cur >= total;
      var inf = ART.info(g);
      el.innerHTML = ART.bg(g, painted) +
        '<div class="menu-head">' + coinPill() + '<span class="pill star">' + ICON('star') + totalStars() + '</span><span class="grow"></span>' +
        '<button class="ibtn" data-go="settings" aria-label="' + T('settings') + '">' + ICON('gear') + '</button></div>' +
        '<div class="menu-body">' +
        '<div class="hero"><button class="hero-card" data-go="map" aria-label="' + T('map') + '">' +
        '<span class="hero-plate">' + (inf.plate ? (inf.plate < 10 ? '0' : '') + inf.plate : '★') + '</span>' +
        '<span class="hero-txt"><b class="hero-name">' + esc(inf.name) + '</b><small>' + esc(inf.place) + '</small></span>' +
        '<span class="hero-prog"><span class="bar hero-bar"><i style="width:' + (painted / ART.PER * 100) + '%"></i></span><small>' + painted + ' / ' + ART.PER + '</small></span></button></div>' +
        '<button class="btn play-btn block" id="playBtn">' + ICON('play') + '<span class="lbl">' + T('play') + '<small>' + (allDone ? T('map') : T('level') + ' ' + (cur + 1) + ' · ' + tierName(tierOf(cur))) + '</small></span></button>' +
        '<div class="modes">' +
        '<button class="mode c-coral' + (dailyLocked ? ' locked' : '') + '" id="mDaily">' + ICON('calendar', 'big') +
        (S.dailyWord.done && !dailyLocked ? '<span class="badge">' + ICON('check') + '</span>' : '') +
        '<b>' + T('daily') + '</b><span>' + (dailyLocked ? ICON('lock') + ' ' + T('unlockAt', { n: UNLOCK.daily }) : (S.dailyWord.done ? T('dailyDone') : T('dailyDesc'))) + '</span></button>' +
        '<button class="mode c-blue' + (rushLocked ? ' locked' : '') + '" id="mRush">' + ICON('bolt', 'big') +
        '<b>' + T('rush') + '</b><span>' + (rushLocked ? ICON('lock') + ' ' + T('unlockAt', { n: UNLOCK.rush }) : T('rushDesc') + (S.stats.rushBest ? ' · ' + T('best') + ': ' + S.stats.rushBest : '')) + '</span></button>' +
        '</div></div>' +
        '<div class="navbar">' +
        '<button class="nav c-teal" data-go="tasks">' + ICON('tasks') + T('tasks') + '<i class="dot"></i></button>' +
        '<button class="nav c-pink" data-go="rewards">' + ICON('gift') + T('rewards') + '<i class="dot"></i></button>' +
        '<button class="nav c-yellow" data-go="achievements">' + ICON('trophy') + T('achievements') + '</button>' +
        '<button class="nav c-purple" data-go="map">' + ICON('map') + T('map') + '</button>' +
        '</div>';
      on($('#playBtn', el), 'click', function () {
        A.play('button');
        if (allDone) show('map'); else Game.start({ mode: 'level', index: cur });
      });
      on($('#mDaily', el), 'click', function () {
        A.play('button');
        if (dailyLocked) { toast(ICON('lock'), T('locked'), T('unlockAt', { n: UNLOCK.daily }), 'gray'); return; }
        if (S.dailyWord.done) { modal('<div style="font-size:64px;color:var(--coral)">' + ICON('calendar') + '</div><h3>' + T('dailyDone') + '</h3><p>' + T('dailyCome') + '</p><div class="streak">' + ICON('flame') + T('streak', { n: S.dailyWord.streak }) + '</div><button class="btn block sm" data-close>' + T('ok') + '</button>'); return; }
        Game.start({ mode: 'daily' });
      });
      on($('#mRush', el), 'click', function () {
        A.play('button');
        if (rushLocked) { toast(ICON('lock'), T('locked'), T('unlockAt', { n: UNLOCK.rush }), 'gray'); return; }
        Game.start({ mode: 'rush' });
      });
    },
  };

  // =========================================================
  // 3. Bölüm haritası
  // =========================================================
  SCREENS.map = {
    render: function (el) {
      var list = levels(S.lang), p = prog(), total = list.length, nG = Math.ceil(total / ART.PER);
      var html = topbar(T('map')) + '<div class="scroll" id="mapScroll">';
      for (var g = 0; g < nG; g++) {
        var start = g * ART.PER, end = Math.min(total, start + ART.PER), painted = galleryPainted(g);
        var locked = start > p.cur;
        html += '<div class="map-gallery card" id="gal' + g + '"><div class="gal-head">' + ART.svg(g, painted, { lite: start > p.cur + ART.PER * 2 }) +
          '<div class="info"><div class="nm">' + esc(ART.name(g, S.lang)) + '<span class="tier t' + tierOf(start) + '">' + tierName(tierOf(start)) + '</span></div>' +
          '<div class="sub">' + T('level') + ' ' + (start + 1) + '–' + end + (locked ? ' · ' + ICON('lock') : '') + '</div>' +
          '<div class="bar pink"><i style="width:' + (painted / ART.PER * 100) + '%"></i></div></div></div>';
        var cols = 3, rows = Math.ceil((end - start) / cols), rowH = 72;
        var pts = [];
        var nodes = '';
        for (var i = start; i < end; i++) {
          var k = i - start, r = Math.floor(k / cols), c = k % cols;
          if (r % 2) c = cols - 1 - c;
          pts.push(((c + 0.5) / cols * 100).toFixed(2) + ',' + (18 + 27 + r * rowH));
          var st = p.stars[i] || 0, isCur = i === p.cur, isLocked = i > p.cur;
          var color = isLocked ? 'gray' : isCur ? 'coral' : (st >= 3 ? 'green' : 'teal');
          var stars = '';
          if (st) { stars = '<span class="stars">'; for (var s = 1; s <= 3; s++) stars += ICON('star', s <= st ? 'on' : ''); stars += '</span>'; }
          var isGift = (i + 1) >= E.MECHANICS.gift && (i + 1) % 10 === 0;
          nodes += '<button class="node c-' + color + (isCur ? ' cur' : '') + (isLocked ? ' locked' : '') + (isGift ? ' special' : '') + '" data-lv="' + i + '" style="grid-row:' + (r + 1) + ';grid-column:' + (c + 1) + '">' +
            (isLocked ? ICON('lock') : (i + 1)) + stars + (isGift && !st ? '<span class="sp">' + ICON('chest') + '</span>' : '') + '</button>';
        }
        var hgt = 18 + rows * rowH;
        html += '<div class="path" style="height:' + hgt + 'px;grid-template-rows:repeat(' + rows + ',54px)">' +
          '<svg class="trail" viewBox="0 0 100 ' + hgt + '" preserveAspectRatio="none"><polyline points="' + pts.join(' ') + '" fill="none" stroke="#fff" stroke-width="16" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" opacity=".9"/>' +
          '<polyline points="' + pts.join(' ') + '" fill="none" stroke="#D9E1EC" stroke-width="5" stroke-dasharray="2 12" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>' + nodes + '</div></div>';
      }
      html += '</div>';
      el.innerHTML = html;
      on($('#mapScroll', el), 'click', function (e) {
        var n = e.target.closest('.node'); if (!n) return;
        var i = +n.dataset.lv;
        if (i > prog().cur) { A.play('wrong'); n.animate([{ transform: 'translateX(-5px)' }, { transform: 'translateX(5px)' }, { transform: 'none' }], 220); return; }
        A.play('button'); Game.start({ mode: 'level', index: i });
      });
      // Mevcut bölüme kaydır
      requestAnimationFrame(function () {
        var c = $('.node.cur', el) || $$('.node', el).pop();
        var sc = $('#mapScroll', el);
        if (c && sc) sc.scrollTop = Math.max(0, c.offsetTop + c.closest('.map-gallery').offsetTop - sc.clientHeight / 2);
      });
    },
  };

  // =========================================================
  // 4. Oyun ekranı
  // =========================================================
  var Game = {
    mode: 'level', index: 0, level: null, sess: null, sel: [], tapMode: false, busy: false,
    order: [], rush: null, timer: null, el: null,

    start: function (opts) {
      rollDay();
      this.mode = opts.mode; this.index = opts.index || 0; this.sel = []; this.tapMode = false; this.busy = false;
      var d = dict(S.lang), saved = null;
      if (this.mode === 'level') {
        var base = levels(S.lang)[this.index];
        // Kopya: kutuya uyan kelime kuralı hedefleri bu oturumda değiştirebilir; önbellek bozulmasın.
        this.level = { letters: base.letters, targets: base.targets.slice(), bonus: base.bonus, loose: this.index < LOOSE_LEVELS };
        if (S.session && S.session.lang === S.lang && S.session.index === this.index) saved = S.session.data;
      } else if (this.mode === 'daily') {
        this.level = E.seededLevel(d, 'daily-' + S.lang + '-' + E.dayKey(), { lens: [7, 6], minT: 5, maxT: 7 });
        saved = S.dailyWord.session;
      } else {
        this.rush = { score: 0, words: 0, left: 90, seed: Date.now(), n: 0 };
        this.level = this.rushLevel();
      }
      this.sess = new E.LevelSession(this.level, d, saved);
      this.order = this.level.letters.map(function (_, i) { return i; });
      this.colors = this.level.targets.map(function (_, i) { return TILE_COLORS[(i * 3 + Game.index) % TILE_COLORS.length]; });
      this.feat = this.mode === 'level' ? E.levelFeatures(this.index, this.level) : { golden: -1, gift: false, challenge: null, chain: false };
      if (this.feat.golden >= 0) this.colors[this.feat.golden] = 'gold';
      this.chain = 0; this.lastFoundAt = 0;
      show('game', {}, {});
      if (this.mode === 'rush') this.startTimer();
      if (this.mode === 'level') this.introduce();
    },
    // Yeni mekanik ilk kez çıktığında kısa tanıtım
    introduce: function () {
      var n = this.index + 1, f = this.feat, list = [];
      if (f.golden >= 0 && !S.intros.golden) list.push(['golden', 'star', 'gold']);
      if (f.gift && !S.intros.gift) list.push(['gift', 'chest', 'pink']);
      if (f.challenge && !S.intros.challenge) list.push(['challenge', 'target', 'coral']);
      if (f.chain && !S.intros.chain) list.push(['chain', 'chain', 'teal']);
      var t = tierOf(this.index);
      if (t > (S.seenTier || 0)) { S.seenTier = t; save(); setTimeout(function () { toast(ICON('map'), T('tier_up', { t: tierName(t) }), '', ['green', 'blue', 'orange', 'purple'][t]); }, 600); }
      var self = this;
      (function next() {
        var it = list.shift(); if (!it) return;
        S.intros[it[0]] = 1; save();
        var m = modal('<div class="intro-ic c-' + it[2] + '">' + ICON(it[1]) + '</div><div class="kicker">' + T('newFeature') + '</div><h3>' + T(it[0]) + '</h3><p>' + T('intro_' + it[0]) + '</p><button class="btn block" data-close>' + T('gotIt') + '</button>', { onClose: function () { setTimeout(next, 150); } });
        A.play('reward');
      })();
    },
    rushLevel: function () {
      var r = this.rush; r.n++;
      return E.seededLevel(dict(S.lang), 'rush-' + r.seed + '-' + r.n, { lens: r.n < 3 ? [5] : [5, 6], minT: 3, maxT: 5 });
    },
    persist: function () {
      if (this.mode === 'level') S.session = { lang: S.lang, index: this.index, data: this.sess.serialize() };
      else if (this.mode === 'daily') S.dailyWord.session = this.sess.serialize();
      save();
    },
    leave: function () {
      this.stopTimer();
      if (this.sess && !this.sess.isComplete() && this.mode !== 'rush') this.persist();
      $$('.coach,.hand').forEach(function (e) { e.remove(); });
    },

    render: function (el) {
      this.el = el;
      var lv = this.level, self = this;
      var title, sub;
      if (this.mode === 'level') { title = T('level') + ' ' + (this.index + 1); sub = esc(ART.name(ART.gallery(this.index), S.lang)) + ' · ' + tierName(tierOf(this.index)); }
      else if (this.mode === 'daily') { title = T('daily'); sub = E.dayKey(); }
      else { title = T('rush'); sub = T('score') + ': <span id="rushScore">' + this.rush.score + '</span>'; }
      var right = this.mode === 'rush' ? '<span class="pill timer" id="rushTime">' + ICON('clock') + '<span>' + this.rush.left + '</span></span>' : coinPill();
      el.innerHTML =
        '<div class="game-top"><button class="ibtn" data-act="back" aria-label="' + T('back') + '">' + ICON('back') + '</button>' +
        '<div class="lvl-badge"><b>' + title + '</b><span>' + sub + '</span></div>' + right + '</div>' +
        '<div class="game-progress"><div class="bar"><i id="gBar"></i></div><span class="cnt" id="gCnt"></span></div>' +
        this.chipsHtml() +
        '<div class="board" id="board"></div>' +
        '<div class="preview-wrap" id="pvWrap"><div class="preview c-purple" id="preview"></div></div>' +
        '<div class="play-area">' +
        '<div class="side"><button class="tool c-teal" id="tShuffle" aria-label="' + T('shuffle') + '">' + ICON('shuffle') + '</button>' +
        '<button class="tool c-yellow jar" id="tJar" aria-label="' + T('bonusJar') + '"><span class="fill" id="jarFill"></span>' + ICON('jar') + '<span class="cnt" id="jarCnt"></span></button></div>' +
        '<div class="palette" id="palette"><svg class="line"><polyline id="line" points=""/></svg></div>' +
        '<div class="side"><button class="tool c-pink" id="tHint" aria-label="' + T('hint') + '">' + ICON('bulb') + '<span class="cnt" id="hintCnt"></span></button>' +
        '</div>' +
        '</div>';
      this.layout();
      this.renderBoard();
      this.renderLetters();
      this.updateTools();
      this.updateProgress();
      this.bindInput();
      on($('#tShuffle', el), 'click', function () { self.shuffle(); });
      on($('#tHint', el), 'click', function () { self.hint(); });
      on($('#tJar', el), 'click', function () {
        A.play('button');
        var found = self.sess.bonusFound;
        modal('<div style="font-size:60px;color:var(--yellow)">' + ICON('jar') + '</div><h3>' + T('bonusJar') + '</h3><p>' + T('bonusJarDesc', { n: S.jar, m: ECON.jarSize }) + '</p>' +
          '<div class="bar gold" style="margin:0 20px 12px"><i style="width:' + (S.jar / ECON.jarSize * 100) + '%"></i></div>' +
          (found.length ? '<p><b>' + found.map(esc).join(' · ') + '</b></p>' : '') + '<button class="btn yellow block sm" data-close>' + T('ok') + '</button>');
      });
      if (this.mode === 'rush') { $('#tHint', el).classList.add('off'); }
      if (this.mode === 'level' && this.index === 0 && !S.tutorialDone) setTimeout(function () { self.tutorial(); }, 500);
      this._onResize = function () { if (current === 'game') { self.layout(); self.renderBoard(); self.placeLetters(); } };
      window.addEventListener('resize', this._onResize);
    },
    leaveScreen: function () { window.removeEventListener('resize', this._onResize); },

    layout: function () {
      var el = this.el, W = Math.min(window.innerWidth, 560) - 24, H = window.innerHeight;
      var n = this.level.letters.length;
      var pd = clamp(Math.min(W - 2 * 62 - 8, H * 0.34), 180, 300);
      var pt = clamp(pd * (n <= 4 ? 0.3 : n <= 6 ? 0.27 : 0.235), 42, 74);
      el.style.setProperty('--pd', pd + 'px');
      el.style.setProperty('--pt', pt + 'px');
      this.pd = pd; this.pt = pt;
      // Tahta yüksekliği: kalan alan
      var reserved = 52 + 22 + 58 + pd + 26 + 22 + 10 + ($('.chips', el) ? 36 : 0);
      var bh = Math.max(120, H - reserved - 0);
      var rows = this.level.targets.length, L = 0;
      this.level.targets.forEach(function (t) { L = Math.max(L, E.chars(t).length); });
      var g = 5, rg = 8;
      var ts1 = Math.min((W - (L - 1) * g) / L, (bh - (rows - 1) * rg) / rows, 54);
      var rows2 = Math.ceil(rows / 2);
      var ts2 = Math.min((W / 2 - 10 - (L - 1) * 4) / L, (bh - (rows2 - 1) * rg) / rows2, 46);
      this.twoCol = rows >= 5 && ts2 > ts1 + 2;
      var ts = Math.floor(this.twoCol ? ts2 : ts1);
      el.style.setProperty('--ts', ts + 'px');
      el.style.setProperty('--tg', (ts < 34 ? 3 : 5) + 'px');
      el.style.setProperty('--rg', (ts < 34 ? 6 : 8) + 'px');
    },

    chipsHtml: function () {
      var f = this.feat, out = '';
      if (f.gift) out += '<span class="chip c-pink">' + ICON('chest') + T('gift') + '</span>';
      if (f.challenge) out += '<span class="chip c-coral" id="chChip">' + ICON('target') + this.challengeText() + '</span>';
      if (f.chain) out += '<span class="chip c-teal chain-chip" id="chainChip">' + ICON('chain') + '<span>' + T('chain') + '</span></span>';
      return out ? '<div class="chips">' + out + '</div>' : '';
    },
    challengeText: function () {
      var c = this.feat.challenge; return T('ch_' + c.type, { n: c.goal });
    },
    updateChips: function () {
      var c = $('#chChip', this.el); if (!c) return;
      var met = E.challengeMet(this.feat.challenge, this.sess);
      var failed = this.feat.challenge.type === 'nohint' && this.sess.hintsUsed > 0;
      c.classList.toggle('met', met && !failed); c.classList.toggle('failed', failed);
    },
    renderBoard: function () {
      var b = $('#board', this.el), self = this, html = '';
      b.classList.toggle('two-col', !!this.twoCol);
      var rows = this.level.targets.length, half = Math.ceil(rows / 2);
      this.level.targets.forEach(function (t, i) {
        var found = self.sess.isFound(i), rev = self.sess.revealed[i] || [];
        var pos = self.twoCol ? 'style="grid-column:' + (i < half ? 1 : 2) + ';grid-row:' + ((i % half) + 1) + '"' : '';
        html += '<div class="wrow' + (i === self.feat.golden ? ' golden' : '') + '" data-i="' + i + '" ' + pos + '>';
        E.chars(t).forEach(function (c, k) {
          var cls = found ? ' on' : (rev.indexOf(k) >= 0 ? ' reveal' : '');
          html += '<div class="slot c-' + self.colors[i] + cls + '" style="animation-delay:0s">' + c + '</div>';
        });
        if (i === self.feat.golden && !found) html += '<span class="tag">' + ICON('star') + '</span>';
        html += '</div>';
      });
      b.innerHTML = html;
      $$('.slot.on', b).forEach(function (s) { s.style.animation = 'none'; });
    },

    renderLetters: function () {
      var p = $('#palette', this.el), self = this;
      $$('.ptile', p).forEach(function (e) { e.remove(); });
      this.level.letters.forEach(function (c, i) {
        var t = h('<div class="ptile c-' + TILE_COLORS[(i * 5 + 2) % TILE_COLORS.length] + '" data-i="' + i + '">' + c + '</div>');
        p.appendChild(t);
      });
      this.placeLetters();
    },
    placeLetters: function () {
      var p = $('#palette', this.el), n = this.level.letters.length, pd = this.pd, pt = this.pt, self = this;
      var R = pd / 2 - pt / 2 - pd * 0.06;
      this.pos = [];
      this.order.forEach(function (li, slot) {
        var a = -Math.PI / 2 + slot * 2 * Math.PI / n;
        var x = pd / 2 + Math.cos(a) * R, y = pd / 2 + Math.sin(a) * R;
        self.pos[li] = { x: x, y: y };
        var t = $('.ptile[data-i="' + li + '"]', p);
        t.style.left = x + 'px'; t.style.top = y + 'px';
      });
    },

    // ---------- Girdi (kaydırma + dokunma) ----------
    bindInput: function () {
      var p = $('#palette', this.el), self = this, dragging = false, moved = false, startIdx = -1, pid = null;
      // Dokunurken geniş, sürüklerken dar isabet alanı: harfler arasında geçerken
      // aradaki harfin yanlışlıkla seçilmesini önler.
      function hit(e, factor) {
        var r = p.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, best = -1, bd = 1e9;
        for (var i = 0; i < self.pos.length; i++) {
          var dx = self.pos[i].x - x, dy = self.pos[i].y - y, d = dx * dx + dy * dy;
          if (d < bd) { bd = d; best = i; }
        }
        var lim = self.pt * (factor || 0.6);
        return bd <= lim * lim ? best : -1;
      }
      function local(e) { var r = p.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
      on(p, 'pointerdown', function (e) {
        if (self.busy) return;
        e.preventDefault();
        var i = hit(e); if (i < 0) return;
        pid = e.pointerId; try { p.setPointerCapture(pid); } catch (er) {}
        dragging = true; moved = false; startIdx = i;
        var k = self.sel.indexOf(i);
        if (self.tapMode && k >= 0) {
          if (k === self.sel.length - 1) { self.sel.pop(); A.play('tap'); self.refreshSel(); }
          dragging = false; return;
        }
        if (!self.tapMode && self.sel.length) self.clearSel();
        self.add(i);
      });
      on(p, 'pointermove', function (e) {
        if (!dragging || e.pointerId !== pid) return;
        var i = hit(e, 0.42), L = local(e);
        if (i >= 0) {
          var k = self.sel.indexOf(i);
          if (k < 0) { moved = true; self.add(i); }
          else if (k === self.sel.length - 2) { moved = true; self.sel.pop(); A.play('tap'); self.refreshSel(); }
        }
        self.drawLine(L);
      });
      function end(e) {
        if (!dragging || e.pointerId !== pid) return;
        dragging = false;
        try { p.releasePointerCapture(pid); } catch (er) {}
        if (moved && self.sel.length >= 2 && !self.tapMode) { self.submit(); return; }
        if (moved && self.tapMode) { self.drawLine(null); self.maybeAutoSubmit(); return; }
        // Tek dokunuş → dokunma moduna geç
        self.tapMode = true; self.drawLine(null); self.refreshSel(); self.maybeAutoSubmit();
      }
      on(p, 'pointerup', end); on(p, 'pointercancel', end);
    },
    add: function (i) {
      this.sel.push(i);
      A.play('select', this.sel.length - 1);
      vibrate(8);
      this.refreshSel();
    },
    maybeAutoSubmit: function () { if (this.sel.length === this.level.letters.length) this.submit(); },
    word: function () { var L = this.level.letters; return this.sel.map(function (i) { return L[i]; }).join(''); },
    refreshSel: function () {
      var self = this, pv = $('#preview', this.el);
      $$('.ptile', this.el).forEach(function (t) {
        var i = +t.dataset.i, k = self.sel.indexOf(i);
        t.classList.toggle('sel', k >= 0);
        var o = $('.ord', t);
        if (self.tapMode && k >= 0) { if (!o) { o = h('<span class="ord"></span>'); t.appendChild(o); } o.textContent = k + 1; }
        else if (o) o.remove();
      });
      var chars = E.chars(this.word());
      var cur = $$('span', pv).length;
      if (chars.length < cur || !chars.length) pv.innerHTML = '';
      for (var k = $$('span', pv).length; k < chars.length; k++) pv.appendChild(h('<span>' + chars[k] + '</span>'));
      pv.className = 'preview ' + (this.sel.length ? 'c-' + this.tileColor(this.sel[0]) : 'c-purple');
      // Dokunma modu düğmeleri
      var wrap = $('#pvWrap', this.el);
      $$('.pv-btn', wrap).forEach(function (b) { b.remove(); });
      if (this.tapMode && this.sel.length) {
        var no = h('<button class="pv-btn no" aria-label="' + T('close') + '">' + ICON('close') + '</button>');
        var ok = h('<button class="pv-btn ok" aria-label="' + T('ok') + '">' + ICON('ok') + '</button>');
        on(no, 'click', function () { A.play('tap'); self.clearSel(); });
        on(ok, 'click', function () { self.submit(); });
        wrap.insertBefore(no, pv); wrap.appendChild(ok);
      }
      if (!this.tapMode) this.drawLine(null);
      else this.drawLine(null);
    },
    tileColor: function (i) { return TILE_COLORS[(i * 5 + 2) % TILE_COLORS.length]; },
    drawLine: function (pt) {
      var self = this, pl = $('#line', this.el); if (!pl) return;
      var pts = this.sel.map(function (i) { return self.pos[i].x + ',' + self.pos[i].y; });
      if (pt && this.sel.length) pts.push(pt.x + ',' + pt.y);
      pl.setAttribute('points', pts.join(' '));
      pl.style.stroke = this.sel.length ? getComputedStyle($('.ptile[data-i="' + this.sel[0] + '"]', this.el)).getPropertyValue('--c') : 'transparent';
    },
    clearSel: function () { this.sel = []; this.tapMode = false; this.refreshSel(); this.drawLine(null); },

    floatMsg: function (text, cls) {
      var wrap = $('#pvWrap', this.el); if (!wrap) return;
      $$('.floatmsg', wrap).forEach(function (e) { e.remove(); });
      var m = h('<div class="floatmsg ' + (cls || '') + '">' + esc(text) + '</div>');
      wrap.appendChild(m); setTimeout(function () { m.remove(); }, 1150);
    },

    submit: function () {
      var self = this, w = this.word(), pv = $('#preview', this.el);
      if (!w) return;
      var res = this.sess.submit(w);
      this.drawLine(null);
      var R = E.RESULT;
      if (res.type === R.TARGET) {
        this.busy = true;
        pv.classList.add('good');
        this.onTargetFound(res.index, true);
        S.stats.words++; track('words');
        this.onChain();
        var golden = res.index === this.feat.golden;
        var len = E.chars(res.word).length;
        if (len >= 5) { S.stats.long++; track('long'); }
        S.stats.maxLen = Math.max(S.stats.maxLen, len);
        if (this.mode === 'rush') this.rushScore(len * ECON.rushPerLetter);
        if (len >= 5) this.floatMsg(T('greatWords')[Math.floor(Math.random() * T('greatWords').length)], 'good');
        this.flyToRow(res.index, function () {
          self.busy = false;
          if (golden) self.goldenReward(res.index);
          self.afterFound(res.complete);
        });
      } else if (res.type === R.BONUS) {
        pv.className = 'preview bonus c-yellow good';
        A.play('bonus');
        this.floatMsg(T('bonusWord'), 'good');
        S.stats.bonus++; track('bonus');
        this.updateChips();
        if (this.mode === 'rush') this.rushScore(E.chars(res.word).length * 5);
        this.flyToJar();
      } else if (res.type === R.ALREADY) {
        A.play('already');
        this.floatMsg(T('already'));
        if (res.index != null) { var row = $('.wrow[data-i="' + res.index + '"]', this.el); row.classList.remove('flash'); void row.offsetWidth; row.classList.add('flash'); }
        this.resetPreview(350);
      } else {
        A.play('wrong'); vibrate(40);
        pv.className = 'preview c-coral bad';
        this.floatMsg(res.type === R.SHORT ? T('tooShort') : T('notWord'), 'bad');
        this.resetPreview(420);
      }
      this.sel = []; this.tapMode = false;
      this.drawLine(null); // birleştirme bitince çizgi (doğru ya da yanlış) kaybolur
      $$('.ptile', this.el).forEach(function (t) { t.classList.remove('sel'); var o = $('.ord', t); if (o) o.remove(); });
      $$('.pv-btn', this.el).forEach(function (b) { b.remove(); });
      if (this.mode !== 'rush') this.persist();
      checkAchievements();
    },
    resetPreview: function (ms) {
      var pv = $('#preview', this.el);
      setTimeout(function () { if (pv && !Game.sel.length) { pv.innerHTML = ''; pv.className = 'preview c-purple'; } }, ms);
    },
    // Önizlemedeki harfleri hedef satıra uçur
    flyToRow: function (ri, done) {
      var pv = $('#preview', this.el), row = $('.wrow[data-i="' + ri + '"]', this.el);
      var spans = $$('span', pv), slots = $$('.slot', row), color = this.colors[ri];
      var low = S.settings.lowFx;
      spans.forEach(function (sp, k) {
        var a = sp.getBoundingClientRect(), b = slots[k].getBoundingClientRect();
        var f = h('<div class="fly-letter c-' + color + '" style="background:var(--c);left:' + a.left + 'px;top:' + a.top + 'px;width:' + a.width + 'px;height:' + a.height + 'px;font-size:' + (a.height * 0.8) + 'px">' + sp.textContent + '</div>');
        document.body.appendChild(f);
        var anim = f.animate([
          { transform: 'translate(0,0) scale(1)' },
          { transform: 'translate(' + (b.left - a.left) + 'px,' + (b.top - a.top) + 'px) scale(' + (b.width / a.width) + ',' + (b.height / a.height) + ')' },
        ], { duration: low ? 220 : 380, delay: k * (low ? 20 : 45), easing: 'cubic-bezier(.5,0,.3,1.3)', fill: 'forwards' });
        anim.onfinish = function () { f.remove(); };
      });
      pv.innerHTML = ''; pv.className = 'preview c-purple';
      var total = (low ? 220 : 380) + spans.length * (low ? 20 : 45);
      setTimeout(function () {
        var landed = E.chars(Game.level.targets[ri]);
        slots.forEach(function (s, k) { s.textContent = landed[k]; s.style.animationDelay = (k * 0.04) + 's'; s.classList.remove('reveal'); s.classList.add('on'); });
        var r = row.getBoundingClientRect();
        FX.splash(r.left + r.width / 2, r.top + r.height / 2, getComputedStyle(slots[0]).getPropertyValue('--c').trim(), 22);
        A.play('correct'); vibrate(20);
        setTimeout(done, 200);
      }, total);
    },
    onTargetFound: function () { this.updateProgress(); },
    goldenReward: function (ri) {
      var row = $('.wrow[data-i="' + ri + '"]', this.el); if (!row) return;
      var tag = $('.tag', row); if (tag) tag.remove();
      var r = row.getBoundingClientRect();
      FX.sparkle(r.left + r.width / 2, r.top + r.height / 2, 18, '#E9B03A');
      this.floatMsg(T('goldenFound') + ' +' + ECON.goldenReward, 'good gold');
      S.stats.golden = (S.stats.golden || 0) + 1; track('golden');
      addCoins(ECON.goldenReward, row);
    },
    onChain: function () {
      if (!this.feat.chain) return;
      var now = Date.now(), self = this;
      this.chain = E.chainStep(this.chain, this.lastFoundAt, now); this.lastFoundAt = now;
      this.sess.bestChain = Math.max(this.sess.bestChain || 0, this.chain);
      var b = E.chainBonus(this.chain);
      if (b) { this.sess.chainCoins = (this.sess.chainCoins || 0) + b; setTimeout(function () { self.floatMsg(T('chainX', { n: self.chain }) + '  +' + b, 'good chainmsg'); A.play('bonus'); }, 380); }
      var chip = $('#chainChip', this.el);
      if (chip) {
        $('span', chip).textContent = this.chain >= 2 ? T('chainX', { n: this.chain }) : T('chain');
        chip.classList.toggle('hot', this.chain >= 2);
        chip.style.setProperty('--t', (E.CHAIN_WINDOW / 1000) + 's');
        chip.classList.remove('tick'); void chip.offsetWidth; chip.classList.add('tick');
        clearTimeout(this._chainT);
        this._chainT = setTimeout(function () { if (chip.isConnected) { chip.classList.remove('hot', 'tick'); $('span', chip).textContent = T('chain'); } }, E.CHAIN_WINDOW);
      }
      this.updateChips();
    },
    flyToJar: function () {
      var pv = $('#preview', this.el), jar = $('#tJar', this.el), self = this;
      var a = pv.getBoundingClientRect(), b = jar.getBoundingClientRect();
      var anim = pv.animate([{ transform: 'none', opacity: 1 }, { transform: 'translate(' + (b.left + b.width / 2 - a.left - a.width / 2) + 'px,' + (b.top + b.height / 2 - a.top - a.height / 2) + 'px) scale(.2)', opacity: 0.3 }], { duration: 450, easing: 'cubic-bezier(.5,-0.3,.6,1)' });
      anim.onfinish = function () {
        pv.innerHTML = ''; pv.className = 'preview c-purple';
        S.jar++;
        jar.classList.remove('bump'); void jar.offsetWidth; jar.classList.add('bump');
        FX.sparkle(b.left + b.width / 2, b.top + b.height / 2, 10);
        if (S.jar >= ECON.jarSize) {
          S.jar = 0; save();
          toast(ICON('jar'), T('bonusJar'), '+' + ECON.jarReward + ' ' + T('coins'), 'yellow');
          addCoins(ECON.jarReward, jar);
        }
        save(); self.updateTools();
      };
    },
    afterFound: function (complete) {
      this.updateProgress();
      if (this.mode === 'level' && this.index === 0 && !S.tutorialDone) { S.tutorialDone = true; save(); $$('.coach,.hand').forEach(function (e) { e.remove(); }); }
      if (complete) this.complete();
    },
    updateProgress: function () {
      var n = this.sess.found.length, t = this.level.targets.length;
      var bar = $('#gBar', this.el), c = $('#gCnt', this.el);
      if (bar) bar.style.width = (n / t * 100) + '%';
      if (c) c.textContent = n + ' / ' + t;
    },
    updateTools: function () {
      var hc = $('#hintCnt', this.el), jc = $('#jarCnt', this.el), jf = $('#jarFill', this.el);
      if (hc) hc.innerHTML = S.hints > 0 ? S.hints : ICON('coin') + ECON.hintCost;
      if (jc) jc.textContent = S.jar + '/' + ECON.jarSize;
      if (jf) jf.style.height = (S.jar / ECON.jarSize * 70) + '%';
    },

    // ---------- Yardımlar ----------
    shuffle: function () {
      if (this.busy) return;
      A.play('shuffle'); this.clearSel();
      var prev = this.order.join(), guard = 0;
      do { this.order = E.shuffle(this.order, Math.random); } while (this.order.join() === prev && guard++ < 5);
      this.placeLetters();
      S.stats.shuffles++; track('shuffle'); save();
    },
    hint: function () {
      if (this.busy || this.mode === 'rush') return;
      if (S.hints <= 0 && S.coins < ECON.hintCost) { notEnoughCoins(); return; }
      var r = this.sess.revealLetter(Math.random);
      if (!r) return;
      if (S.hints > 0) S.hints--; else { S.coins -= ECON.hintCost; refreshCoins(true); }
      S.stats.hints++;
      A.play('hint');
      var row = $('.wrow[data-i="' + r.index + '"]', this.el), slot = $$('.slot', row)[r.pos];
      var b = slot.getBoundingClientRect();
      FX.sparkle(b.left + b.width / 2, b.top + b.height / 2, 10);
      if (r.autoFound) {
        $$('.slot', row).forEach(function (s) { s.classList.remove('reveal'); s.classList.add('on'); });
        S.stats.words++; track('words');
        this.afterFound(r.complete);
      } else slot.classList.add('reveal');
      this.updateTools(); this.updateChips(); this.persist();
    },
    brush: function () {
      if (this.busy || this.mode === 'rush') return;
      if (S.coins < ECON.brushCost) { notEnoughCoins(); return; }
      var r = this.sess.revealWord(Math.random);
      if (!r) return;
      S.coins -= ECON.brushCost; refreshCoins(true);
      S.stats.hints++;
      A.play('hint');
      var row = $('.wrow[data-i="' + r.index + '"]', this.el);
      $$('.slot', row).forEach(function (s, k) { s.style.animationDelay = (k * 0.05) + 's'; s.classList.remove('reveal'); s.classList.add('on'); });
      var b = row.getBoundingClientRect();
      FX.splash(b.left + b.width / 2, b.top + b.height / 2, '#8E7CE6', 20);
      S.stats.words++; track('words');
      this.updateChips(); this.persist();
      this.afterFound(r.complete);
    },

    tutorial: function () {
      if (current !== 'game') return;
      var p = $('#palette', this.el), self = this;
      var coach = h('<div class="coach">' + T('tutorial1') + '</div>');
      p.appendChild(coach);
      // El animasyonu: en kısa hedefin harfleri üzerinde gezinir
      var target = this.level.targets[0], used = [], path = [];
      E.chars(target).forEach(function (c) {
        for (var i = 0; i < self.level.letters.length; i++) if (self.level.letters[i] === c && used.indexOf(i) < 0) { used.push(i); path.push(self.pos[i]); break; }
      });
      if (!path.length || S.settings.lowFx) return;
      var hand = h('<div class="hand"></div>'); p.appendChild(hand);
      var kf = path.map(function (q) { return { transform: 'translate(' + (q.x - 20) + 'px,' + (q.y - 20) + 'px)' }; });
      kf.push(kf[kf.length - 1]);
      hand.animate(kf, { duration: 700 * path.length + 600, iterations: Infinity, easing: 'ease-in-out' });
    },

    // ---------- Bölüm sonu ----------
    complete: function () {
      var self = this;
      this.busy = true;
      if (this.mode === 'rush') {
        this.rushScore(50);
        this.rush.left += 8; this.rush.words += this.level.targets.length;
        FX.sparkle(window.innerWidth / 2, window.innerHeight * 0.4, 16);
        A.play('complete');
        setTimeout(function () {
          self.level = self.rushLevel();
          self.sess = new E.LevelSession(self.level, dict(S.lang));
          self.order = self.level.letters.map(function (_, i) { return i; });
          self.colors = self.level.targets.map(function (_, i) { return TILE_COLORS[(i * 3 + self.rush.n) % TILE_COLORS.length]; });
          self.busy = false;
          self.layout(); self.renderBoard(); self.renderLetters(); self.updateProgress(); self.clearSel();
        }, 900);
        return;
      }
      setTimeout(function () {
        FX.confetti(); A.play('complete'); vibrate(60);
        if (self.mode === 'daily') self.finishDaily(); else self.finishLevel();
      }, 500);
    },
    finishLevel: function () {
      var i = this.index, p = prog(), stars = this.sess.stars(), prev = p.stars[i] || 0, first = !prev, f = this.feat;
      var g = ART.gallery(i), before = galleryPainted(g);
      var base = first ? ECON.levelBase + stars * ECON.perStar : (stars > prev ? ECON.replayBonus : 0);
      p.stars[i] = Math.max(prev, stars);
      p.cur = Math.max(p.cur, i + 1);
      var after = galleryPainted(g), galDone = first && after >= ART.PER && before < ART.PER;
      var rows = [];
      if (base) rows.push([ICON('coin'), T('coinsEarned'), base]);
      if (galDone) rows.push([ICON('palette'), T('galleryComplete'), ECON.galleryBonus]);
      var chMet = first && f.challenge && E.challengeMet(f.challenge, this.sess);
      if (chMet) rows.push([ICON('target'), T('challengeReward'), ECON.challengeReward]);
      if (this.sess.chainCoins) rows.push([ICON('chain'), T('chainBonus'), this.sess.chainCoins]);
      var coins = rows.reduce(function (a, r) { return a + r[2]; }, 0);
      var gift = first && f.gift;
      if (first) { S.stats.levels++; track('levels'); }
      if (stars === 3 && prev < 3) { S.stats.perfect++; track('stars3'); }
      if (chMet) S.stats.challenges = (S.stats.challenges || 0) + 1;
      S.session = null;
      var unlocked = [];
      ['daily', 'rush'].forEach(function (m) { if (p.cur >= UNLOCK[m] && !S.notified[m]) { S.notified[m] = 1; unlocked.push(m); } });
      save(true);
      var self = this, list = levels(S.lang), hasNext = i + 1 < list.length;
      var html = '<div class="ribbon">' + (galDone ? T('galleryComplete') : T('levelComplete')) + '</div>' +
        '<div class="bigstars">' + [1, 2, 3].map(function (s) { return ICON('star', s <= stars ? 'on' : ''); }).join('') + '</div>' +
        (chMet ? '<div class="chip c-coral met" style="margin:0 auto 6px">' + ICON('target') + T('challengeDone') + '</div>' : '') +
        '<div class="mpainting">' + ART.svg(g, after, { highlight: first ? after - 1 : -1 }) + '</div>' +
        '<div class="muted" style="font-weight:900">' + esc(ART.name(g, S.lang)) + ' · ' + after + '/' + ART.PER + '</div>' +
        (gift ? '<div class="chest-box" id="chestBox"><button class="chest" id="chestBtn" aria-label="' + T('openChest') + '">' + ICON('chestc') + '</button><button class="btn pink sm" id="chestOpen">' + ICON('gift') + T('openChest') + '</button></div>' : '') +
        '<div class="reward-rows">' + rows.map(function (r) { return '<div class="rrow">' + r[0] + '<span>' + r[1] + '</span><span class="v">+' + r[2] + '</span></div>'; }).join('') +
        (this.sess.bonusFound.length ? '<div class="rrow">' + '<span style="color:var(--yellow-d)">' + ICON('jar') + '</span>' + T('bonusFound') + '<span class="v">' + this.sess.bonusFound.length + '</span></div>' : '') +
        '</div>' +
        '<div class="actions"><button class="btn white sm" data-home aria-label="' + T('map') + '">' + ICON('map') + '</button>' +
        (hasNext ? '<button class="btn block" data-next style="flex:3">' + T('next') + ' ' + ICON('play') + '</button>' : '<button class="btn block" data-home2 style="flex:3">' + T('map') + '</button>') + '</div>';
      var m = modal(html, { closable: false });
      var coinRow = $('.rrow', m.el);
      setTimeout(function () { if (coins) addCoins(coins, coinRow); }, 700);
      if (galDone) setTimeout(function () { FX.rain(120); A.play('reward'); }, 900);
      if (gift) {
        var opened = false;
        var openChest = function () {
          if (opened) return; opened = true;
          var box = $('#chestBox', m.el), chest = $('#chestBtn', m.el);
          chest.classList.add('opening'); A.play('shuffle');
          setTimeout(function () {
            var r = chest.getBoundingClientRect();
            FX.splash(r.left + r.width / 2, r.top + r.height / 2, '#F2705F', 30); FX.sparkle(r.left + r.width / 2, r.top + r.height / 2, 16);
            A.play('reward');
            S.hints += ECON.giftHints; save();
            box.innerHTML = '<div class="chest-loot"><span>' + ICON('coin') + '+' + ECON.giftCoins + '</span><span style="color:var(--pink)">' + ICON('bulb') + '+' + ECON.giftHints + '</span></div>';
            addCoins(ECON.giftCoins, box);
          }, 650);
        };
        on($('#chestBtn', m.el), 'click', openChest); on($('#chestOpen', m.el), 'click', openChest);
      }
      var leave = function (to) {
        // Hediye sandığı açılmadan çıkılırsa ödül yine verilir (oyuncu kaybetmez)
        if (gift && !opened) { opened = true; S.hints += ECON.giftHints; addCoins(ECON.giftCoins); }
        A.play('button'); m.close();
        if (to === 'next') {
          var ctx = { mode: 'level', levelNumber: i + 1, dayKey: E.dayKey(), firstTimeGallery: galDone };
          transition(function () {
            window.CWAds.betweenLevels(ctx).then(function () { save(); self.start({ mode: 'level', index: i + 1 }); });
          });
        } else { show('map', {}, { noHistory: true }); history = ['menu']; }
      };
      on($('[data-home]', m.el), 'click', function () { leave('map'); });
      var h2 = $('[data-home2]', m.el); if (h2) on(h2, 'click', function () { leave('map'); });
      var nx = $('[data-next]', m.el); if (nx) on(nx, 'click', function () { leave('next'); });
      unlocked.forEach(function (u, k) { setTimeout(function () { toast(ICON(u === 'daily' ? 'calendar' : 'bolt'), T('newMode'), T(u), u === 'daily' ? 'coral' : 'blue'); A.play('reward'); }, 1400 + k * 600); });
      checkAchievements();
    },
    finishDaily: function () {
      var d = S.dailyWord, today = E.dayKey();
      d.streak = d.lastDone && E.dayDiff(d.lastDone, today) === 1 ? d.streak + 1 : 1;
      d.lastDone = today; d.done = true; d.session = null;
      S.stats.daily++; track('daily');
      S.hints += 1;
      save(true);
      var m = modal('<div class="ribbon coral">' + T('daily') + '</div>' +
        '<div style="font-size:72px;color:var(--coral);margin-top:8px">' + ICON('calendar') + '</div><h3>' + T('dailyDone') + '</h3>' +
        '<div class="streak">' + ICON('flame') + T('streak', { n: d.streak }) + '</div>' +
        '<div class="reward-rows"><div class="rrow">' + ICON('coin') + T('coinsEarned') + '<span class="v">+' + ECON.dailyWordCoins + '</span></div>' +
        '<div class="rrow"><span style="color:var(--pink)">' + ICON('bulb') + '</span>' + T('hint') + '<span class="v">+1</span></div></div>' +
        '<button class="btn block" data-ok>' + T('home') + '</button>', { closable: false });
      setTimeout(function () { addCoins(ECON.dailyWordCoins, $('.rrow', m.el)); }, 600);
      on($('[data-ok]', m.el), 'click', function () { A.play('button'); m.close(); show('menu', {}, { noHistory: true }); });
      checkAchievements();
    },

    // ---------- Renk Koşusu ----------
    rushScore: function (n) {
      this.rush.score += n;
      var el = $('#rushScore', this.el); if (el) el.textContent = this.rush.score;
    },
    startTimer: function () {
      var self = this;
      this.stopTimer();
      this.timer = setInterval(function () {
        if (document.hidden || modalStack.length) return;
        self.rush.left--;
        var t = $('#rushTime', self.el);
        if (t) { $('span', t).textContent = Math.max(0, self.rush.left); t.classList.toggle('low', self.rush.left <= 10); }
        if (self.rush.left <= 10 && self.rush.left > 0) A.play('tick');
        if (self.rush.left <= 0) { self.stopTimer(); self.endRush(); }
      }, 1000);
    },
    stopTimer: function () { if (this.timer) { clearInterval(this.timer); this.timer = null; } },
    endRush: function () {
      var r = this.rush, best = Math.max(S.stats.rushBest, r.score), isBest = r.score > S.stats.rushBest && r.score > 0;
      S.stats.rushBest = best; S.stats.rush++; track('rush');
      var coins = Math.floor(r.score / 20);
      this.busy = true; this.clearSel();
      save(true);
      A.play('complete'); if (isBest) FX.confetti(100);
      var self = this;
      var m = modal('<div class="ribbon blue">' + T('timeUp') + '</div>' +
        '<div style="font-size:66px;color:var(--blue);margin-top:8px">' + ICON('bolt') + '</div>' +
        '<div class="reward-rows"><div class="rrow">' + T('score') + '<span class="v">' + r.score + '</span></div>' +
        '<div class="rrow">' + T('best') + (isBest ? ' ' + ICON('crown') : '') + '<span class="v">' + best + '</span></div>' +
        '<div class="rrow">' + ICON('coin') + T('coinsEarned') + '<span class="v">+' + coins + '</span></div></div>' +
        '<div class="actions"><button class="btn white sm" data-home>' + ICON('home') + '</button><button class="btn blue" data-again style="flex:3">' + ICON('refresh') + T('replay') + '</button></div>', { closable: false });
      if (coins) setTimeout(function () { addCoins(coins, $('.rrow', m.el)); }, 600);
      on($('[data-home]', m.el), 'click', function () { A.play('button'); m.close(); show('menu', {}, { noHistory: true }); });
      on($('[data-again]', m.el), 'click', function () { A.play('button'); m.close(); self.start({ mode: 'rush' }); });
      checkAchievements();
    },
  };
  SCREENS.game = { render: function (el) { Game.render(el); }, leave: function () { Game.leaveScreen(); Game.stopTimer(); } };

  // =========================================================
  // 5. Görevler
  // =========================================================
  var TASK_ICON = { words: ['feather', 'teal'], levels: ['map', 'green'], bonus: ['jar', 'yellow'], stars3: ['star', 'orange'], long: ['trophy', 'purple'], shuffle: ['shuffle', 'blue'], daily: ['calendar', 'coral'], rush: ['bolt', 'blue'], golden: ['star', 'gold'] };
  function untilMidnight() {
    var n = new Date(), m = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1), s = Math.max(0, Math.floor((m - n) / 1000));
    var hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60);
    return hh + (S.lang === 'tr' ? ' sa ' : 'h ') + mm + (S.lang === 'tr' ? ' dk' : 'm');
  }
  var tasksTimer = null;
  function untilWeekEnd() {
    var n = new Date(), d = (8 - (n.getDay() || 7)) % 7 || 7, m = new Date(n.getFullYear(), n.getMonth(), n.getDate() + d);
    var s = Math.max(0, Math.floor((m - n) / 1000)), dd = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600);
    return dd + (S.lang === 'tr' ? ' gün ' : 'd ') + hh + (S.lang === 'tr' ? ' sa' : 'h');
  }
  SCREENS.tasks = {
    render: function (el) {
      rollDay();
      function block(list, weekly) {
        return list.map(function (t, k) {
          var pr = taskProgress(t, weekly), done = pr >= t.goal, ic = TASK_ICON[t.metric] || ['star', 'teal'];
          return '<div class="card task' + (t.claimed ? ' done' : '') + (weekly ? ' weekly' : '') + '"><div class="ticon c-' + ic[1] + '">' + ICON(ic[0]) + '</div>' +
            '<div class="tb"><div class="tt">' + T('task_' + t.id, { n: t.goal }) + '</div><div class="bar ' + (weekly ? 'pink' : 'gold') + '"><i style="width:' + (pr / t.goal * 100) + '%"></i></div>' +
            '<div class="tp">' + pr + ' / ' + t.goal + ' · ' + ICON('coin') + ' ' + t.reward + '</div></div>' +
            (t.claimed ? '<button class="btn sm white off" aria-label="' + T('claimed') + '">' + ICON('check') + '</button>' :
              '<button class="btn sm ' + (done ? (weekly ? 'pink' : 'yellow') : 'white off') + '" data-claim="' + k + '" data-weekly="' + (weekly ? 1 : 0) + '">' + T('claim') + '</button>') + '</div>';
        }).join('');
      }
      el.innerHTML = topbar(T('tasks')) + '<div class="scroll">' +
        '<div class="section-title">' + ICON('tasks') + T('dailyTasks') + '</div><div class="reset-note" id="resetNote">' + T('resetIn', { t: untilMidnight() }) + '</div>' + block(S.today.tasks, false) +
        '<div class="section-title">' + ICON('calendar') + T('weeklyTasks') + '</div><div class="reset-note">' + T('weeklyReset', { t: untilWeekEnd() }) + '</div>' + block(S.week.tasks, true) +
        '</div>';
      $$('[data-claim]', el).forEach(function (b) {
        on(b, 'click', function () {
          var weekly = b.dataset.weekly === '1', t = (weekly ? S.week : S.today).tasks[+b.dataset.claim];
          if (t.claimed || taskProgress(t, weekly) < t.goal) return;
          t.claimed = true; A.play('reward');
          addCoins(t.reward, b);
          var r = b.getBoundingClientRect(); FX.sparkle(r.left + r.width / 2, r.top + r.height / 2, 12);
          checkAchievements();
          setTimeout(function () { if (current === 'tasks') SCREENS.tasks.render(el); }, 900);
        });
      });
      clearInterval(tasksTimer);
      tasksTimer = setInterval(function () { var n = $('#resetNote'); if (n) n.textContent = T('resetIn', { t: untilMidnight() }); if (S.today.key !== E.dayKey() && current === 'tasks') SCREENS.tasks.render(el); }, 30000);
    },
    leave: function () { clearInterval(tasksTimer); },
  };

  // =========================================================
  // 6. Ödüller (7 günlük takvim)
  // =========================================================
  function rewardState() { return E.dailyRewardState({ lastRewardDay: S.reward.last, rewardStreak: S.reward.streak }, E.dayKey()); }
  SCREENS.rewards = {
    render: function (el) {
      var st = rewardState();
      var html = topbar(T('rewards')) + '<div class="scroll"><div class="card" style="text-align:center"><div class="section-title" style="justify-content:center;margin-top:0">' + ICON('gift') + T('dailyReward') + '</div><div class="days">';
      E.DAILY_REWARDS.forEach(function (r, i) {
        var got = st.canClaim ? i < st.dayIndex : i <= st.dayIndex;
        var today = st.canClaim && i === st.dayIndex;
        var icon = r.hints && !r.coins ? '<span style="color:var(--pink)">' + ICON('bulb') + '</span>' : ICON('coin');
        var val = (r.coins ? r.coins : '') + (r.hints ? (r.coins ? ' + ' : '') + r.hints + ' ' + ICON('bulb') : '');
        html += '<div class="dayc' + (got ? ' got' : '') + (today ? ' today' : '') + (i === 6 ? ' big' : '') + '"><div class="dn">' + T('day', { n: i + 1 }) + '</div><div class="dr">' + (i === 6 ? ICON('gift') : icon) + '</div><div class="dv">' + val + '</div></div>';
      });
      html += '</div>' + ((st.canClaim ? st.streak : S.reward.streak) ? '<div class="streak">' + ICON('flame') + T('streak', { n: st.canClaim ? st.streak : S.reward.streak }) + '</div>' : '<div style="height:14px"></div>') +
        (st.canClaim ? '<button class="btn pink block" id="claimDay">' + ICON('gift') + T('claimReward') + '</button>' : '<button class="btn white block off">' + T('comeBack') + '</button>') +
        '</div><div class="note">' + T('collectionDesc') + '</div></div>';
      el.innerHTML = html;
      var b = $('#claimDay', el);
      if (b) on(b, 'click', function () {
        var st2 = rewardState(); if (!st2.canClaim) return;
        var r = E.DAILY_REWARDS[st2.dayIndex];
        S.reward.streak = st2.streak + 1; S.reward.last = E.dayKey();
        if (r.hints) S.hints += r.hints;
        A.play('reward'); FX.confetti(70);
        if (r.coins) addCoins(r.coins, b); else save();
        save(true); checkAchievements();
        setTimeout(function () { if (current === 'rewards') SCREENS.rewards.render(el); }, 900);
      });
    },
  };

  // =========================================================
  // 7. Ayarlar
  // =========================================================
  SCREENS.settings = {
    render: function (el) {
      var s = S.settings;
      function row(id, icon, color, label, desc, val) {
        return '<div class="set-row"><div class="si c-' + color + '">' + ICON(icon) + '</div><div class="sl">' + label + (desc ? '<small>' + desc + '</small>' : '') + '</div><button class="switch' + (val ? ' on' : '') + '" data-set="' + id + '" role="switch" aria-checked="' + !!val + '"></button></div>';
      }
      el.innerHTML = topbar(T('settings'), '<span style="width:46px"></span>') + '<div class="scroll"><div class="card">' +
        row('sfx', 'sound', 'teal', T('sound'), '', s.sfx) +
        row('music', 'music', 'purple', T('music'), '', s.music) +
        row('vib', 'vibrate', 'pink', T('vibration'), '', s.vib) +
        row('lowFx', 'bolt', 'orange', T('lowFx'), T('lowFxDesc'), s.lowFx) +
        (LANG_SWITCH ? '<div class="set-row"><div class="si c-blue">' + ICON('globe') + '</div><div class="sl">' + T('language') + '</div><div class="seg-ctl">' +
        '<button data-lang="tr" class="' + (S.lang === 'tr' ? 'on' : '') + '">TR</button><button data-lang="en" class="' + (S.lang === 'en' ? 'on' : '') + '">EN</button></div></div>' : '') +
        '</div><div class="card">' +
        '<div class="set-row" data-x="credits" style="cursor:pointer"><div class="si c-green">' + ICON('info') + '</div><div class="sl">' + T('credits') + '<small>' + T('version') + ' ' + VERSION + '</small></div>' + ICON('play') + '</div>' +
        '<div class="set-row" data-x="privacy" style="cursor:pointer"><div class="si c-teal">' + ICON('lock') + '</div><div class="sl">' + T('privacy') + '</div>' + ICON('play') + '</div>' +
        '<div class="set-row" data-x="reset" style="cursor:pointer"><div class="si c-coral">' + ICON('eraser') + '</div><div class="sl" style="color:var(--coral-d)">' + T('resetProgress') + '</div></div>' +
        '</div></div>';
      $$('[data-set]', el).forEach(function (b) {
        on(b, 'click', function () {
          var k = b.dataset.set; s[k] = !s[k]; b.classList.toggle('on', s[k]); b.setAttribute('aria-checked', s[k]);
          applySettings(); A.play('button'); save();
        });
      });
      $$('[data-lang]', el).forEach(function (b) {
        on(b, 'click', function () {
          if (S.lang === b.dataset.lang) return;
          S.lang = b.dataset.lang; I18N.set(S.lang); S.session = null; save(true); A.play('button');
          SCREENS.settings.render(el);
        });
      });
      on($('[data-x="credits"]', el), 'click', function () {
        A.play('button');
        modal('<h3>Kelime Yolculuğu</h3><div class="licenses">' + T('version') + ' ' + VERSION + '<br><br>' + licenseText() + '</div><button class="btn block sm" style="margin-top:14px" data-close>' + T('close') + '</button>');
      });
      on($('[data-x="privacy"]', el), 'click', function () { A.play('button'); modal('<h3>' + T('privacy') + '</h3><p>' + T('privacyText') + '</p><button class="btn block sm" data-close>' + T('ok') + '</button>'); });
      on($('[data-x="reset"]', el), 'click', function () {
        A.play('button');
        confirmBox(T('resetConfirm'), function () {
          var lang = S.lang, settings = S.settings;
          var ads = S.ads; // satın alınmış reklamsız sürüm sıfırlamada korunur
          ST.clear(); S = defaultSave(); S.lang = lang; S.settings = settings; S.tutorialDone = true; S.deviceChecked = true;
          S.ads = { adsRemoved: !!(ads && ads.adsRemoved) }; window.CWAds.attach(S.ads); save(true);
          show('menu', {}, { noHistory: true });
        });
      });
    },
  };
  function licenseText() {
    return S.lang === 'tr'
      ? '<b>Kod, tasarım, ikonlar, tablolar:</b> Bu proje için özgün olarak üretildi.<br><b>Sesler ve müzik:</b> Çalışma anında Web Audio ile sentezlenir; harici ses dosyası yoktur.<br><b>Yazı tipi:</b> Inter © The Inter Project Authors — SIL Open Font License 1.1.<br><b>Sözlük:</b> Ortak Türkçe kelimelerden özgün derleme.'
      : '<b>Code, design, icons, paintings:</b> Original work made for this project.<br><b>Sounds & music:</b> Synthesized at runtime with Web Audio; no external audio files.<br><b>Font:</b> Inter © The Inter Project Authors — SIL Open Font License 1.1.<br><b>Dictionary:</b> Original compilation of common words.';
  }
  function applySettings() {
    A.setSfx(S.settings.sfx); A.setMusic(S.settings.music);
    FX.setLow(S.settings.lowFx); document.body.classList.toggle('lowfx', !!S.settings.lowFx);
  }

  // =========================================================
  // 8. Başarımlar + Koleksiyon
  // =========================================================
  SCREENS.achievements = {
    tab: 'ach',
    render: function (el, params) {
      var self = this; if (params.tab) this.tab = params.tab;
      var html = topbar(T('achievements')) + '<div class="tabs"><button class="tab' + (this.tab === 'ach' ? ' on' : '') + '" data-tab="ach">' + T('achievements') + '</button><button class="tab' + (this.tab === 'col' ? ' on' : '') + '" data-tab="col">' + T('collection') + '</button></div><div class="scroll">';
      if (this.tab === 'ach') {
        html += '<div class="ach-grid">';
        ACH.forEach(function (a) {
          var got = !!S.ach[a.id], v = Math.min(a.goal, a.m()), txt = a[S.lang] || a.tr;
          html += '<div class="ach' + (got ? '' : ' lock') + '"><div class="medal c-' + a.c + '">' + ICON(a.icon) + '</div><b>' + esc(txt[0]) + '</b><small>' + esc(txt[1]) + '</small>' +
            (got ? '<div style="color:var(--green-d);font-weight:900;font-size:13px">' + ICON('check') + ' +' + ACH_REWARD + '</div>' : '<div class="bar gold"><i style="width:' + (v / a.goal * 100) + '%"></i></div>') + '</div>';
        });
        html += '</div>';
      } else {
        var total = Math.ceil(levels(S.lang).length / ART.PER);
        html += '<p class="muted" style="text-align:center">' + T('collectionDesc') + '</p><div class="coll-grid">';
        for (var g = 0; g < total; g++) {
          var pnt = galleryPainted(g);
          var inf = ART.info(g);
          html += '<div class="coll' + (pnt >= ART.PER ? ' done' : pnt ? '' : ' lock') + '">' + ART.svg(g, pnt) + '<b>' + (inf.plate ? (inf.plate < 10 ? '0' : '') + inf.plate + ' · ' : '') + esc(inf.name) + '</b>' + (pnt >= ART.PER ? '<small>' + esc(inf.place) + '</small>' : '<small>' + pnt + '/' + ART.PER + '</small>') + '</div>';
        }
        html += '</div>';
      }
      el.innerHTML = html + '</div>';
      $$('[data-tab]', el).forEach(function (b) { on(b, 'click', function () { A.play('button'); self.tab = b.dataset.tab; self.render(el, {}); }); });
    },
  };

  // Mağaza (4. aşamada doldurulacak alan; şimdilik altın kaynaklarını gösterir)
  SCREENS.shop = {
    render: function (el) {
      el.innerHTML = topbar(T('coins')) + '<div class="scroll">' +
        '<div class="card shop-item"><div class="sic c-pink">' + ICON('gift') + '</div><div class="sb"><b>' + T('dailyReward') + '</b><small>' + T('rewards') + '</small></div><button class="btn sm pink" data-go="rewards">' + ICON('play') + '</button></div>' +
        '<div class="card shop-item"><div class="sic c-teal">' + ICON('tasks') + '</div><div class="sb"><b>' + T('dailyTasks') + '</b><small>' + T('tasks') + '</small></div><button class="btn sm teal" data-go="tasks">' + ICON('play') + '</button></div>' +
        '</div>';
    },
  };

  // =========================================================
  // Başlatma
  // =========================================================
  function boot() {
    // İlk açılışta zayıf cihazı algıla → hafif efekt modu
    if (!S.deviceChecked) {
      S.deviceChecked = true;
      var mem = navigator.deviceMemory || 4, cpu = navigator.hardwareConcurrency || 4;
      if (mem <= 2 || cpu <= 2) S.settings.lowFx = true;
      save();
    }
    window.CWAds.attach(S.ads);
    window.CWAds.init();
    I18N.set(S.lang);
    FX.init();
    applySettings();
    rollDay();
    // Native: geri tuşu ve uygulama durumu
    var C = window.Capacitor, App = C && C.Plugins && C.Plugins.App;
    if (App && C.isNativePlatform && C.isNativePlatform()) {
      App.addListener('backButton', function () { if (!back()) App.exitApp(); });
      App.addListener('pause', function () { Game.leave && current === 'game' && Game.persist(); save(true); A.pause(); });
      App.addListener('resume', function () { A.resume(); rollDay(); if (current === 'menu') show('menu', {}, { noHistory: true }); });
      ST.loadNative().then(function (n) {
        // localStorage silinmişse SharedPreferences yedeğinden geri yükle
        if (n && (!S.savedAt || (n.savedAt || 0) > S.savedAt)) { S = migrate(n); window.CWAds.attach(S.ads); I18N.set(S.lang); applySettings(); if (current === 'menu') show('menu', {}, { noHistory: true }); }
      });
    } else {
      // Tarayıcıda Escape = geri
      on(document, 'keydown', function (e) { if (e.key === 'Escape') back(); });
    }
    on(document, 'visibilitychange', function () {
      if (document.hidden) { if (current === 'game' && Game.mode !== 'rush') Game.persist(); save(true); A.pause(); }
      else A.resume();
    });
    on(window, 'pagehide', function () { save(true); });
    on(document, 'contextmenu', function (e) { e.preventDefault(); });
    show('splash', {}, { noHistory: true });
  }

  // Test ve hata ayıklama için dışa açılan arayüz
  window.CW = { get S() { return S; }, Game: Game, show: show, back: back, levels: levels, dict: dict, save: save, ECON: ECON, UNLOCK: UNLOCK, ACH: ACH, current: function () { return current; }, modals: function () { return modalStack.length; } };
  boot();
})();
