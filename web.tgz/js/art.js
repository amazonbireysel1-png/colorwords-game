/*
 * Color Words – "Çiçek tablosu" sistemi (imza görsel). Her 20 bölümde bir mandala çiçeği tamamlanır.
 * Çiçekler tamamen kodla üretilir: simetrik, temiz geometrik yapraklar, her galeride farklı şekil ve palet.
 * Her tamamlanan bölüm bir yaprağı boyar; çiçek içten dışa doğru ve her adımda simetrik biçimde büyür.
 */
(function (root) {
  'use strict';
  var PER = 20;
  var NAMES = {
    tr: ['Mercan Koyu', 'Lale Bahçesi', 'Limon Vadisi', 'Lavanta Tepesi', 'Turkuaz Lagün', 'Kiraz Ormanı', 'Şeker Adası',
      'Gökkuşağı Çarşısı', 'Okyanus Rüzgârı', 'Güneş Bahçesi', 'Pembe Bulutlar', 'Zümrüt Şelale', 'Mandalina Limanı',
      'Mor Dağlar', 'Yıldız Pazarı', 'Nar Çiçeği', 'Mavi Fener', 'Bal Petekleri', 'Papatya Kırı', 'Ay Işığı Gölü',
      'Kelebek Vadisi', 'Pamuk Kasaba', 'Yakut Kanyon', 'Nane Adası', 'Renk Sarayı'],
    en: ['Coral Bay', 'Tulip Garden', 'Lemon Valley', 'Lavender Hill', 'Turquoise Lagoon', 'Cherry Woods', 'Candy Island',
      'Rainbow Bazaar', 'Ocean Breeze', 'Sun Garden', 'Pink Clouds', 'Emerald Falls', 'Tangerine Harbor',
      'Purple Peaks', 'Star Market', 'Pomegranate Bloom', 'Blue Lighthouse', 'Honeycombs', 'Daisy Meadow', 'Moonlit Lake',
      'Butterfly Valley', 'Cotton Town', 'Ruby Canyon', 'Mint Island', 'Color Palace'],
  };
  // Her palet: [iç halka, orta halka, dış halka, vurgu(merkez)] – turkuaz, mint, mercan, şeftali, lavanta, ölçülü altın
  var PALETTES = [
    ['#F2705F', '#F59A62', '#E9B03A', '#14A8AE'],
    ['#14A8AE', '#3DBF8F', '#8E7CE6', '#E9B03A'],
    ['#E9B03A', '#F59A62', '#3DBF8F', '#14A8AE'],
    ['#8E7CE6', '#4C9ED9', '#14A8AE', '#E9B03A'],
    ['#3DBF8F', '#14A8AE', '#4C9ED9', '#F2705F'],
    ['#F2705F', '#EE7C94', '#8E7CE6', '#E9B03A'],
    ['#F59A62', '#F2705F', '#8E7CE6', '#14A8AE'],
  ];
  // Temiz, simetrik yaprak şekilleri (birim yaprak: (0,0)'dan yukarı, uzunluk 1)
  var SHAPES = [
    function (w) { return 'M0 0C' + w + ' -.22 ' + w + ' -.72 0 -1C' + (-w) + ' -.72 ' + (-w) + ' -.22 0 0Z'; },                  // sivri yaprak
    function (w) { return 'M0 0C' + (w * 1.25) + ' -.18 ' + (w * 1.1) + ' -.88 0 -.92C' + (-w * 1.1) + ' -.88 ' + (-w * 1.25) + ' -.18 0 0Z'; }, // yuvarlak taç yaprak
    function (w) { return 'M0 0L' + w + ' -.46 0 -1 ' + (-w) + ' -.46Z'; },                                                         // baklava
    function (w) { return 'M0 0Q' + (w * 1.5) + ' -.5 0 -1Q' + (-w * 1.5) + ' -.5 0 0Z'; },                                         // damla
  ];

  function gallery(levelIndex) { return Math.floor(levelIndex / PER); }
  function name(g, lang) { var a = NAMES[lang] || NAMES.tr; return a[g % a.length] + (g >= a.length ? ' ' + (Math.floor(g / a.length) + 1) : ''); }

  // 20 parça: iç halka 4, orta halka 8, dış halka 8. Boyama sırası içten dışa ve her adımda simetrik (karşılıklı çiftler).
  function segments(g) {
    var sA = SHAPES[0], sB = SHAPES[(g + 1) % SHAPES.length], sC = SHAPES[(g + 2) % SHAPES.length];
    var rings = [
      { n: 4, r0: 4, len: 24, w: 0.50, rot: 45, sh: sA, order: [0, 2, 1, 3] },
      { n: 8, r0: 16, len: 28, w: 0.44, rot: 22.5, sh: sB, order: [0, 4, 2, 6, 1, 5, 3, 7] },
      { n: 8, r0: 30, len: 35, w: 0.38, rot: 0, sh: sC, order: [0, 4, 2, 6, 1, 5, 3, 7] },
    ];
    var out = [];
    rings.forEach(function (rg, ri) {
      rg.order.forEach(function (i) {
        out.push({ ring: ri, d: rg.sh(rg.w), ang: rg.rot + i * 360 / rg.n, r0: rg.r0, len: rg.len });
      });
    });
    return out;
  }

  // painted: 0..20 boyanmış parça sayısı; highlight: yeni boyanan parçanın indeksi
  function svg(g, painted, opts) {
    opts = opts || {};
    var pal = PALETTES[g % PALETTES.length];
    var segs = segments(g);
    var out = '<svg class="painting" viewBox="-70 -70 140 140" aria-hidden="true">';
    out += '<defs><radialGradient id="pg' + g + '" cx="50%" cy="42%" r="62%"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#E6F0F2"/></radialGradient></defs>';
    out += '<circle r="68" fill="url(#pg' + g + ')"/><circle r="67" fill="none" stroke="' + pal[0] + '" stroke-opacity=".22" stroke-width="1"/>';
    out += '<circle r="62" fill="none" stroke="' + pal[1] + '" stroke-opacity=".16" stroke-width=".8"/>';
    segs.forEach(function (s, i) {
      var on = i < painted;
      var col = pal[s.ring];
      var cls = 'seg' + (on ? ' on' : '') + (opts.highlight === i ? ' fresh' : '');
      var sw = (1.1 / s.len).toFixed(4);
      out += '<g transform="rotate(' + s.ang + ') translate(0,' + (-s.r0) + ') scale(' + s.len + ')">';
      if (on) {
        out += '<path class="' + cls + '" d="' + s.d + '" fill="' + col + '" stroke="#fff" stroke-width="' + sw + '"/>';
        out += '<path class="vein" d="' + s.d + '" fill="#fff" fill-opacity=".26" transform="scale(.5)"/>';
      } else {
        out += '<path class="' + cls + '" d="' + s.d + '" fill="' + col + '" fill-opacity=".15" stroke="' + col + '" stroke-opacity=".38" stroke-width="' + sw + '"/>';
      }
      out += '</g>';
    });
    var done = painted >= PER;
    out += '<circle r="8" fill="' + (done ? pal[3] : '#fff') + '" stroke="' + (done ? '#fff' : pal[0]) + '" stroke-opacity="' + (done ? 1 : 0.35) + '" stroke-width="1.6"/>';
    if (done) out += '<circle r="2.6" fill="#fff" fill-opacity=".9"/>';
    out += '</svg>';
    return out;
  }

  root.CWArt = { PER: PER, gallery: gallery, name: name, svg: svg, palette: function (g) { return PALETTES[g % PALETTES.length]; } };
})(window);
