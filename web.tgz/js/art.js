/*
 * Kelime Yolculuğu – "Türkiye Yolculuğu" sistemi. Her il 6 bölümdür (plaka sırasıyla 01–81).
 * Her bölüm, o ilin ünlü yerinin manzara resmine bir katman ekler: gökyüzü → uzak tepeler → ara plan →
 * ön plan → ünlü yapı → ayrıntılar ve plaka. Resimler tamamen kodla (SVG) üretilir; fotoğraf kullanılmaz.
 * API (eski sistemle aynı): PER, gallery(i), name(g), svg(g, painted, opts), palette(g) + info(g).
 */
(function (root) {
  'use strict';
  var PER = 6;
  var GY = 106; // yapıların zemin çizgisi

  // Gökyüzü paletleri: üst, orta, ufuk, güneş, uzak tepe, ara tepe, ön plan, su
  var SK = [
    { top: '#8E9BE6', mid: '#F6B2A3', hor: '#FFDDA6', sun: '#FFF3CF', far: '#C9A6D6', mid2: '#E9937E', fore: '#7A4A63', water: '#F0A99B' },   // gün batımı
    { top: '#9EB4F0', mid: '#F9C9A0', hor: '#FFE6AE', sun: '#FFF6D6', far: '#EBB992', mid2: '#DE8A52', fore: '#8A4B2C', water: '#F3C49A' },   // sonbahar altını
    { top: '#79C3E8', mid: '#BDE7E0', hor: '#FFEBC6', sun: '#FFF9E4', far: '#8FD1C8', mid2: '#55B7A8', fore: '#2F7F7A', water: '#8FD6D0' },   // sabah turkuazı
    { top: '#5CB3EE', mid: '#9ED8F5', hor: '#E9F7FF', sun: '#FFFBE8', far: '#A2D3E2', mid2: '#6DC09C', fore: '#3F8F6B', water: '#7CCBEA' },   // öğle mavisi
    { top: '#6468C9', mid: '#B684D8', hor: '#F5AABA', sun: '#FFE6C2', far: '#A387D2', mid2: '#C873AC', fore: '#4B3A7A', water: '#C28FD0' },   // alacakaranlık
    { top: '#A9B9F6', mid: '#FBC3CB', hor: '#FFE5C6', sun: '#FFF4DD', far: '#E5B6D2', mid2: '#EE909E', fore: '#97506B', water: '#F4B2BD' },   // pembe şeftali
  ];
  var C = { stone: '#F7E9D2', shade: '#E4CBA8', dark: '#B98D6A', roof: '#D2644C', dome: '#8FB5BD', gold: '#F2C14E', rock: '#C79A76', wood: '#B7794E', white: '#FFFFFF', green: '#5FAE72' };

  // [plaka, il, ünlü yer, çizim türü, gökyüzü, kısa bilgi]
  var PROV = [
    [1, 'Adana', 'Taşköprü', 'bridge', 0, 'Seyhan Nehri üzerindeki Taşköprü, Roma döneminden kalma tarihi bir köprüdür.'],
    [2, 'Adıyaman', 'Nemrut Dağı', 'heads', 4, 'Nemrut Dağı, tepesindeki dev heykel başlarıyla UNESCO Dünya Mirası listesindedir.'],
    [3, 'Afyonkarahisar', 'Afyon Kalesi', 'castle', 1, 'Kale, şehrin ortasında yükselen dev bir kayalığın tepesindedir.'],
    [4, 'Ağrı', 'Ağrı Dağı', 'mountain', 3, 'Ağrı Dağı, 5.137 metreyle Türkiye\'nin en yüksek dağıdır.'],
    [5, 'Amasya', 'Yalıboyu Evleri', 'houses', 1, 'Yeşilırmak kıyısındaki Osmanlı evleri ve kaya mezarlarıyla ünlüdür.'],
    [6, 'Ankara', 'Anıtkabir', 'mausoleum', 5, 'Anıtkabir, Atatürk\'ün anıt mezarıdır; ziyaretçiler her yıl akın eder.'],
    [7, 'Antalya', 'Aspendos Tiyatrosu', 'ruins', 3, 'Aspendos, dünyanın en iyi korunmuş Roma tiyatrolarından biridir.'],
    [8, 'Artvin', 'Karagöl', 'lake', 2, 'Artvin, yemyeşil ormanları ve yayla göllerinin diyarıdır.'],
    [9, 'Aydın', 'Afrodisias', 'ruins', 1, 'Afrodisias, mermer işçiliğiyle ünlü UNESCO listesindeki antik kenttir.'],
    [10, 'Balıkesir', 'Ayvalık ve Cunda', 'sea', 0, 'Ayvalık, zeytinlikleri ve gün batımıyla meşhur bir Ege kasabasıdır.'],
    [11, 'Bilecik', 'Söğüt', 'mausoleum', 1, 'Osmanlı Devleti\'nin kurulduğu yer olarak bilinen Söğüt buradadır.'],
    [12, 'Bingöl', 'Bingöl Dağları', 'mountain', 5, 'Bingöl, dağları ve serin yaylalarıyla bilinir.'],
    [13, 'Bitlis', 'Ahlat Selçuklu Mezarlığı', 'mausoleum', 4, 'Ahlat\'taki Selçuklu mezar taşları ve türbeleri Van Gölü kıyısındadır.'],
    [14, 'Bolu', 'Abant Gölü', 'lake', 1, 'Abant Gölü, özellikle sonbaharda renk renk görünür.'],
    [15, 'Burdur', 'Salda Gölü', 'lake', 3, 'Salda Gölü, berrak turkuaz suyu ve beyaz kumlarıyla tanınır.'],
    [16, 'Bursa', 'Ulu Cami', 'mosque', 0, 'Bursa, Osmanlı Devleti\'nin ilk başkentlerinden biridir.'],
    [17, 'Çanakkale', 'Truva', 'ruins', 5, 'Truva, efsanevi Truva Atı hikâyesiyle bilinen antik kenttir.'],
    [18, 'Çankırı', 'Ilgaz Dağı', 'mountain', 2, 'Ilgaz Dağı, kış turizmi ve ormanlarıyla bilinir.'],
    [19, 'Çorum', 'Hattuşa', 'ruins', 1, 'Hattuşa, Hititlerin başkentidir ve UNESCO Dünya Mirası listesindedir.'],
    [20, 'Denizli', 'Pamukkale', 'terraces', 3, 'Pamukkale\'nin beyaz travertenleri ve sıcak su havuzları dünyaca ünlüdür.'],
    [21, 'Diyarbakır', 'Diyarbakır Surları', 'castle', 1, 'Diyarbakır Surları, dünyanın en uzun şehir surlarından biridir.'],
    [22, 'Edirne', 'Selimiye Camii', 'mosque', 5, 'Selimiye Camii, Mimar Sinan\'ın ustalık eseri olarak anılır.'],
    [23, 'Elazığ', 'Hazar Gölü', 'lake', 4, 'Hazar Gölü, dağların arasındaki derin ve sakin bir göldür.'],
    [24, 'Erzincan', 'Girlevik Şelalesi', 'waterfall', 2, 'Girlevik Şelalesi, Fırat\'ın yakınında yer alan görkemli bir şelaledir.'],
    [25, 'Erzurum', 'Çifte Minareli Medrese', 'mosque', 4, 'Erzurum, Palandöken\'deki kayak pistleri ve tarihi medreseleriyle bilinir.'],
    [26, 'Eskişehir', 'Odunpazarı Evleri', 'houses', 5, 'Odunpazarı, Osmanlı dönemi ahşap evleriyle ünlü bir semttir.'],
    [27, 'Gaziantep', 'Gaziantep Kalesi', 'castle', 1, 'Gaziantep, baklavası ve mutfağıyla UNESCO Yaratıcı Şehirler ağındadır.'],
    [28, 'Giresun', 'Giresun Adası', 'sea', 2, 'Giresun, fındığıyla tanınır; kıyısında küçük bir ada vardır.'],
    [29, 'Gümüşhane', 'Karaca Mağarası', 'mountain', 0, 'Torul\'daki Karaca Mağarası, sarkıt ve dikitleriyle bilinir.'],
    [30, 'Hakkâri', 'Cilo ve Sat Dağları', 'mountain', 3, 'Cilo ve Sat Dağları, yüksek zirveleri ve buzullarıyla ünlüdür.'],
    [31, 'Hatay', 'Habib-i Neccar Camii', 'mosque', 1, 'Antakya, birçok medeniyetin ve lezzetin buluştuğu bir şehirdir.'],
    [32, 'Isparta', 'Eğirdir Gölü', 'lake', 5, 'Isparta, gülü ve lavantasıyla meşhurdur.'],
    [33, 'Mersin', 'Kızkalesi', 'seacastle', 3, 'Kızkalesi, denizin içinde yükselen eşsiz bir kaledir.'],
    [34, 'İstanbul', 'Ayasofya', 'mosque', 0, 'İstanbul, iki kıtayı birleştiren, tarihi çok zengin bir şehirdir.'],
    [35, 'İzmir', 'Saat Kulesi', 'tower', 3, 'Konak Meydanı\'ndaki Saat Kulesi İzmir\'in simgesidir; yakınındaki Efes Antik Kenti dünyaca ünlüdür.'],
    [36, 'Kars', 'Ani Harabeleri', 'ruins', 4, 'Ani, bir zamanlar "bin bir kilise şehri" olarak anılan UNESCO mirasıdır.'],
    [37, 'Kastamonu', 'Kastamonu Kalesi', 'castle', 2, 'Kastamonu, tarihi evleri ve doğal güzellikleriyle bilinir.'],
    [38, 'Kayseri', 'Erciyes Dağı', 'mountain', 0, 'Erciyes, İç Anadolu\'nun en yüksek dağı ve önemli bir kayak merkezidir.'],
    [39, 'Kırklareli', 'İğneada Longoz Ormanları', 'lake', 2, 'İğneada\'nın sular altında kalan longoz ormanları Türkiye\'de eşsizdir.'],
    [40, 'Kırşehir', 'Cacabey Medresesi', 'mosque', 1, 'Kırşehir, Ahi Evran\'ın şehri olarak bilinir.'],
    [41, 'Kocaeli', 'Kartepe', 'mountain', 3, 'Kartepe, İstanbul\'a yakın bir kış ve doğa turizmi merkezidir.'],
    [42, 'Konya', 'Mevlana Müzesi', 'mosque', 1, 'Konya, Mevlana\'nın şehridir; yeşil kubbesiyle bilinen türbe buradadır.'],
    [43, 'Kütahya', 'Aizanoi Zeus Tapınağı', 'ruins', 5, 'Aizanoi\'deki Zeus Tapınağı, Anadolu\'nun en iyi korunmuş tapınaklarındandır.'],
    [44, 'Malatya', 'Aslantepe', 'ruins', 1, 'Malatya, kayısısıyla meşhurdur; Aslantepe Höyüğü UNESCO listesindedir.'],
    [45, 'Manisa', 'Sardes Artemis Tapınağı', 'ruins', 0, 'Sardes, Lidya Krallığı\'nın başkentidir.'],
    [46, 'Kahramanmaraş', 'Maraş Kalesi', 'castle', 5, 'Kahramanmaraş, dondurmasıyla ün yapmıştır.'],
    [47, 'Mardin', 'Taş Evler', 'stonecity', 1, 'Mardin\'in taş evleri, Mezopotamya Ovası\'na bakar.'],
    [48, 'Muğla', 'Ölüdeniz', 'sea', 3, 'Ölüdeniz, turkuaz lagünü ve yamaç paraşütüyle ünlüdür.'],
    [49, 'Muş', 'Muş Ovası', 'fields', 1, 'Muş Ovası, Doğu Anadolu\'nun geniş ve verimli ovalarından biridir.'],
    [50, 'Nevşehir', 'Kapadokya', 'fairy', 0, 'Kapadokya, peri bacaları ve sabah gökyüzünü dolduran balonlarıyla ünlüdür.'],
    [51, 'Niğde', 'Aladağlar', 'mountain', 3, 'Aladağlar, dağcıların ve doğa severlerin sevdiği bir sıradağdır.'],
    [52, 'Ordu', 'Boztepe', 'sea', 2, 'Ordu, fındık bahçeleri ve Karadeniz manzarasıyla tanınır.'],
    [53, 'Rize', 'Çay Bahçeleri', 'tea', 2, 'Rize\'nin yamaçlarındaki çay bahçeleri Türkiye\'nin çay ihtiyacının büyük kısmını sağlar.'],
    [54, 'Sakarya', 'Sapanca Gölü', 'lake', 5, 'Sapanca Gölü, doğa ve dinlenme için sevilen bir yerdir.'],
    [55, 'Samsun', 'Bandırma Vapuru', 'ship', 0, 'Atatürk, 19 Mayıs 1919\'da Samsun\'a çıkarak kurtuluş mücadelesini başlattı.'],
    [56, 'Siirt', 'Botan Vadisi', 'mountain', 1, 'Siirt, fıstığı ve büryan kebabıyla bilinir.'],
    [57, 'Sinop', 'İnceburun Feneri', 'lighthouse', 4, 'Sinop, Türkiye\'nin en kuzeydeki noktasıdır.'],
    [58, 'Sivas', 'Divriği Ulu Camii', 'mosque', 3, 'Divriği Ulu Camii ve Darüşşifası, taş işçiliğiyle UNESCO listesindedir.'],
    [59, 'Tekirdağ', 'Marmara Kıyısı', 'sea', 5, 'Tekirdağ, köftesi ve ayçiçeği tarlalarıyla tanınır.'],
    [60, 'Tokat', 'Tokat Kalesi', 'castle', 2, 'Tokat, tarihi evleri ve zengin yemekleriyle bilinir.'],
    [61, 'Trabzon', 'Sümela Manastırı', 'cliff', 2, 'Sümela Manastırı, bir uçurumun yamacına inşa edilmiştir.'],
    [62, 'Tunceli', 'Munzur Vadisi', 'mountain', 2, 'Munzur Vadisi, doğal güzellikleri ve berrak suyuyla bilinir.'],
    [63, 'Şanlıurfa', 'Göbeklitepe', 'pillars', 1, 'Göbeklitepe, bilinen en eski tapınak alanlarından biridir ve yaklaşık 11 bin yıllıktır.'],
    [64, 'Uşak', 'Ulubey Kanyonu', 'mountain', 0, 'Ulubey Kanyonu, Türkiye\'nin en uzun kanyonlarından biridir.'],
    [65, 'Van', 'Akdamar Kilisesi', 'lakechurch', 3, 'Akdamar Adası\'ndaki kilise, Van Gölü\'nün ortasındadır.'],
    [66, 'Yozgat', 'Çamlık Milli Parkı', 'lake', 2, 'Çamlık Milli Parkı, çam ormanlarıyla ünlüdür.'],
    [67, 'Zonguldak', 'Gökgöl Mağarası', 'mountain', 4, 'Zonguldak, kömür madenciliğiyle özdeşleşmiş bir Karadeniz şehridir.'],
    [68, 'Aksaray', 'Ihlara Vadisi', 'mountain', 1, 'Ihlara Vadisi, kayalara oyulmuş kiliseleriyle ünlüdür.'],
    [69, 'Bayburt', 'Bayburt Kalesi', 'castle', 5, 'Bayburt Kalesi, Çoruh Nehri vadisine hâkim bir yerdedir.'],
    [70, 'Karaman', 'Karaman Kalesi', 'castle', 0, 'Karamanoğlu Mehmet Bey, Türkçeyi devlet dili ilan etmiştir.'],
    [71, 'Kırıkkale', 'Kızılırmak Kıyısı', 'fields', 2, 'Kızılırmak, Türkiye\'nin en uzun nehridir.'],
    [72, 'Batman', 'Hasankeyf', 'castle', 1, 'Hasankeyf, binlerce yıllık geçmişi olan kaya yerleşimidir.'],
    [73, 'Şırnak', 'Cudi Dağı', 'mountain', 4, 'Cudi Dağı, Nuh\'un Gemisi\'yle ilişkilendirilen bir dağdır.'],
    [74, 'Bartın', 'Amasra', 'seacastle', 3, 'Amasra, iki limanı ve tarihi surlarıyla sevilen bir sahil kasabasıdır.'],
    [75, 'Ardahan', 'Çıldır Gölü', 'lake', 4, 'Çıldır Gölü, kışın donar ve atlı kızaklar gölün üstünde gezer.'],
    [76, 'Iğdır', 'Ağrı Dağı Manzarası', 'mountain', 0, 'Iğdır\'dan Ağrı Dağı\'nın en güzel görüntüsü izlenir.'],
    [77, 'Yalova', 'Termal', 'sea', 5, 'Yalova, kaplıcaları ve Marmara kıyısıyla tanınır.'],
    [78, 'Karabük', 'Safranbolu Evleri', 'houses', 1, 'Safranbolu, UNESCO Dünya Mirası listesindeki ahşap evleriyle ünlüdür.'],
    [79, 'Kilis', 'Ravanda Kalesi', 'castle', 1, 'Kilis, Suriye sınırında küçük ama tarihi bir şehirdir.'],
    [80, 'Osmaniye', 'Karatepe-Aslantaş', 'ruins', 2, 'Karatepe-Aslantaş, Hitit dönemine ait bir açık hava müzesidir.'],
    [81, 'Düzce', 'Efteni Gölü', 'lake', 2, 'Efteni Gölü, kuşlarıyla ve sazlıklarıyla bilinen bir sulak alandır.'],
  ];
  var FINALE = [
    ['Büyük Final I', 'Kapadokya Sabahı', 'fairy', 2, 'Türkiye yolculuğunun son durakları: tebrikler!'],
    ['Büyük Final II', 'Boğaz Manzarası', 'mosque', 0, 'Türkiye\'nin dört bir yanını gezdin!'],
    ['Büyük Final III', 'Anadolu Zirvesi', 'mountain', 3, 'Harika bir yolculuk oldu, tebrikler!'],
  ];
  var WATER = { lake: 1, lakechurch: 1, seacastle: 1, lighthouse: 1, ship: 1, sea: 1 };

  function entry(g) {
    if (g < PROV.length) { var p = PROV[g]; return { plate: p[0], name: p[1], place: p[2], type: p[3], sky: p[4], fact: p[5] }; }
    var f = FINALE[(g - PROV.length) % FINALE.length];
    return { plate: 0, name: f[0], place: f[1], type: f[2], sky: f[3], fact: f[4] };
  }
  function gallery(i) { return Math.floor(i / PER); }
  function name(g) { return entry(g).name; }
  function info(g) { return entry(g); }

  // ---- küçük SVG yardımcıları ----
  function f1(n) { return Math.round(n * 10) / 10; }
  function R(x, y, w, h, fill, extra) { return '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="' + f1(w) + '" height="' + f1(h) + '" fill="' + fill + '"' + (extra || '') + '/>'; }
  function P(d, fill, extra) { return '<path d="' + d + '" fill="' + fill + '"' + (extra || '') + '/>'; }
  function Ci(x, y, r, fill, extra) { return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="' + fill + '"' + (extra || '') + '/>'; }
  function El(x, y, rx, ry, fill, extra) { return '<ellipse cx="' + f1(x) + '" cy="' + f1(y) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="' + fill + '"' + (extra || '') + '/>'; }
  function seeded(n) { var s = n * 9301 + 49297; return function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; }
  function arch(x, y, w, h, fill) { return P('M' + f1(x) + ' ' + f1(y + h) + 'V' + f1(y + w / 2) + 'a' + f1(w / 2) + ' ' + f1(w / 2) + ' 0 0 1 ' + f1(w) + ' 0V' + f1(y + h) + 'Z', fill); }

  // ---- yapılar (ortada, zemin GY) ----
  var LM = {
    mosque: function () {
      var x = 100, y = GY, o = '';
      o += R(x - 32, y - 20, 64, 20, C.stone) + R(x - 32, y - 4, 64, 4, C.shade);
      [-22, -8, 8, 22].forEach(function (d) { o += arch(x + d - 3, y - 15, 6, 11, C.dark); });
      o += P('M' + (x - 22) + ' ' + (y - 20) + 'a22 22 0 0 1 44 0Z', C.dome) + R(x - 1, y - 48, 2, 7, C.gold) + Ci(x, y - 49.5, 2.2, C.gold);
      o += P('M' + (x - 36) + ' ' + (y - 20) + 'a9 9 0 0 1 18 0Z', C.dome) + P('M' + (x + 18) + ' ' + (y - 20) + 'a9 9 0 0 1 18 0Z', C.dome);
      [-46, 46].forEach(function (d) {
        var mx = x + d;
        o += R(mx - 2.2, y - 54, 4.4, 54, C.stone) + R(mx - 4, y - 38, 8, 2.6, C.shade) + R(mx - 3.4, y - 54, 6.8, 2, C.shade) + P('M' + (mx - 3.2) + ' ' + (y - 54) + 'L' + mx + ' ' + (y - 68) + 'L' + (mx + 3.2) + ' ' + (y - 54) + 'Z', C.dome) + R(mx - 0.6, y - 72, 1.2, 5, C.gold);
      });
      return o;
    },
    tower: function () {
      var x = 100, y = GY, o = '';
      o += R(x - 14, y - 6, 28, 6, C.shade) + R(x - 10, y - 56, 20, 52, C.stone) + R(x - 12, y - 56, 24, 3, C.shade);
      o += P('M' + (x - 12) + ' ' + (y - 56) + 'L' + x + ' ' + (y - 76) + 'L' + (x + 12) + ' ' + (y - 56) + 'Z', C.roof);
      o += Ci(x, y - 42, 6.4, C.white, ' stroke="' + C.dark + '" stroke-width="1.2"') + '<path d="M' + x + ' ' + (y - 42) + 'V' + (y - 46.5) + 'M' + x + ' ' + (y - 42) + 'L' + (x + 3) + ' ' + (y - 40.5) + '" stroke="' + C.dark + '" stroke-width="1" fill="none"/>';
      o += arch(x - 3.5, y - 30, 7, 12, C.dark) + arch(x - 3.5, y - 16, 7, 10, C.dark);
      o += Ci(x, y - 79, 1.6, C.gold) + R(x - 18, y - 3, 36, 3, C.dark, ' opacity=".35"');
      return o;
    },
    mausoleum: function () {
      var x = 100, y = GY, o = '', i;
      o += R(x - 50, y - 5, 100, 5, C.shade) + R(x - 44, y - 10, 88, 5, C.stone);
      o += R(x - 38, y - 34, 76, 24, C.stone);
      for (i = 0; i < 11; i++) o += R(x - 36 + i * 7.1, y - 34, 2.6, 24, C.shade);
      o += R(x - 42, y - 39, 84, 5, C.stone) + R(x - 42, y - 36, 84, 1.5, C.shade);
      o += R(x - 56, y - 50, 11, 40, C.stone) + R(x + 45, y - 50, 11, 40, C.stone) + R(x - 57, y - 53, 13, 3.5, C.shade) + R(x + 44, y - 53, 13, 3.5, C.shade);
      o += R(x - 53, y - 44, 5, 8, C.dark, ' opacity=".5"') + R(x + 48, y - 44, 5, 8, C.dark, ' opacity=".5"');
      return o;
    },
    ruins: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 54) + ' ' + y + 'A54 30 0 0 1 ' + (x + 54) + ' ' + y + 'Z', C.shade) + P('M' + (x - 40) + ' ' + y + 'A40 20 0 0 1 ' + (x + 40) + ' ' + y + 'Z', C.dark, ' opacity=".35"');
      [[-42, 22], [-28, 32], [-14, 17], [0, 36], [14, 12], [28, 28], [42, 18]].forEach(function (c, k) {
        var cx = x + c[0], h = c[1];
        o += R(cx - 3.4, y - h, 6.8, h, C.stone) + R(cx - 4.6, y - h - 2, 9.2, 2.6, C.shade) + R(cx - 4.4, y - 2, 8.8, 2.6, C.shade);
        o += R(cx - 1.2, y - h, 1, h, C.shade, ' opacity=".6"');
        if (k % 3 === 1) o += P('M' + (cx - 4.6) + ' ' + (y - h - 2) + 'l1.6 -2 2 1.2 2 -1.6 1.6 1.8Z', C.stone);
      });
      o += R(x - 30, y - 42, 34, 4, C.stone) + R(x - 30, y - 38, 34, 1.4, C.shade);
      return o;
    },
    castle: function () {
      var x = 100, y = GY, o = '', i;
      o += P('M' + (x - 54) + ' ' + y + 'L' + (x - 36) + ' ' + (y - 18) + 'L' + (x - 22) + ' ' + (y - 28) + 'L' + (x + 4) + ' ' + (y - 24) + 'L' + (x + 30) + ' ' + (y - 30) + 'L' + (x + 54) + ' ' + y + 'Z', C.rock);
      o += P('M' + (x - 30) + ' ' + (y - 18) + 'L' + (x - 14) + ' ' + (y - 28) + 'L' + (x + 6) + ' ' + (y - 24) + 'L' + (x + 24) + ' ' + (y - 30) + 'L' + (x + 40) + ' ' + (y - 8) + 'L' + (x - 30) + ' ' + (y - 8) + 'Z', C.dark, ' opacity=".25"');
      o += R(x - 28, y - 50, 56, 22, C.stone);
      for (i = 0; i < 9; i++) o += R(x - 28 + i * 6.6, y - 54, 3.6, 4.5, C.stone);
      o += R(x - 36, y - 62, 14, 34, C.stone) + R(x + 22, y - 62, 14, 34, C.stone);
      o += P('M' + (x - 38) + ' ' + (y - 62) + 'L' + (x - 29) + ' ' + (y - 74) + 'L' + (x - 20) + ' ' + (y - 62) + 'Z', C.roof) + P('M' + (x + 20) + ' ' + (y - 62) + 'L' + (x + 29) + ' ' + (y - 74) + 'L' + (x + 38) + ' ' + (y - 62) + 'Z', C.roof);
      o += arch(x - 5, y - 44, 10, 16, C.dark) + arch(x - 32, y - 56, 5, 8, C.dark) + arch(x + 27, y - 56, 5, 8, C.dark);
      return o;
    },
    seacastle: function () {
      var x = 100, y = GY, o = '', i;
      o += El(x, y + 1, 46, 7, C.rock) + El(x, y - 1, 40, 5, C.green, ' opacity=".7"');
      o += R(x - 24, y - 26, 48, 24, C.stone);
      for (i = 0; i < 8; i++) o += R(x - 24 + i * 6.2, y - 30, 3.6, 4.5, C.stone);
      o += R(x - 32, y - 40, 12, 38, C.stone) + R(x + 20, y - 36, 12, 34, C.stone) + R(x - 12, y - 42, 12, 16, C.stone);
      o += P('M' + (x - 34) + ' ' + (y - 40) + 'L' + (x - 26) + ' ' + (y - 52) + 'L' + (x - 18) + ' ' + (y - 40) + 'Z', C.roof) + P('M' + (x + 18) + ' ' + (y - 36) + 'L' + (x + 26) + ' ' + (y - 47) + 'L' + (x + 34) + ' ' + (y - 36) + 'Z', C.roof);
      o += arch(x - 3, y - 20, 8, 15, C.dark) + arch(x - 29, y - 34, 5, 8, C.dark);
      return o;
    },
    heads: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 62) + ' ' + y + 'L' + (x - 24) + ' ' + (y - 30) + 'L' + (x + 24) + ' ' + (y - 30) + 'L' + (x + 62) + ' ' + y + 'Z', C.rock) + P('M' + (x - 30) + ' ' + (y - 24) + 'L' + (x - 14) + ' ' + (y - 30) + 'L' + (x + 14) + ' ' + (y - 30) + 'L' + (x + 36) + ' ' + (y - 18) + 'Z', C.dark, ' opacity=".2"');
      [-34, -17, 0, 17, 34].forEach(function (d, k) {
        var cx = x + d, hh = k === 2 ? 1.12 : 1;
        o += R(cx - 5.6, y - 42, 11.2, 14, C.shade) + R(cx - 6.6, y - 31, 13.2, 3.5, C.stone);
        o += El(cx, y - 50 * hh + 4, 5.2, 7.2 * hh, C.stone) + P('M' + (cx - 5.4) + ' ' + (y - 56 * hh + 4) + 'L' + cx + ' ' + (y - 63 * hh + 4) + 'L' + (cx + 5.4) + ' ' + (y - 56 * hh + 4) + 'Z', C.gold);
        o += R(cx - 3, y - 51 * hh + 4, 1.8, 1.3, C.dark) + R(cx + 1.4, y - 51 * hh + 4, 1.8, 1.3, C.dark) + R(cx - 0.6, y - 47 * hh + 4, 1.2, 3, C.dark, ' opacity=".5"');
      });
      return o;
    },
    fairy: function () {
      var x = 100, y = GY, o = '';
      [[-44, 34, 18], [-20, 52, 22], [8, 44, 20], [34, 58, 24], [58, 30, 15]].forEach(function (c, k) {
        var cx = x + c[0], h = c[1], w = c[2];
        o += P('M' + (cx - w / 2) + ' ' + y + 'L' + (cx - w * 0.15) + ' ' + (y - h) + 'L' + (cx + w * 0.15) + ' ' + (y - h) + 'L' + (cx + w / 2) + ' ' + y + 'Z', k % 2 ? C.shade : C.stone);
        o += P('M' + (cx - w * 0.3) + ' ' + (y - h) + 'a' + (w * 0.3) + ' ' + (w * 0.2) + ' 0 0 1 ' + (w * 0.6) + ' 0Z', C.dark);
        o += arch(cx - 1.3, y - h * 0.5, 2.6, 6, C.dark);
      });
      o += El(x, y + 1, 70, 4, C.dark, ' opacity=".18"');
      return o;
    },
    terraces: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 58) + ' ' + y + 'C' + (x - 50) + ' ' + (y - 20) + ' ' + (x - 30) + ' ' + (y - 44) + ' ' + (x - 6) + ' ' + (y - 48) + 'C' + (x + 20) + ' ' + (y - 50) + ' ' + (x + 48) + ' ' + (y - 24) + ' ' + (x + 60) + ' ' + y + 'Z', C.white);
      [[0, -38, 22, 5], [-10, -30, 30, 6.4], [8, -22, 36, 7.2], [-6, -14, 44, 8], [4, -6, 50, 8.6]].forEach(function (p) {
        o += El(x + p[0], y + p[1], p[2], p[3], '#7FDDD8', ' stroke="#fff" stroke-width="2.4"') + El(x + p[0], y + p[1] - 1, p[2] * 0.7, p[3] * 0.45, '#BFF2EE', ' opacity=".7"');
      });
      return o;
    },
    mountain: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 70) + ' ' + y + 'L' + (x - 18) + ' ' + (y - 58) + 'L' + (x - 4) + ' ' + (y - 46) + 'L' + (x + 12) + ' ' + (y - 70) + 'L' + (x + 72) + ' ' + y + 'Z', '#9A93CC');
      o += P('M' + (x + 12) + ' ' + (y - 70) + 'L' + (x + 72) + ' ' + y + 'L' + (x + 30) + ' ' + y + 'L' + (x + 14) + ' ' + (y - 34) + 'Z', '#7E78B8', ' opacity=".75"');
      o += P('M' + (x + 12) + ' ' + (y - 70) + 'L' + (x - 2) + ' ' + (y - 48) + 'L' + (x + 4) + ' ' + (y - 50) + 'L' + (x + 9) + ' ' + (y - 44) + 'L' + (x + 14) + ' ' + (y - 50) + 'L' + (x + 24) + ' ' + (y - 46) + 'Z', C.white);
      o += P('M' + (x - 18) + ' ' + (y - 58) + 'L' + (x - 28) + ' ' + (y - 42) + 'L' + (x - 22) + ' ' + (y - 44) + 'L' + (x - 17) + ' ' + (y - 39) + 'L' + (x - 11) + ' ' + (y - 45) + 'L' + (x - 4) + ' ' + (y - 46) + 'Z', C.white);
      return o;
    },
    houses: function () {
      var x = 100, y = GY, o = '';
      [[-48, 26, 22, 0], [-26, 34, 24, 1], [-2, 28, 24, 0], [22, 36, 26, 1], [46, 24, 22, 0]].forEach(function (h) {
        var cx = x + h[0], hh = h[1], w = h[2];
        o += R(cx - w / 2, y - hh, w, hh, h[3] ? C.stone : '#F1D7B0') + R(cx - w / 2 - 1.5, y - hh * 0.55, w + 3, 2.2, C.wood);
        o += P('M' + (cx - w / 2 - 3) + ' ' + (y - hh) + 'L' + cx + ' ' + (y - hh - 12) + 'L' + (cx + w / 2 + 3) + ' ' + (y - hh) + 'Z', C.roof);
        o += R(cx - w / 2 + 3, y - hh + 5, 5, 7, C.dark, ' opacity=".55"') + R(cx + w / 2 - 8, y - hh + 5, 5, 7, C.dark, ' opacity=".55"') + R(cx - 2.2, y - 9, 4.4, 9, C.wood);
        o += R(cx - w / 2, y - hh, 1.6, hh, C.wood, ' opacity=".7"') + R(cx + w / 2 - 1.6, y - hh, 1.6, hh, C.wood, ' opacity=".7"');
      });
      return o;
    },
    stonecity: function () {
      var x = 100, y = GY, o = '', i;
      for (i = 0; i < 5; i++) {
        var w = 34 + i * 10, hh = 13, yy = y - hh * (i + 1) + (4 - i) * 0 + 4;
        o += R(x - w / 2, y - hh * (5 - i), w, hh, i % 2 ? C.stone : '#EED5AE') + R(x - w / 2, y - hh * (5 - i), w, 2, C.shade);
        for (var k = 0; k < 4 + i; k++) o += arch(x - w / 2 + 5 + k * ((w - 10) / (3.4 + i)), y - hh * (5 - i) + 4, 4, 8, C.dark);
      }
      o += P('M' + (x - 9) + ' ' + (y - 65) + 'a9 9 0 0 1 18 0Z', C.dome) + R(x + 14, y - 80, 4.6, 16, C.stone) + P('M' + (x + 13.4) + ' ' + (y - 80) + 'L' + (x + 16.3) + ' ' + (y - 90) + 'L' + (x + 19.2) + ' ' + (y - 80) + 'Z', C.dome);
      return o;
    },
    lake: function () {
      var x = 100, y = GY, o = '';
      o += El(x, y + 2, 52, 7, '#6DA36E') + El(x, y - 1, 46, 6, '#7FBF7F');
      [[-26, 36], [-12, 46], [4, 38], [20, 48], [34, 32]].forEach(function (t, k) {
        var cx = x + t[0], h = t[1];
        o += R(cx - 1, y - 6, 2, 7, '#7A5A3E') + P('M' + (cx - 8) + ' ' + (y - 4) + 'L' + cx + ' ' + (y - h) + 'L' + (cx + 8) + ' ' + (y - 4) + 'Z', k % 2 ? '#3F8F5C' : '#4DA46B') + P('M' + (cx - 6) + ' ' + (y - h * 0.45) + 'L' + cx + ' ' + (y - h * 0.9) + 'L' + (cx + 6) + ' ' + (y - h * 0.45) + 'Z', 'rgba(255,255,255,.12)');
      });
      return o;
    },
    lakechurch: function () {
      var x = 100, y = GY, o = '';
      o += El(x, y + 2, 46, 7, '#6DA36E') + El(x, y - 1, 40, 6, '#86C586');
      o += R(x - 14, y - 22, 28, 22, C.stone) + R(x - 16, y - 4, 32, 4, C.shade);
      o += R(x - 8, y - 38, 16, 18, C.stone) + P('M' + (x - 9) + ' ' + (y - 38) + 'L' + x + ' ' + (y - 54) + 'L' + (x + 9) + ' ' + (y - 38) + 'Z', C.dome) + R(x - 0.6, y - 58, 1.2, 5, C.gold);
      o += P('M' + (x - 14) + ' ' + (y - 22) + 'L' + (x - 7) + ' ' + (y - 29) + 'L' + (x + 7) + ' ' + (y - 29) + 'L' + (x + 14) + ' ' + (y - 22) + 'Z', C.dome, ' opacity=".8"') + arch(x - 2.4, y - 12, 4.8, 9, C.dark) + arch(x - 2, y - 33, 4, 8, C.dark);
      o += Ci(x + 30, y - 12, 7, '#E986A0') + Ci(x + 25, y - 15, 5, '#F2A3B6') + R(x + 29.4, y - 6, 1.6, 7, '#7A5A3E');
      return o;
    },
    tea: function () {
      var x = 100, y = GY, o = '', i, j;
      o += P('M' + (x - 70) + ' ' + y + 'C' + (x - 40) + ' ' + (y - 40) + ' ' + (x + 20) + ' ' + (y - 60) + ' ' + (x + 70) + ' ' + y + 'Z', '#8BCB7C');
      for (i = 0; i < 4; i++) {
        var by = y - 10 - i * 11, wid = 56 - i * 10;
        o += P('M' + (x - wid) + ' ' + by + 'Q' + x + ' ' + (by - 12) + ' ' + (x + wid) + ' ' + by + 'L' + (x + wid - 4) + ' ' + (by + 8) + 'Q' + x + ' ' + (by - 4) + ' ' + (x - wid + 4) + ' ' + (by + 8) + 'Z', i % 2 ? '#5DAF63' : '#6DBB6B');
        for (j = 0; j < 7; j++) o += Ci(x - wid + 6 + j * ((wid * 2 - 12) / 6.2), by - 4 - Math.sin(j / 6.2 * Math.PI) * 6 + 4, 2.6, '#3F8F52', ' opacity=".55"');
      }
      o += R(x + 6, y - 50, 12, 9, C.stone) + P('M' + (x + 4) + ' ' + (y - 50) + 'L' + (x + 12) + ' ' + (y - 58) + 'L' + (x + 20) + ' ' + (y - 50) + 'Z', C.roof) + R(x + 10, y - 46, 4, 5, C.dark, ' opacity=".6"');
      return o;
    },
    lighthouse: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 36) + ' ' + (y + 4) + 'Q' + (x - 22) + ' ' + (y - 14) + ' ' + (x - 8) + ' ' + (y - 8) + 'L' + (x + 40) + ' ' + (y + 4) + 'Z', '#8F7B6B') + P('M' + (x - 18) + ' ' + (y + 4) + 'Q' + (x + 4) + ' ' + (y - 12) + ' ' + (x + 24) + ' ' + (y + 4) + 'Z', '#A38F7C');
      o += P('M' + (x - 9) + ' ' + (y - 6) + 'L' + (x - 5.5) + ' ' + (y - 58) + 'L' + (x + 5.5) + ' ' + (y - 58) + 'L' + (x + 9) + ' ' + (y - 6) + 'Z', '#FFFFFF');
      [[-34, 8], [-20, 8], [-6, 8]].forEach(function (b) { o += P('M' + (x - 8 + (b[0] + 34) * 0.045) + ' ' + (y + b[0] + 4) + 'h' + (16 - (b[0] + 34) * 0.1) + 'l-0.8 7h' + (-(14.4 - (b[0] + 34) * 0.1)) + 'Z', '#E4534A'); });
      o += R(x - 8, y - 62, 16, 5, '#44505F') + R(x - 5, y - 70, 10, 9, '#FFF2B0') + P('M' + (x - 7) + ' ' + (y - 70) + 'L' + x + ' ' + (y - 79) + 'L' + (x + 7) + ' ' + (y - 70) + 'Z', '#E4534A');
      o += P('M' + (x + 5) + ' ' + (y - 66) + 'L' + (x + 70) + ' ' + (y - 80) + 'L' + (x + 70) + ' ' + (y - 50) + 'Z', 'rgba(255,244,190,.35)');
      return o;
    },
    ship: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 46) + ' ' + (y - 12) + 'L' + (x + 48) + ' ' + (y - 12) + 'L' + (x + 38) + ' ' + (y + 4) + 'L' + (x - 36) + ' ' + (y + 4) + 'Z', '#3B4660') + R(x - 46, y - 14, 94, 3, '#E4534A');
      o += R(x - 28, y - 26, 48, 12, '#FBF1E0') + R(x - 18, y - 36, 28, 10, '#FBF1E0') + R(x - 12, y - 33, 4, 4, '#44505F') + R(x - 4, y - 33, 4, 4, '#44505F') + R(x + 4, y - 33, 4, 4, '#44505F');
      o += R(x - 8, y - 52, 9, 17, '#2F3A52') + R(x - 8, y - 46, 9, 3, '#E4534A') + R(x - 31, y - 46, 1.6, 20, '#6B5645') + R(x + 24, y - 44, 1.6, 18, '#6B5645');
      o += Ci(x - 6, y - 58, 4, 'rgba(255,255,255,.7)') + Ci(x + 3, y - 64, 5, 'rgba(255,255,255,.55)') + Ci(x + 14, y - 70, 6, 'rgba(255,255,255,.4)');
      o += P('M' + (x + 24) + ' ' + (y - 44) + 'L' + (x + 38) + ' ' + (y - 40) + 'L' + (x + 24) + ' ' + (y - 36) + 'Z', '#E4534A');
      return o;
    },
    cliff: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 58) + ' ' + y + 'L' + (x - 40) + ' ' + (y - 64) + 'L' + (x - 6) + ' ' + (y - 84) + 'L' + (x + 30) + ' ' + (y - 70) + 'L' + (x + 60) + ' ' + y + 'Z', '#B79A83') + P('M' + (x + 4) + ' ' + (y - 80) + 'L' + (x + 30) + ' ' + (y - 70) + 'L' + (x + 60) + ' ' + y + 'L' + (x + 20) + ' ' + y + 'Z', '#9A7E69', ' opacity=".7"');
      o += R(x - 24, y - 46, 38, 4, '#8B6E58') + R(x - 22, y - 62, 32, 16, C.stone) + R(x - 12, y - 74, 22, 12, '#F2DDBB') + P('M' + (x - 24) + ' ' + (y - 62) + 'L' + (x - 6) + ' ' + (y - 69) + 'L' + (x + 12) + ' ' + (y - 62) + 'Z', C.roof) + P('M' + (x - 14) + ' ' + (y - 74) + 'L' + (x - 1) + ' ' + (y - 81) + 'L' + (x + 12) + ' ' + (y - 74) + 'Z', C.roof);
      [-18, -9, 0, 7].forEach(function (d) { o += arch(x + d - 1.4, y - 58, 2.8, 8, C.dark); });
      o += arch(x - 3, y - 71, 3, 6, C.dark);
      [-52, 44, 52].forEach(function (d, k) { o += P('M' + (x + d - 6) + ' ' + (y + 2) + 'L' + (x + d) + ' ' + (y - 18 - k * 3) + 'L' + (x + d + 6) + ' ' + (y + 2) + 'Z', '#3F8F5C'); });
      return o;
    },
    pillars: function () {
      var x = 100, y = GY, o = '';
      o += El(x, y - 2, 62, 11, '#D9B88A') + El(x, y - 3, 52, 8, '#E8CCA0');
      [[-42, 0.8], [-24, 0.95], [0, 1.2], [24, 0.95], [42, 0.8]].forEach(function (p, k) {
        var cx = x + p[0], s = p[1], ty = y - 6 + (k === 2 ? 4 : 0);
        o += R(cx - 3.6 * s, ty - 40 * s, 7.2 * s, 40 * s, k % 2 ? C.stone : '#EFD9B4') + R(cx - 9 * s, ty - 46 * s, 18 * s, 7.5 * s, C.stone) + R(cx - 9 * s, ty - 41 * s, 18 * s, 1.6 * s, C.shade);
        o += R(cx - 1 * s, ty - 34 * s, 2 * s, 12 * s, C.dark, ' opacity=".35"');
      });
      return o;
    },
    bridge: function () {
      var x = 100, y = GY, o = '', i;
      o += R(x - 68, y - 26, 136, 9, C.stone) + R(x - 68, y - 28, 136, 2.4, C.shade);
      for (i = 0; i < 12; i++) o += R(x - 66 + i * 11.4, y - 32, 5.2, 5, C.stone);
      o += R(x - 68, y - 17, 136, 17, C.stone);
      [-44, -4, 36].forEach(function (d) { o += P('M' + (x + d - 14) + ' ' + y + 'V' + (y - 8) + 'A14 11 0 0 1 ' + (x + d + 14) + ' ' + (y - 8) + 'V' + y + 'Z', '#7F6A5A'); });
      o += R(x - 68, y - 4, 136, 4, C.dark, ' opacity=".18"');
      return o;
    },
    waterfall: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 62) + ' ' + y + 'L' + (x - 50) + ' ' + (y - 60) + 'L' + (x - 12) + ' ' + (y - 66) + 'L' + (x - 6) + ' ' + y + 'Z', '#9A8470') + P('M' + (x + 6) + ' ' + y + 'L' + (x + 10) + ' ' + (y - 66) + 'L' + (x + 52) + ' ' + (y - 58) + 'L' + (x + 64) + ' ' + y + 'Z', '#A6907B');
      o += R(x - 12, y - 66, 22, 4, '#7FD0E6') + P('M' + (x - 12) + ' ' + (y - 66) + 'L' + (x + 10) + ' ' + (y - 66) + 'L' + (x + 8) + ' ' + (y - 6) + 'L' + (x - 9) + ' ' + (y - 6) + 'Z', '#F4FBFF');
      [-6, -1, 4].forEach(function (d) { o += R(x + d, y - 62, 1.4, 54, '#BEE6F2', ' opacity=".8"'); });
      o += El(x, y - 4, 22, 6, '#9FE0EF') + El(x, y - 6, 16, 4, '#fff', ' opacity=".7"');
      [-40, 40].forEach(function (d) { o += P('M' + (x + d - 7) + ' ' + (y - 40) + 'L' + (x + d) + ' ' + (y - 66) + 'L' + (x + d + 7) + ' ' + (y - 40) + 'Z', '#3F8F5C'); });
      return o;
    },
    fields: function () {
      var x = 100, y = GY, o = '', i, j;
      o += P('M' + (x - 70) + ' ' + y + 'Q' + (x - 20) + ' ' + (y - 34) + ' ' + x + ' ' + (y - 24) + 'T' + (x + 70) + ' ' + y + 'Z', '#F2CE6E');
      for (i = 0; i < 4; i++) {
        o += P('M' + (x - 66 + i * 6) + ' ' + (y - 2 - i * 5) + 'Q' + x + ' ' + (y - 14 - i * 8) + ' ' + (x + 66 - i * 6) + ' ' + (y - 2 - i * 5), 'none', ' stroke="#E2B24C" stroke-width="2.4"');
      }
      for (j = 0; j < 9; j++) { var wx = x - 48 + j * 12; o += R(wx, y - 20 - (j % 3) * 3, 1.2, 14, '#C98A2E') + El(wx + 0.6, y - 22 - (j % 3) * 3, 2.4, 5, '#EBBF55'); }
      o += R(x + 18, y - 44, 1.4, 22, '#6B5645') + P('M' + (x + 19.4) + ' ' + (y - 44) + 'L' + (x + 34) + ' ' + (y - 39) + 'L' + (x + 19.4) + ' ' + (y - 34) + 'Z', '#E4534A');
      return o;
    },
    sea: function () {
      var x = 100, y = GY, o = '';
      o += P('M' + (x - 60) + ' ' + (y + 3) + 'Q' + (x - 40) + ' ' + (y - 16) + ' ' + (x - 18) + ' ' + (y + 3) + 'Z', '#7BA76E') + P('M' + (x - 8) + ' ' + (y + 3) + 'Q' + (x + 18) + ' ' + (y - 24) + ' ' + (x + 44) + ' ' + (y + 3) + 'Z', '#6C9C63');
      o += R(x + 6, y - 24, 1.4, 16, '#6B5645') + P('M' + (x + 7.4) + ' ' + (y - 24) + 'L' + (x + 24) + ' ' + (y - 10) + 'L' + (x + 7.4) + ' ' + (y - 10) + 'Z', '#FFF7EA') + P('M' + (x + 4.6) + ' ' + (y - 20) + 'L' + (x + 4.6) + ' ' + (y - 10) + 'L' + (x - 6) + ' ' + (y - 10) + 'Z', '#FDE0C8') + P('M' + (x - 12) + ' ' + (y - 8) + 'L' + (x + 28) + ' ' + (y - 8) + 'L' + (x + 22) + ' ' + (y - 2) + 'L' + (x - 6) + ' ' + (y - 2) + 'Z', '#B7794E');
      o += El(x - 34, y - 6, 6, 2.6, '#E7B67A') + El(x - 38, y - 12, 1.2, 4, '#7A5A3E');
      return o;
    },
  };

  // ---- sahne katmanları ----
  function shade(hex, k) { // k>0 açar, k<0 koyulaştırır
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function m(c) { return Math.max(0, Math.min(255, Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)))); }
    return '#' + ((1 << 24) + (m(r) << 16) + (m(g) << 8) + m(b)).toString(16).slice(1);
  }
  function cloud(x, y, w, a) {
    return '<g opacity="' + (a || 0.9) + '">' + El(x, y + 1.6, w * 0.5, w * 0.1, 'rgba(240,150,150,.35)') + El(x - w * 0.22, y, w * 0.26, w * 0.14, '#fff') + El(x + w * 0.12, y - w * 0.04, w * 0.3, w * 0.17, '#fff') + El(x + w * 0.34, y + 0.4, w * 0.2, w * 0.11, '#fff') + El(x, y + w * 0.05, w * 0.5, w * 0.09, '#fff') + '</g>';
  }
  function tree(t, base, h, kind, col) {
    if (kind) { // yuvarlak yapraklı ağaç
      return R(t - 1.2, base - h * 0.45, 2.4, h * 0.5, 'rgba(60,35,30,.7)') + Ci(t, base - h * 0.62, h * 0.3, shade(col, -0.25)) + Ci(t - h * 0.12, base - h * 0.7, h * 0.22, col) + Ci(t + h * 0.14, base - h * 0.55, h * 0.2, shade(col, -0.12)) + Ci(t - h * 0.1, base - h * 0.76, h * 0.1, shade(col, 0.35), ' opacity=".6"');
    }
    return R(t - 1, base - 3, 2, 5, 'rgba(60,35,30,.7)') + P('M' + (t - h * 0.3) + ' ' + base + 'L' + t + ' ' + (base - h) + 'L' + (t + h * 0.3) + ' ' + base + 'Z', shade(col, -0.3)) + P('M' + (t - h * 0.26) + ' ' + (base - h * 0.38) + 'L' + t + ' ' + (base - h * 0.96) + 'L' + (t + h * 0.02) + ' ' + (base - h * 0.38) + 'Z', shade(col, 0.1), ' opacity=".8"') + P('M' + t + ' ' + (base - h) + 'L' + (t + h * 0.3) + ' ' + base + 'L' + (t + h * 0.04) + ' ' + base + 'Z', 'rgba(20,10,30,.22)');
  }
  function sceneLayers(g, id, bg) {
    var e = entry(g), pal = SK[e.sky % SK.length], rnd = seeded(e.plate || (g + 7)), water = !!WATER[e.type];
    var L = [], xx, k, i;
    var sunX = 56 + rnd() * 88, sunY = 56 + rnd() * 10;
    // 0 gökyüzü, güneş ışığı, ışık huzmeleri, bulutlar
    var sky = bg ? '<rect x="-60" y="-70" width="320" height="220" fill="url(#sk' + id + ')"/>' : '<rect width="200" height="150" fill="url(#sk' + id + ')"/>';
    sky += '<circle cx="' + f1(sunX) + '" cy="' + f1(sunY) + '" r="64" fill="url(#sg' + id + ')"/>';
    for (i = 0; i < 5; i++) { var an = (-100 + i * 40 + rnd() * 20) * Math.PI / 180; sky += '<path d="M' + f1(sunX) + ' ' + f1(sunY) + 'L' + f1(sunX + Math.cos(an - 0.07) * 150) + ' ' + f1(sunY + Math.sin(an - 0.07) * 150) + 'L' + f1(sunX + Math.cos(an + 0.07) * 150) + ' ' + f1(sunY + Math.sin(an + 0.07) * 150) + 'Z" fill="#fff" opacity=".10"/>'; }
    sky += Ci(sunX, sunY, 11, pal.sun) + Ci(sunX, sunY, 8, '#FFFDF2');
    sky += cloud(34 + rnd() * 30, 28 + rnd() * 8, 52, 0.9) + cloud(120 + rnd() * 30, 20 + rnd() * 8, 60, 0.85) + cloud(176, 46 + rnd() * 6, 34, 0.7) + cloud(70 + rnd() * 20, 52 + rnd() * 6, 30, 0.6);
    L[0] = sky;
    // 1 uzak tepeler (iki sıra, hava perspektifi)
    var d = 'M0 96', d1 = 'M0 100';
    for (xx = 0; xx <= 200; xx += 16) { d += 'L' + xx + ' ' + f1(70 + rnd() * 18 - (xx > 60 && xx < 140 ? 6 : 0)); d1 += 'L' + xx + ' ' + f1(86 + rnd() * 10); }
    L[1] = P(d + 'L200 150L0 150Z', shade(pal.far, 0.35), ' opacity=".8"') + P(d1 + 'L200 150L0 150Z', 'url(#hf' + id + ')') + R(0, 78, 200, 34, 'url(#hz' + id + ')');
    // 2 ara plan (su ya da tepeler)
    if (water) {
      var rl = '';
      for (i = 0; i < 7; i++) rl += El(sunX + (rnd() - 0.5) * 8, 108 + i * 5.2, 12 - i * 0.9 + rnd() * 4, 1.1, pal.sun, ' opacity="' + f1(0.7 - i * 0.08) + '"');
      L[2] = R(0, 104, 200, 46, 'url(#wt' + id + ')') + R(0, 104, 200, 2.4, '#fff', ' opacity=".45"') + R(0, 104, 200, 12, 'url(#hz' + id + ')') +
        '<use href="#lm' + id + '" transform="translate(0,' + GY + ') scale(1,-.5) translate(0,' + (-GY) + ')" opacity=".28"/>' +
        '<g stroke="#fff" stroke-opacity=".55" stroke-width=".9" fill="none" stroke-linecap="round"><path d="M18 120h26M120 116h34M62 128h40M146 132h30M10 138h24M96 122h18M70 112h12"/></g>' + rl;
    } else {
      var d2 = 'M0 112';
      for (xx = 0; xx <= 200; xx += 25) d2 += 'Q' + (xx + 12) + ' ' + f1(92 + rnd() * 14) + ' ' + (xx + 25) + ' ' + f1(106 + rnd() * 6);
      L[2] = P(d2 + 'L200 150L0 150Z', 'url(#hm' + id + ')') + R(0, 100, 200, 14, 'url(#hz' + id + ')', ' opacity=".7"');
    }
    // 3 ön plan: tepe, ağaçlar, çalılar, çiçekler, savrulan yapraklar
    var fg = P('M0 128Q40 108 84 122T200 116L200 150L0 150Z', 'url(#hg' + id + ')') + P('M0 140Q60 126 130 138T200 134L200 150L0 150Z', shade(pal.fore, -0.28), ' opacity=".9"');
    var t, kinds = [1, 0, 1, 0, 1, 0];
    for (k = 0; k < 6; k++) {
      t = (k < 3 ? 6 + k * 24 : 138 + (k - 3) * 24) + rnd() * 8; var h = 24 + rnd() * 18, base = 128 + rnd() * 8;
      fg += tree(t, base, h, kinds[(k + g) % 6], k % 2 ? shade(pal.fore, 0.18) : shade(pal.mid2, -0.3));
    }
    for (k = 0; k < 7; k++) fg += El(8 + rnd() * 184, 140 + rnd() * 8, 6 + rnd() * 6, 3 + rnd() * 2, shade(pal.fore, -0.35), ' opacity=".7"');
    for (k = 0; k < 12; k++) fg += Ci(8 + rnd() * 184, 134 + rnd() * 14, 1.1 + rnd() * 0.7, k % 2 ? '#FFD27A' : '#FF9A74', ' opacity=".95"');
    for (k = 0; k < 6; k++) { var lx = 10 + rnd() * 180, ly = 60 + rnd() * 70; fg += El(lx, ly, 2.2, 1.1, k % 2 ? '#F28A3C' : '#D9532F', ' transform="rotate(' + Math.round(rnd() * 90 - 45) + ' ' + f1(lx) + ' ' + f1(ly) + ')" opacity=".85"'); }
    if (bg) fg += R(-60, 138, 320, 160, shade(pal.fore, -0.3)) + P('M-60 150Q40 136 100 146T260 140L260 300L-60 300Z', 'url(#hg' + id + ')') + P('M-60 190Q60 172 130 186T260 180L260 300L-60 300Z', shade(pal.fore, -0.38));
    L[3] = fg;
    // 4 yapı (gölge + ışık/gölge yüzü)
    L[4] = LM[e.type] ? El(100, GY + 1.6, 52, 3.4, 'rgba(30,15,40,.30)') + '<use href="#lm' + id + '"/>' + '<use href="#lm' + id + '" filter="url(#ls' + id + ')" opacity=".9"/>' : '';
    // 5 ayrıntılar
    var det = '<g stroke="#4B3C60" stroke-opacity=".6" stroke-width="1.1" fill="none" stroke-linecap="round"><path d="M150 40q3 -3 6 0q3 -3 6 0M166 50q2 -2 4 0q2 -2 4 0M132 34q2 -2 4 0q2 -2 4 0"/></g>';
    if (e.type === 'fairy') {
      [[50, 38, '#F2705F'], [150, 30, '#14A8AE'], [118, 22, '#E9B03A'], [30, 58, '#8E7CE6']].forEach(function (b) {
        det += Ci(b[0], b[1], 7.4, b[2]) + P('M' + (b[0] - 7) + ' ' + (b[1] + 2) + 'Q' + b[0] + ' ' + (b[1] + 14) + ' ' + (b[0] + 7) + ' ' + (b[1] + 2), b[2], ' opacity=".9"') + Ci(b[0] - 2, b[1] - 2.4, 2.4, '#fff', ' opacity=".35"') + R(b[0] - 2.4, b[1] + 11, 4.8, 3.4, '#8A5A3A') + '<path d="M' + (b[0] - 5) + ' ' + (b[1] + 6) + 'L' + (b[0] - 2) + ' ' + (b[1] + 11) + 'M' + (b[0] + 5) + ' ' + (b[1] + 6) + 'L' + (b[0] + 2) + ' ' + (b[1] + 11) + '" stroke="#6B5645" stroke-width=".7"/>';
      });
    }
    for (k = 0; k < 6; k++) det += P('M' + f1(20 + rnd() * 160) + ' ' + f1(20 + rnd() * 70) + 'm0 -3l.9 2.1 2.1 .9-2.1 .9-.9 2.1-.9-2.1-2.1-.9 2.1-.9Z', '#fff', ' opacity=".8"');
    L[5] = det;
    var plateSvg = '';
    if (e.plate) {
      var label = (e.plate < 10 ? '0' : '') + e.plate;
      plateSvg = '<g><rect x="6" y="6" width="31" height="14" rx="3" fill="#fff" stroke="#2D5BB0" stroke-width="1.4"/><rect x="6" y="6" width="8" height="14" rx="3" fill="#2D5BB0"/><rect x="11" y="6" width="3" height="14" fill="#2D5BB0"/><text x="10" y="16.6" font-size="4.6" font-weight="900" fill="#fff" text-anchor="middle" font-family="Inter,Arial,sans-serif">TR</text><text x="26" y="17.2" font-size="9.6" font-weight="900" fill="#1E3350" text-anchor="middle" font-family="Inter,Arial,sans-serif">' + label + '</text></g>';
    }
    return { layers: L, pal: pal, plate: plateSvg, sunX: sunX, sunY: sunY, type: e.type, bg: bg };
  }

  function defsFor(id, pal, sc) {
    function lg(n, c1, c2, c3) { return '<linearGradient id="' + n + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + c1 + '"/>' + (c3 ? '<stop offset=".5" stop-color="' + c2 + '"/><stop offset="1" stop-color="' + c3 + '"/>' : '<stop offset="1" stop-color="' + c2 + '"/>') + '</linearGradient>'; }
    return '<defs>' + lg('sk', pal.top, pal.mid, pal.hor) +
      '<radialGradient id="sg' + id + '"><stop offset="0" stop-color="' + pal.sun + '" stop-opacity=".9"/><stop offset=".35" stop-color="' + pal.sun + '" stop-opacity=".35"/><stop offset="1" stop-color="' + pal.sun + '" stop-opacity="0"/></radialGradient>' +
      lg('hf', shade(pal.far, 0.1), shade(pal.far, -0.12)) + lg('hm', shade(pal.mid2, 0.18), shade(pal.mid2, -0.18)) + lg('hg', shade(pal.fore, 0.12), shade(pal.fore, -0.3)) + lg('wt', shade(pal.water, 0.25), shade(pal.water, -0.12)) +
      '<linearGradient id="hz' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + pal.hor + '" stop-opacity="0"/><stop offset=".6" stop-color="' + pal.hor + '" stop-opacity=".55"/><stop offset="1" stop-color="' + pal.hor + '" stop-opacity="0"/></linearGradient>' +
      '<linearGradient id="lt' + id + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".0"/><stop offset="1" stop-color="#1B1030" stop-opacity=".22"/></linearGradient>' +
      '<radialGradient id="vg' + id + '" cx=".5" cy=".5" r=".75"><stop offset=".6" stop-color="#1B1030" stop-opacity="0"/><stop offset="1" stop-color="#1B1030" stop-opacity=".28"/></radialGradient>' +
      // yapının sağ yüzünü gölgeleyen filtre: şekli koyu renge boyar, ışığın geldiği (sol) kenarı açık bırakır
      '<filter id="ls' + id + '" x="0" y="0" width="1" height="1"><feColorMatrix type="matrix" values="0 0 0 0 .1  0 0 0 0 .05  0 0 0 0 .2  0 0 0 .32 0"/><feOffset dx="-1.4" dy="0" result="o"/><feComposite in="SourceGraphic" in2="o" operator="out"/></filter>' +
      '<clipPath id="cp' + id + '"><rect x="' + (sc.bg ? -60 : 0) + '" y="' + (sc.bg ? -70 : 0) + '" width="' + (sc.bg ? 320 : 200) + '" height="' + (sc.bg ? 400 : 150) + '" rx="' + (sc.bg ? 0 : 14) + '"/></clipPath></defs>';
  }

  // painted: 0..PER boyanmış katman; highlight: yeni eklenen katman; opts.full: köşesiz tam ekran sahne
  var uid = 0;
  function svg(g, painted, opts) {
    opts = opts || {};
    if (opts.bg) painted = PER;
    var id = g + '_' + (++uid), sc = sceneLayers(g, id, opts.bg), pal = sc.pal, lm = LM[sc.type];
    var out = '<svg class="painting scene" viewBox="' + (opts.bg ? '35 -12 130 281" preserveAspectRatio="xMidYMid slice' : '0 0 200 150') + '" aria-hidden="true">' + defsFor(id, pal, sc);
    if (lm) out = out.replace('</defs>', '<g id="lm' + id + '">' + lm() + '</g></defs>');
    out += '<g clip-path="url(#cp' + id + ')"><rect x="-60" y="-70" width="320" height="400" fill="#EEF2F7"/>';
    sc.layers.forEach(function (l, i) {
      if (opts.lite && i !== 0 && i !== 5) return;
      var on = i < painted;
      out += '<g class="lay' + (on ? ' on' : ' ghost') + (opts.highlight === i ? ' fresh' : '') + '">' + l + '</g>';
    });
    if (painted > 0 && !opts.lite) out += '<rect width="200" height="150" fill="url(#lt' + id + ')"/><circle cx="' + f1(sc.sunX) + '" cy="' + f1(sc.sunY) + '" r="90" fill="url(#sg' + id + ')" opacity=".35" style="mix-blend-mode:soft-light"/><rect width="200" height="150" fill="url(#vg' + id + ')"/>';
    out += (opts.bg ? '' : sc.plate) + '</g>';
    if (painted >= PER && !opts.bg) out += '<rect width="200" height="150" rx="14" fill="none" stroke="#E9B03A" stroke-width="3"/>';
    out += '</svg>';
    return out;
  }

  // Tam ekran arka plan: hazır görsel varsa onu, yoksa kodla çizilen sahneyi kullanır
  function bg(g, painted) {
    var e = entry(g), pal = SK[e.sky % SK.length], img = (root.CW_IL_IMAGES || {})[e.plate];
    var style = 'background:linear-gradient(180deg,' + pal.top + ' 0%,' + pal.top + ' 30%,' + shade(pal.fore, -0.1) + ' 72%,' + shade(pal.fore, -0.3) + ' 100%)';
    if (img) return '<div class="scene-bg" style="' + style + '"><img class="scene-img" src="' + img + '" alt=""></div>';
    return '<div class="scene-bg" style="' + style + '">' + svg(g, painted, { bg: true }) + '</div>';
  }

  root.CWArt = { PER: PER, gallery: gallery, name: name, info: info, svg: svg, bg: bg, count: PROV.length + FINALE.length, palette: function (g) { var p = SK[entry(g).sky % SK.length]; return [p.mid2, p.far, p.top, '#E9B03A']; } };
})(window);
