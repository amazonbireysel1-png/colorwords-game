/*
 * Color Words – ses sistemi. Tüm sesler Web Audio API ile çalışma anında sentezlenir
 * (harici ses dosyası yok → lisans sorunu yok, APK küçük kalır).
 */
(function (root) {
  'use strict';
  var ctx = null, master = null, sfxBus = null, musicBus = null;
  var state = { sfx: true, music: true, musicTimer: null, step: 0, nextTime: 0, playing: false };

  function ensure() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
    sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(master);
    musicBus = ctx.createGain(); musicBus.gain.value = 0.0; musicBus.connect(master);
    return ctx;
  }
  function resume() { if (ensure() && ctx.state === 'suspended') ctx.resume(); }

  // Temel ton: hafif zarflı osilatör
  function tone(freq, t0, dur, opts) {
    opts = opts || {};
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = opts.type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (opts.slide) o.frequency.exponentialRampToValueAtTime(opts.slide, t0 + dur);
    var peak = opts.gain != null ? opts.gain : 0.3;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + (opts.attack || 0.008));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(opts.bus || sfxBus);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }
  // Tatlı "çan" sesi: temel + oktav üstü harmonik
  function bell(freq, t0, dur, gain, bus) {
    tone(freq, t0, dur, { type: 'sine', gain: gain, bus: bus });
    tone(freq * 2, t0, dur * 0.6, { type: 'sine', gain: gain * 0.35, bus: bus });
    tone(freq * 3.01, t0, dur * 0.35, { type: 'triangle', gain: gain * 0.12, bus: bus });
  }
  function noise(t0, dur, gain, hp) {
    var len = Math.floor(ctx.sampleRate * dur), buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    var s = ctx.createBufferSource(); s.buffer = buf;
    var f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp || 3000;
    var g = ctx.createGain(); g.gain.value = gain;
    s.connect(f); f.connect(g); g.connect(sfxBus); s.start(t0);
  }

  // Do majör pentatonik (C D E G A) — harf seçiminde yükselen notalar
  var PENTA = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.66, 1318.51, 1567.98, 1760.0];

  var SFX = {
    tap: function () { var t = ctx.currentTime; tone(880, t, 0.07, { type: 'triangle', gain: 0.12 }); },
    button: function () { var t = ctx.currentTime; tone(660, t, 0.06, { type: 'sine', gain: 0.2 }); tone(990, t + 0.03, 0.08, { type: 'sine', gain: 0.12 }); },
    select: function (i) { var t = ctx.currentTime; bell(PENTA[Math.min(i || 0, PENTA.length - 1)], t, 0.22, 0.16); },
    correct: function () {
      var t = ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { bell(f, t + i * 0.07, 0.4, 0.17); });
      noise(t + 0.24, 0.18, 0.04, 6000);
    },
    bonus: function () {
      var t = ctx.currentTime;
      [1318.5, 1567.98, 2093].forEach(function (f, i) { bell(f, t + i * 0.05, 0.3, 0.1); });
    },
    wrong: function () {
      var t = ctx.currentTime;
      tone(300, t, 0.16, { type: 'triangle', gain: 0.16, slide: 220 });
      tone(240, t + 0.1, 0.2, { type: 'triangle', gain: 0.12, slide: 180 });
    },
    already: function () { var t = ctx.currentTime; tone(520, t, 0.1, { type: 'sine', gain: 0.14 }); tone(520, t + 0.12, 0.1, { type: 'sine', gain: 0.1 }); },
    shuffle: function () { var t = ctx.currentTime; for (var i = 0; i < 5; i++) tone(500 + Math.random() * 600, t + i * 0.035, 0.05, { type: 'triangle', gain: 0.07 }); },
    hint: function () { var t = ctx.currentTime; tone(700, t, 0.25, { type: 'sine', gain: 0.15, slide: 1400 }); bell(1400, t + 0.2, 0.3, 0.1); },
    coin: function () { var t = ctx.currentTime; bell(1567.98, t, 0.12, 0.12); bell(2093, t + 0.07, 0.25, 0.12); },
    complete: function () {
      var t = ctx.currentTime;
      var seq = [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.51];
      seq.forEach(function (f, i) { bell(f, t + i * 0.09, 0.5, 0.15); });
      [523.25, 659.25, 783.99].forEach(function (f) { tone(f / 2, t + 0.63, 1.2, { type: 'triangle', gain: 0.08, attack: 0.05 }); });
      noise(t + 0.6, 0.5, 0.05, 5000);
    },
    reward: function () {
      var t = ctx.currentTime;
      [783.99, 987.77, 1174.66, 1567.98].forEach(function (f, i) { bell(f, t + i * 0.06, 0.45, 0.13); });
    },
    pop: function () { var t = ctx.currentTime; tone(400, t, 0.08, { type: 'sine', gain: 0.18, slide: 900 }); },
    tick: function () { var t = ctx.currentTime; tone(1200, t, 0.03, { type: 'square', gain: 0.03 }); },
  };

  // ---------- Arka plan müziği: yumuşak, tekrarlamayan pentatonik melodi ----------
  var CHORDS = [[261.63, 329.63, 392.0], [220.0, 261.63, 329.63], [174.61, 220.0, 261.63], [196.0, 246.94, 293.66]];
  var MEL = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5];
  var BEAT = 0.42;
  function scheduleMusic() {
    if (!state.playing || !ctx) return;
    while (state.nextTime < ctx.currentTime + 0.6) {
      var s = state.step, t = state.nextTime;
      var chord = CHORDS[Math.floor(s / 8) % CHORDS.length];
      if (s % 8 === 0) chord.forEach(function (f) { tone(f, t, BEAT * 8, { type: 'sine', gain: 0.05, attack: 0.6, bus: musicBus }); });
      if (s % 2 === 0) tone(chord[0] / 2, t, BEAT * 1.6, { type: 'triangle', gain: 0.06, attack: 0.02, bus: musicBus });
      var r = Math.sin(s * 12.9898) * 43758.5453; r = r - Math.floor(r);
      if (r > 0.42) bell(MEL[Math.floor(r * 997) % MEL.length], t, BEAT * 2.2, 0.045, musicBus);
      state.step++; state.nextTime += BEAT;
    }
  }
  function startMusic() {
    if (!ensure() || state.playing || !state.music) return;
    state.playing = true; state.nextTime = ctx.currentTime + 0.1;
    musicBus.gain.cancelScheduledValues(ctx.currentTime);
    musicBus.gain.setTargetAtTime(0.55, ctx.currentTime, 0.8);
    state.musicTimer = setInterval(scheduleMusic, 200);
  }
  function stopMusic() {
    if (!ctx || !state.playing) return;
    state.playing = false;
    clearInterval(state.musicTimer);
    musicBus.gain.setTargetAtTime(0.0, ctx.currentTime, 0.2);
  }

  root.CWAudio = {
    unlock: function () { resume(); if (state.music) startMusic(); },
    play: function (name, arg) {
      if (!state.sfx || !ensure() || !SFX[name]) return;
      try { resume(); SFX[name](arg); } catch (e) {}
    },
    setSfx: function (on) { state.sfx = !!on; },
    setMusic: function (on) { state.music = !!on; if (on) startMusic(); else stopMusic(); },
    pause: function () { if (ctx && ctx.state === 'running') ctx.suspend(); },
    resume: function () { if (ctx && (state.sfx || state.music)) ctx.resume(); },
  };
})(window);
