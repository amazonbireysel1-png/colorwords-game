/*
 * Color Words – Oyun motoru (arayüzden bağımsız, saf mantık).
 * Tarayıcıda window.CWEngine, Node'da require() ile kullanılır.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CWEngine = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  // ---------- Dil kuralları ----------
  var LANGS = {
    tr: {
      locale: 'tr-TR',
      alphabet: 'ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ',
    },
    en: {
      locale: 'en-US',
      alphabet: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    },
  };

  function langOf(code) { return LANGS[code] || LANGS.tr; }

  // Şapkalı harfleri sadeleştirir, dile göre büyük harfe çevirir (i→İ, ı→I).
  function normalize(word, lang) {
    var L = langOf(lang);
    var w = String(word || '').trim()
      .replace(/â/g, 'a').replace(/Â/g, 'A')
      .replace(/î/g, 'i').replace(/Î/g, 'İ')
      .replace(/û/g, 'u').replace(/Û/g, 'U');
    w = w.toLocaleUpperCase(L.locale);
    return w;
  }

  // Unicode-güvenli harf dizisi (İ gibi harfler tek karakter kalır).
  function chars(word) { return Array.from(word); }

  function isAlpha(word, lang) {
    var alpha = langOf(lang).alphabet;
    var arr = chars(word);
    for (var i = 0; i < arr.length; i++) if (alpha.indexOf(arr[i]) < 0) return false;
    return arr.length > 0;
  }

  function counts(word) {
    var m = Object.create(null);
    chars(word).forEach(function (c) { m[c] = (m[c] || 0) + 1; });
    return m;
  }

  function fits(word, pool) {
    var need = counts(word);
    for (var k in need) if ((pool[k] || 0) < need[k]) return false;
    return true;
  }

  // ---------- Rastgelelik (tohumlu, tekrarlanabilir) ----------
  function hashStr(s) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function rng(seed) {
    var a = (typeof seed === 'string' ? hashStr(seed) : seed) >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function shuffle(arr, r) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(r() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  // ---------- Sözlük ----------
  function Dictionary(raw, lang, exclude) {
    this.lang = lang || 'tr';
    var ex = Object.create(null);
    String(exclude || '').split(/\s+/).forEach(function (w) { if (w) ex[normalize(w, lang)] = 1; });
    var set = Object.create(null);
    var list = [];
    String(raw || '').split(/[\s,]+/).forEach(function (w) {
      if (!w) return;
      var n = normalize(w, lang);
      if (ex[n] || set[n] || !isAlpha(n, lang)) return;
      set[n] = 1; list.push(n);
    });
    this.set = set;
    this.words = list;
  }
  Dictionary.prototype.has = function (w) { return !!this.set[normalize(w, this.lang)]; };
  Dictionary.prototype.add = function (w) {
    var n = normalize(w, this.lang);
    if (!this.set[n] && isAlpha(n, this.lang)) { this.set[n] = 1; this.words.push(n); }
  };
  Dictionary.prototype.size = function () { return this.words.length; };
  // Verilen harf havuzundan yazılabilen tüm kelimeler.
  Dictionary.prototype.subwords = function (letters, minLen) {
    var pool = counts(Array.isArray(letters) ? letters.join('') : letters);
    var max = Array.isArray(letters) ? letters.length : chars(letters).length;
    minLen = minLen || 3;
    return this.words.filter(function (w) {
      var l = chars(w).length;
      return l >= minLen && l <= max && fits(w, pool);
    });
  };

  // ---------- Bölüm üretimi ----------
  // Zorluk eğrisi: bölüm numarasına göre taban kelime uzunluğu ve hedef sayısı.
  // Dört kademe: Kolay 1-100, Orta 101-250, Zor 251-400, Uzman 401-500 (sonrası Uzman).
  function difficulty(index) {
    if (index < 12) return { lens: [4], minT: 2, maxT: 3, minLen: 3 };
    if (index < 40) return { lens: [5], minT: 3, maxT: 4, minLen: 3 };
    if (index < 100) return { lens: [5], minT: 4, maxT: 5, minLen: 3 };
    if (index < 180) return { lens: [5, 6, 6], minT: 4, maxT: 6, minLen: 3 };
    if (index < 250) return { lens: [6], minT: 5, maxT: 6, minLen: 3 };
    if (index < 330) return { lens: [6, 7], minT: 5, maxT: 7, minLen: 3 };
    if (index < 400) return { lens: [7], minT: 6, maxT: 7, minLen: 3 };
    return { lens: [7, 8], minT: 6, maxT: 7, minLen: 4 };
  }
  function tierOfIndex(index) { return index < 100 ? 0 : index < 250 ? 1 : index < 400 ? 2 : 3; }
  // Aynı kelimenin bölümlerde aşırı tekrarını sınırlar (uzunluğa göre üst sınır).
  function usageCap(len) { return len <= 3 ? 5 : len === 4 ? 4 : 3; }

  function byLenAlpha(a, b) {
    var d = chars(a).length - chars(b).length;
    return d !== 0 ? d : a.localeCompare(b, 'tr');
  }

  // Bir taban kelimeden bölüm kur. Yeterli hedef yoksa null döner.
  // usage (isteğe bağlı): kelime → kaç bölümde hedef oldu; sık kullanılanlar geri plana atılır.
  function buildLevel(dict, base, diff, r, usage) {
    var letters = chars(base);
    var all = dict.subwords(letters, 3).filter(function (w) { return w !== base; });
    var subs = all.filter(function (w) { return chars(w).length >= diff.minLen; });
    if (subs.length + 1 < diff.minT) return null;
    var fresh = usage ? subs.filter(function (w) { return (usage[w] || 0) < usageCap(chars(w).length); }) : subs;
    // Taze kelimeler yetmiyorsa eski havuza dön (çözülebilirlik her zaman öncelikli)
    var src = fresh.length + 1 >= diff.minT + 1 ? fresh : subs;
    var pool = shuffle(src, r).sort(function (a, b) {
      var d = chars(b).length - chars(a).length;
      return d !== 0 ? d : (usage ? (usage[a] || 0) - (usage[b] || 0) : 0);
    });
    var chosen = [base];
    var want = Math.min(diff.maxT, src.length + 1);
    var seenLen = {};
    pool.forEach(function (w) {
      var l = chars(w).length;
      if (chosen.length < want && !seenLen[l]) { seenLen[l] = 1; chosen.push(w); }
    });
    pool.forEach(function (w) {
      if (chosen.length < want && chosen.indexOf(w) < 0) chosen.push(w);
    });
    if (chosen.length < diff.minT) return null;
    var targets = chosen.sort(byLenAlpha);
    var bonus = all.filter(function (w) { return targets.indexOf(w) < 0; });
    var mixed = shuffle(letters, r);
    var guard = 0;
    while (mixed.join('') === base && guard++ < 10) mixed = shuffle(letters, r);
    return { base: base, letters: mixed, targets: targets, bonus: bonus.sort(byLenAlpha) };
  }

  // Sabit bölüm listesi üretir (araç ve çalışma zamanı ortak kullanır).
  function generateLevels(dict, count, seed) {
    var r = rng(seed || 'colorwords');
    var used = Object.create(null), usage = Object.create(null);
    var levels = [];
    var byLen = {};
    dict.words.forEach(function (w) {
      var l = chars(w).length;
      (byLen[l] = byLen[l] || []).push(w);
    });
    for (var l in byLen) byLen[l] = shuffle(byLen[l].sort(), r);
    var cursor = {};
    function take(len, diff) {
      var bucket = byLen[len] || [];
      var c = cursor[len] || 0;
      for (; c < bucket.length; c++) {
        var base = bucket[c];
        // Aynı harf kümesi (anagram taban) ikinci kez kullanılmaz → tekrar eden bulmaca yok
        var sig = chars(base).sort().join('');
        if (used[sig]) continue;
        var lv = buildLevel(dict, base, diff, r, usage);
        if (lv) { used[sig] = 1; cursor[len] = c + 1; lv.targets.forEach(function (w) { usage[w] = (usage[w] || 0) + 1; }); return lv; }
      }
      cursor[len] = c;
      return null;
    }
    for (var i = 0; i < count; i++) {
      var diff = difficulty(i);
      var made = null;
      // Bir uzunluk tükenirse sıradaki uzunluğa geç (dönüşümlü).
      var start = Math.floor(r() * diff.lens.length);
      for (var k = 0; k < diff.lens.length && !made; k++) made = take(diff.lens[(start + k) % diff.lens.length], diff);
      if (!made) {
        var loose = { lens: diff.lens, minT: Math.max(2, diff.minT - 1), maxT: diff.maxT, minLen: 3 };
        for (var L2 = 8; L2 >= 4 && !made; L2--) { cursor[L2] = 0; made = take(L2, loose); }
      }
      if (!made) break;
      levels.push(made);
    }
    return levels;
  }

  // Günlük / serbest modlar için tek seferlik tohumlu bölüm.
  function seededLevel(dict, seed, opts) {
    opts = opts || {};
    var r = rng(seed);
    var diff = { lens: opts.lens || [6, 7], minT: opts.minT || 4, maxT: opts.maxT || 7, minLen: 3 };
    var cands = dict.words.filter(function (w) { return diff.lens.indexOf(chars(w).length) >= 0; });
    cands = shuffle(cands.sort(), r);
    for (var i = 0; i < cands.length; i++) {
      var lv = buildLevel(dict, cands[i], diff, r);
      if (lv) return lv;
    }
    return null;
  }

  // ---------- Bölüm oturumu ----------
  var RESULT = { TARGET: 'target', BONUS: 'bonus', ALREADY: 'already', INVALID: 'invalid', SHORT: 'short' };

  function LevelSession(level, dict, saved) {
    this.level = level;
    this.dict = dict;
    this.found = (saved && saved.found) ? saved.found.slice() : [];
    this.bonusFound = (saved && saved.bonusFound) ? saved.bonusFound.slice() : [];
    // revealed[i] = hedef i için açılan harf indeksleri
    this.revealed = (saved && saved.revealed) ? JSON.parse(JSON.stringify(saved.revealed)) : {};
    this.hintsUsed = (saved && saved.hintsUsed) || 0;
    this.bestChain = (saved && saved.bestChain) || 0;
    this.chainCoins = (saved && saved.chainCoins) || 0;
  }
  LevelSession.prototype.isFound = function (i) { return this.found.indexOf(this.level.targets[i]) >= 0; };
  LevelSession.prototype.isComplete = function () {
    var self = this;
    return this.level.targets.every(function (t) { return self.found.indexOf(t) >= 0; });
  };
  LevelSession.prototype.progress = function () { return this.found.length / this.level.targets.length; };

  LevelSession.prototype.submit = function (word) {
    var w = normalize(word, this.dict.lang);
    if (chars(w).length < 3) return { type: RESULT.SHORT, word: w };
    var lettersPool = counts(this.level.letters.join(''));
    if (!fits(w, lettersPool)) return { type: RESULT.INVALID, word: w };
    var ti = this.level.targets.indexOf(w);
    if (ti >= 0) {
      if (this.found.indexOf(w) >= 0) return { type: RESULT.ALREADY, word: w, index: ti };
      this.found.push(w);
      return { type: RESULT.TARGET, word: w, index: ti, complete: this.isComplete() };
    }
    if (this.dict.has(w)) {
      if (this.bonusFound.indexOf(w) >= 0) return { type: RESULT.ALREADY, word: w, bonus: true };
      this.bonusFound.push(w);
      return { type: RESULT.BONUS, word: w };
    }
    return { type: RESULT.INVALID, word: w };
  };

  // Bulunmamış bir hedefte henüz açılmamış ilk harfi açar.
  LevelSession.prototype.revealLetter = function (r) {
    var self = this;
    var open = [];
    this.level.targets.forEach(function (t, i) {
      if (self.found.indexOf(t) >= 0) return;
      var rev = self.revealed[i] || [];
      var len = chars(t).length;
      if (rev.length < len) open.push(i);
    });
    if (!open.length) return null;
    // Kısa kelimeleri önceliklendir (yardım daha anlamlı olsun).
    open.sort(function (a, b) { return chars(self.level.targets[a]).length - chars(self.level.targets[b]).length; });
    var pickFrom = open.slice(0, Math.max(1, Math.ceil(open.length / 2)));
    var i = pickFrom[Math.floor((r || Math.random)() * pickFrom.length)];
    var rev = this.revealed[i] = (this.revealed[i] || []);
    var len = chars(this.level.targets[i]).length;
    var pos = 0;
    while (rev.indexOf(pos) >= 0 && pos < len) pos++;
    rev.push(pos);
    this.hintsUsed++;
    var res = { index: i, pos: pos };
    // Tüm harfler açıldıysa kelime bulunmuş sayılır.
    if (rev.length >= len) {
      this.found.push(this.level.targets[i]);
      res.autoFound = true; res.complete = this.isComplete();
    }
    return res;
  };

  // Tek hamlede bütün bir kelimeyi açar.
  LevelSession.prototype.revealWord = function (r) {
    var self = this;
    var open = [];
    this.level.targets.forEach(function (t, i) { if (self.found.indexOf(t) < 0) open.push(i); });
    if (!open.length) return null;
    var i = open[Math.floor((r || Math.random)() * open.length)];
    var len = chars(this.level.targets[i]).length;
    this.revealed[i] = [];
    for (var p = 0; p < len; p++) this.revealed[i].push(p);
    this.found.push(this.level.targets[i]);
    this.hintsUsed += 2;
    return { index: i, complete: this.isComplete() };
  };

  LevelSession.prototype.stars = function () {
    if (this.hintsUsed === 0) return 3;
    if (this.hintsUsed <= 2) return 2;
    return 1;
  };

  LevelSession.prototype.serialize = function () {
    return { found: this.found.slice(), bonusFound: this.bonusFound.slice(), revealed: JSON.parse(JSON.stringify(this.revealed)), hintsUsed: this.hintsUsed, bestChain: this.bestChain || 0, chainCoins: this.chainCoins || 0 };
  };

  // ---------- Tarih yardımcıları (yerel saat) ----------
  function dayKey(d) {
    d = d || new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  function dayDiff(aKey, bKey) {
    var pa = aKey.split('-').map(Number), pb = bKey.split('-').map(Number);
    var a = Date.UTC(pa[0], pa[1] - 1, pa[2]), b = Date.UTC(pb[0], pb[1] - 1, pb[2]);
    return Math.round((b - a) / 86400000);
  }

  // ---------- Günlük görevler ----------
  var TASK_POOL = [
    { id: 'words', metric: 'words', goals: [8, 12, 18], reward: 40 },
    { id: 'levels', metric: 'levels', goals: [2, 3, 5], reward: 50 },
    { id: 'bonus', metric: 'bonus', goals: [2, 4, 6], reward: 40 },
    { id: 'stars3', metric: 'stars3', goals: [1, 2, 3], reward: 50 },
    { id: 'long', metric: 'long', goals: [2, 3, 4], reward: 45 },
    { id: 'shuffle', metric: 'shuffle', goals: [3, 5], reward: 25 },
    { id: 'daily', metric: 'daily', goals: [1], reward: 60 },
    { id: 'rush', metric: 'rush', goals: [1], reward: 40 },
  ];
  function dailyTasks(key, unlockedRush) {
    var r = rng('tasks-' + key);
    var pool = TASK_POOL.filter(function (t) { return unlockedRush || t.id !== 'rush'; });
    return shuffle(pool, r).slice(0, 3).map(function (t) {
      var g = t.goals[Math.floor(r() * t.goals.length)];
      return { id: t.id, metric: t.metric, goal: g, reward: t.reward + (g > t.goals[0] ? 15 : 0) };
    });
  }

  // 7 günlük ödül takvimi
  var DAILY_REWARDS = [
    { coins: 50 }, { coins: 75 }, { hints: 1 }, { coins: 100 }, { coins: 120 }, { hints: 2 }, { coins: 250, hints: 1 },
  ];

  // Günlük ödül alınabilir mi? Seri ve gün indeksini hesaplar.
  function dailyRewardState(save, todayKey) {
    var last = save.lastRewardDay;
    if (last === todayKey) return { canClaim: false, dayIndex: (save.rewardStreak - 1) % 7, streak: save.rewardStreak };
    var streak = save.rewardStreak || 0;
    if (!last || dayDiff(last, todayKey) !== 1) streak = 0; // seri kırıldı
    return { canClaim: true, dayIndex: streak % 7, streak: streak };
  }

  // ---------- Haftalık görevler (ISO hafta) ----------
  function weekKey(d) {
    d = d || new Date();
    var t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    var y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    var w = Math.ceil(((t - y0) / 86400000 + 1) / 7);
    return t.getUTCFullYear() + '-W' + (w < 10 ? '0' : '') + w;
  }
  var WEEK_POOL = [
    { id: 'w_words', metric: 'words', goals: [60, 90], reward: 150 },
    { id: 'w_levels', metric: 'levels', goals: [12, 20], reward: 180 },
    { id: 'w_bonus', metric: 'bonus', goals: [15, 25], reward: 150 },
    { id: 'w_stars3', metric: 'stars3', goals: [8, 12], reward: 160 },
    { id: 'w_daily', metric: 'daily', goals: [4, 6], reward: 200 },
    { id: 'w_golden', metric: 'golden', goals: [5, 8], reward: 160 },
    { id: 'w_rush', metric: 'rush', goals: [3, 5], reward: 150 },
  ];
  function weeklyTasks(key, unlocked) {
    unlocked = unlocked || {};
    var r = rng('week-' + key);
    var pool = WEEK_POOL.filter(function (t) {
      if (t.metric === 'rush') return !!unlocked.rush;
      if (t.metric === 'daily') return !!unlocked.daily;
      if (t.metric === 'golden') return !!unlocked.golden;
      return true;
    });
    return shuffle(pool, r).slice(0, 3).map(function (t) {
      var g = t.goals[Math.floor(r() * t.goals.length)];
      return { id: t.id, metric: t.metric, goal: g, reward: t.reward + (g > t.goals[0] ? 50 : 0) };
    });
  }

  // ---------- Özel bölüm mekanikleri (kademeli açılır) ----------
  // Bölüm numarası (1'den başlar) → mekanik ilk kez bu bölümde görünür.
  var MECHANICS = { golden: 9, gift: 10, challenge: 25, chain: 41 };
  // Bölüme özgü özellikler; tamamen bölüm indeksinden türetilir (kayıt gerektirmez, tekrarlanabilir).
  function levelFeatures(index, level) {
    var n = index + 1, r = rng('feat-' + index), f = { golden: -1, gift: false, challenge: null, chain: n >= MECHANICS.chain };
    if (n >= MECHANICS.gift && n % 10 === 0) f.gift = true;
    if (n >= MECHANICS.golden && !f.gift && (n === MECHANICS.golden || n % 3 === 2) && level && level.targets.length >= 3) {
      // En kısa ve en uzun dışındaki bir kelime altın olur (ne çok kolay ne çok zor)
      var mid = [];
      for (var i = 1; i < level.targets.length - 1; i++) mid.push(i);
      f.golden = mid[Math.floor(r() * mid.length)];
    }
    if (n >= MECHANICS.challenge && !f.gift && (n === MECHANICS.challenge || n % 5 === 3) && level) {
      var opts = [];
      if (level.bonus.length >= 2) opts.push({ type: 'bonus', goal: Math.min(3, level.bonus.length >= 4 ? 3 : 2) });
      opts.push({ type: 'nohint', goal: 1 });
      if (f.chain && level.targets.length >= 4) opts.push({ type: 'chain', goal: 3 });
      f.challenge = opts[Math.floor(r() * opts.length)];
    }
    return f;
  }
  function challengeMet(ch, s) {
    if (!ch) return false;
    if (ch.type === 'bonus') return s.bonusFound.length >= ch.goal;
    if (ch.type === 'nohint') return s.hintsUsed === 0;
    if (ch.type === 'chain') return (s.bestChain || 0) >= ch.goal;
    return false;
  }
  // Renk Zinciri: art arda hızlı bulunan kelimeler zinciri büyütür.
  var CHAIN_WINDOW = 8000;
  function chainStep(prevChain, lastAt, now) {
    if (lastAt && now - lastAt <= CHAIN_WINDOW) return prevChain + 1;
    return 1;
  }
  function chainBonus(chain) { return chain >= 2 ? Math.min(10, (chain - 1) * 2) : 0; }

  return {
    LANGS: LANGS, normalize: normalize, chars: chars, counts: counts, fits: fits,
    rng: rng, shuffle: shuffle, hashStr: hashStr,
    Dictionary: Dictionary, difficulty: difficulty, tierOfIndex: tierOfIndex, buildLevel: buildLevel,
    generateLevels: generateLevels, seededLevel: seededLevel,
    LevelSession: LevelSession, RESULT: RESULT,
    dayKey: dayKey, dayDiff: dayDiff, dailyTasks: dailyTasks, TASK_POOL: TASK_POOL,
    DAILY_REWARDS: DAILY_REWARDS, dailyRewardState: dailyRewardState,
    weekKey: weekKey, weeklyTasks: weeklyTasks, WEEK_POOL: WEEK_POOL,
    MECHANICS: MECHANICS, levelFeatures: levelFeatures, challengeMet: challengeMet,
    CHAIN_WINDOW: CHAIN_WINDOW, chainStep: chainStep, chainBonus: chainBonus,
  };
});
