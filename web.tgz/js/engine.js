/*
 * Kelime Yolculuğu – Oyun motoru (arayüzden bağımsız, saf mantık).
 * Tarayıcıda window.CWEngine, Node'da require() ile kullanılır.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CWEngine = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  // ---------- Dil kuralları ----------
  var LANGS = {
    tr: {
      locale: 'tr-TR',
      alphabet: 'ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ',
    },
    en: {
      locale: 'en-US',
      alphabet: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    },
  };

  function langOf(code) { return LANGS[code] || LANGS.tr; }

  // Şapkalı harfleri sadeleştirir, dile göre büyük harfe çevirir (i→İ, ı→I).
  function normalize(word, lang) {
    var L = langOf(lang);
    var w = String(word || '').trim()
      .replace(/â/g, 'a').replace(/Â/g, 'A')
      .replace(/î/g, 'i').replace(/Î/g, 'İ')
      .replace(/û/g, 'u').replace(/Û/g, 'U');
    w = w.toLocaleUpperCase(L.locale);
    return w;
  }

  // Unicode-güvenli harf dizisi (İ gibi harfler tek karakter kalır).
  function chars(word) { return Array.from(word); }

  function isAlpha(word, lang) {
    var alpha = langOf(lang).alphabet;
    var arr = chars(word);
    for (var i = 0; i < arr.length; i++) if (alpha.indexOf(arr[i]) < 0) return false;
    return arr.length > 0;
  }

  function counts(word) {
    var m = Object.create(null);
    chars(word).forEach(function (c) { m[c] = (m[c] || 0) + 1; });
    return m;
  }

  function fits(word, pool) {
    var need = counts(word);
    for (var k in need) if ((pool[k] || 0) < need[k]) return false;
    return true;
  }

  // ---------- Rastgelelik (tohumlu, tekrarlanabilir) ----------
  function hashStr(s) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function rng(seed) {
    var a = (typeof seed === 'string' ? hashStr(seed) : seed) >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // ---------- Çapraz bulmaca yerleşimi ----------
  // Hedef kelimeleri harfleri kesişecek şekilde ızgaraya dizer. Tüm kelimeler birbirine
  // bağlanamazsa null döner (oyun alt alta sıra düzenine geçer). Aynı girdi → aynı sonuç.
  function crossLayout(words, seed) {
    var ch = words.map(chars), n = ch.length;
    if (n < 2) return null;
    var R = rng('cross-' + (seed || 0) + '-' + words.join('|')), best = null;
    for (var attempt = 0; attempt < 160; attempt++) {
      var order = ch.map(function (_, i) { return i; }).sort(function (a, b) { return ch[b].length - ch[a].length || a - b; });
      if (attempt > 0) {
        // ilk kelime uzun kalır, kalanı karıştır
        var rest = shuffle(order.slice(1), R); order = [order[0]].concat(rest);
        if (attempt > 70) order = shuffle(order, R);
      }
      var grid = {}, placed = [], ok = true;
      var key = function (r, c) { return r + ',' + c; };
      var valid = function (w, r, c, h) {
        var cross = 0, dr = h ? 0 : 1, dc = h ? 1 : 0;
        if (grid[key(r - dr, c - dc)] || grid[key(r + dr * w.length, c + dc * w.length)]) return -1;
        for (var k = 0; k < w.length; k++) {
          var rr = r + dr * k, cc = c + dc * k, e = grid[key(rr, cc)];
          if (e) {
            if (e.ch !== w[k] || e[h ? 'h' : 'v'] !== -1) return -1;
            cross++;
          } else if (grid[key(rr + dc, cc + dr)] || grid[key(rr - dc, cc - dr)]) return -1;
        }
        return cross;
      };
      var put = function (i, r, c, h) {
        var w = ch[i], dr = h ? 0 : 1, dc = h ? 1 : 0;
        for (var k = 0; k < w.length; k++) {
          var kk = key(r + dr * k, c + dc * k), e = grid[kk] || (grid[kk] = { ch: w[k], h: -1, v: -1, r: r + dr * k, c: c + dc * k });
          e[h ? 'h' : 'v'] = i;
        }
        placed[i] = { i: i, r: r, c: c, h: h };
      };
      put(order[0], 0, 0, true);
      for (var oi = 1; oi < order.length && ok; oi++) {
        var wi = order[oi], w = ch[wi], cands = [];
        placed.forEach(function (p) {
          if (!p) return;
          var pw = ch[p.i];
          for (var a = 0; a < pw.length; a++) for (var b = 0; b < w.length; b++) {
            if (pw[a] !== w[b]) continue;
            var h = !p.h, r = p.h ? p.r - b : p.r + a, c = p.h ? p.c + a : p.c - b;
            var cr = valid(w, r, c, h);
            if (cr > 0) cands.push({ r: r, c: c, h: h, cr: cr });
          }
        });
        if (!cands.length) { ok = false; break; }
        var pick = null, ps = 1e9;
        cands.forEach(function (cd) {
          var minR = 0, maxR = 0, minC = 0, maxC = 0;
          Object.keys(grid).forEach(function (kk) { var e = grid[kk]; minR = Math.min(minR, e.r); maxR = Math.max(maxR, e.r); minC = Math.min(minC, e.c); maxC = Math.max(maxC, e.c); });
          var er = cd.r + (cd.h ? 0 : w.length - 1), ec = cd.c + (cd.h ? w.length - 1 : 0);
          minR = Math.min(minR, cd.r); minC = Math.min(minC, cd.c); maxR = Math.max(maxR, er); maxC = Math.max(maxC, ec);
          var rows = maxR - minR + 1, cols = maxC - minC + 1;
          var sc = rows * cols + Math.abs(rows - cols) * 2 - cd.cr * 3 + R() * 2;
          if (sc < ps) { ps = sc; pick = cd; }
        });
        put(wi, pick.r, pick.c, pick.h);
      }
      if (!ok) continue;
      var minR2 = 1e9, minC2 = 1e9, maxR2 = -1e9, maxC2 = -1e9;
      Object.keys(grid).forEach(function (kk) { var e = grid[kk]; minR2 = Math.min(minR2, e.r); maxR2 = Math.max(maxR2, e.r); minC2 = Math.min(minC2, e.c); maxC2 = Math.max(maxC2, e.c); });
      var rows2 = maxR2 - minR2 + 1, cols2 = maxC2 - minC2 + 1;
      var score = rows2 * cols2 + Math.abs(rows2 - cols2) * 2 + Math.max(0, Math.max(rows2, cols2) - 9) * 60;
      if (!best || score < best.score) {
        var cells = Object.keys(grid).map(function (kk) { var e = grid[kk]; return { r: e.r - minR2, c: e.c - minC2, h: e.h, v: e.v }; });
        var pw2 = placed.map(function (p) { return { i: p.i, r: p.r - minR2, c: p.c - minC2, h: p.h }; });
        best = { rows: rows2, cols: cols2, words: pw2, cells: cells, score: score };
      }
    }
    if (!best) return null;
    // kesişim konumları: kelime i, k. harf → başka kelimeyle paylaşılıyorsa sabit
    var fixed = ch.map(function () { return []; });
    best.cells.forEach(function (e) {
      if (e.h >= 0 && e.v >= 0) {
        [e.h, e.v].forEach(function (i) {
          var p = best.words.filter(function (x) { return x.i === i; })[0];
          fixed[i].push(p.h ? e.c - p.c : e.r - p.r);
        });
      }
    });
    best.fixed = fixed;
    return best;
  }
  function shuffle(arr, r) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(r() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  // ---------- Sözlük ----------
  function Dictionary(raw, lang, exclude) {
    this.lang = lang || 'tr';
    var ex = Object.create(null);
    String(exclude || '').split(/\s+/).forEach(function (w) { if (w) ex[normalize(w, lang)] = 1; });
    var set = Object.create(null);
    var list = [];
    String(raw || '').split(/[\s,]+/).forEach(function (w) {
      if (!w) return;
      var n = normalize(w, lang);
      if (ex[n] || set[n] || !isAlpha(n, lang)) return;
      set[n] = 1; list.push(n);
    });
    this.set = set;
    this.words = list;
  }
  Dictionary.prototype.has = function (w) { return !!this.set[normalize(w, this.lang)]; };
  Dictionary.prototype.add = function (w) {
    var n = normalize(w, this.lang);
    if (!this.set[n] && isAlpha(n, this.lang)) { this.set[n] = 1; this.words.push(n); }
  };
  Dictionary.prototype.size = function () { return this.words.length; };
  // Verilen harf havuzundan yazılabilen tüm kelimeler.
  Dictionary.prototype.subwords = function (letters, minLen) {
    var pool = counts(Array.isArray(letters) ? letters.join('') : letters);
    var max = Array.isArray(letters) ? letters.length : chars(letters).length;
    minLen = minLen || 3;
    return this.words.filter(function (w) {
      var l = chars(w).length;
      return l >= minLen && l <= max && fits(w, pool);
    });
  };

  // ---------- Bölüm üretimi ----------
  // Zorluk eğrisi: bölüm numarasına göre taban kelime uzunluğu ve hedef sayısı.
  // Dört kademe: Kolay 1-100, Orta 101-250, Zor 251-400, Uzman 401-500 (sonrası Uzman).
  function difficulty(index) {
    if (index < 15) return { lens: [4], minT: 2, maxT: 2, minLen: 3 };   // 1–15: ikili
    if (index < 25) return { lens: [5], minT: 3, maxT: 4, minLen: 3 };   // 16–25: en az üçlü
    if (index < 40) return { lens: [5], minT: 4, maxT: 4, minLen: 3 };   // 26+: en az dörtlü
    if (index < 100) return { lens: [5], minT: 4, maxT: 5, minLen: 3 };
    if (index < 180) return { lens: [5, 6, 6], minT: 4, maxT: 6, minLen: 3 };
    if (index < 250) return { lens: [6], minT: 5, maxT: 6, minLen: 3 };
    if (index < 330) return { lens: [6, 7], minT: 5, maxT: 7, minLen: 3 };
    if (index < 400) return { lens: [7], minT: 6, maxT: 8, minLen: 3 };
    return { lens: [7, 8], minT: 7, maxT: 9, minLen: 4 };
  }
  function tierOfIndex(index) { return index < 100 ? 0 : index < 250 ? 1 : index < 400 ? 2 : 3; }
  // Aynı kelimenin bölümlerde aşırı tekrarını sınırlar (uzunluğa göre üst sınır).
  function usageCap(len) { return len <= 3 ? 5 : len === 4 ? 4 : 3; }

  function byLenAlpha(a, b) {
    var d = chars(a).length - chars(b).length;
    return d !== 0 ? d : a.localeCompare(b, 'tr');
  }

  // Bir taban kelimeden bölüm kur. Yeterli hedef yoksa null döner.
  // usage (isteğe bağlı): kelime → kaç bölümde hedef oldu; sık kullanılanlar geri plana atılır.
  function buildLevel(dict, base, diff, r, usage, common, strict) {
    var letters = chars(base);
    var all = dict.subwords(letters, 3).filter(function (w) { return w !== base; });
    var subs = all.filter(function (w) { return chars(w).length >= diff.minLen; });
    // Günlük kelime seti (isteğe bağlı): strict ise hedefler yalnızca günlük kelimelerden seçilir.
    if (common && strict) subs = subs.filter(function (w) { return common[w]; });
    if (subs.length + 1 < diff.minT) return null;
    var fresh = usage ? subs.filter(function (w) { return (usage[w] || 0) < usageCap(chars(w).length); }) : subs;
    // Taze kelimeler yetmiyorsa eski havuza dön (çözülebilirlik her zaman öncelikli)
    var src = fresh.length + 1 >= diff.minT + 1 ? fresh : subs;
    var pool = shuffle(src, r).sort(function (a, b) {
      if (common) { var ca = common[a] ? 1 : 0, cb = common[b] ? 1 : 0; if (ca !== cb) return cb - ca; }
      var d = chars(b).length - chars(a).length;
      return d !== 0 ? d : (usage ? (usage[a] || 0) - (usage[b] || 0) : 0);
    });
    var chosen = [base];
    var want = Math.min(diff.maxT, src.length + 1);
    var seenLen = {};
    pool.forEach(function (w) {
      var l = chars(w).length;
      if (chosen.length < want && !seenLen[l]) { seenLen[l] = 1; chosen.push(w); }
    });
    pool.forEach(function (w) {
      if (chosen.length < want && chosen.indexOf(w) < 0) chosen.push(w);
    });
    if (chosen.length < diff.minT) return null;
    var targets = chosen.sort(byLenAlpha);
    var bonus = all.filter(function (w) { return targets.indexOf(w) < 0; });
    var mixed = shuffle(letters, r);
    var guard = 0;
    while (mixed.join('') === base && guard++ < 10) mixed = shuffle(letters, r);
    return { base: base, letters: mixed, targets: targets, bonus: bonus.sort(byLenAlpha) };
  }

  // Sabit bölüm listesi üretir (araç ve çalışma zamanı ortak kullanır).
  function generateLevels(dict, count, seed, opts) {
    opts = opts || {};
    var common = opts.common || null, strictN = opts.strictUntil || 0, preferN = opts.preferUntil || 0;
    var r = rng(seed || 'colorwords');
    var used = Object.create(null), usage = Object.create(null), lastIdx = Object.create(null);
    var levels = [];
    var byLen = {};
    dict.words.forEach(function (w) {
      var l = chars(w).length;
      (byLen[l] = byLen[l] || []).push(w);
    });
    for (var l in byLen) byLen[l] = shuffle(byLen[l].sort(), r);
    var cursor = {};
    function take(len, diff, idx) {
      var strict = common && idx < strictN, usec = common && idx < preferN;
      var bucket = byLen[len] || [];
      var ck = strict ? 'S' + len : len, c = cursor[ck] || 0;
      // Aday tabanlar arasında en az tekrar eden kelime içereni seç (aynı kelimeler sık dönmesin)
      var best = null, bestScore = Infinity, tried = 0, firstOk = -1;
      for (var j = c; j < bucket.length && tried < (opts.tries || 5000); j++) {
        var base = bucket[j];
        if (strict && !common[base]) continue;
        var sig = chars(base).sort().join('');
        if (used[sig]) { if (firstOk < 0 && j === c) c = j + 1; continue; }
        var lv = buildLevel(dict, base, diff, r, usage, usec ? common : null, strict);
        if (!lv) continue;
        tried++;
        var score = 0;
        lv.targets.forEach(function (w) { var u = usage[w] || 0; score += u * u * 4 + u; if (lastIdx[w] !== undefined) score += Math.max(0, 200 - (idx - lastIdx[w])) * 0.5; });
        lv._sig = sig;
        if (score < bestScore) { bestScore = score; best = lv; }
        if (score === 0) break;
      }
      cursor[ck] = c;
      if (!best) return null;
      used[best._sig] = 1; delete best._sig;
      best.targets.forEach(function (w) { usage[w] = (usage[w] || 0) + 1; lastIdx[w] = idx; });
      return best;
    }
    for (var i = 0; i < count; i++) {
      var diff = difficulty(i);
      var made = null;
      // Bir uzunluk tükenirse sıradaki uzunluğa geç (dönüşümlü).
      var start = Math.floor(r() * diff.lens.length);
      for (var k = 0; k < diff.lens.length && !made; k++) made = take(diff.lens[(start + k) % diff.lens.length], diff, i);
      if (!made) {
        var loose = { lens: diff.lens, minT: Math.max(2, diff.minT - 1), maxT: diff.maxT, minLen: 3 };
        for (var L2 = 8; L2 >= 4 && !made; L2--) { cursor[L2] = 0; made = take(L2, loose, i); }
      }
      if (!made) break;
      levels.push(made);
    }
    return levels;
  }

  // Günlük / serbest modlar için tek seferlik tohumlu bölüm.
  function seededLevel(dict, seed, opts) {
    opts = opts || {};
    var r = rng(seed);
    var diff = { lens: opts.lens || [6, 7], minT: opts.minT || 4, maxT: opts.maxT || 7, minLen: 3 };
    var cands = dict.words.filter(function (w) { return diff.lens.indexOf(chars(w).length) >= 0; });
    cands = shuffle(cands.sort(), r);
    for (var i = 0; i < cands.length; i++) {
      var lv = buildLevel(dict, cands[i], diff, r);
      if (lv) return lv;
    }
    return null;
  }

  // ---------- Bölüm oturumu ----------
  var RESULT = { TARGET: 'target', BONUS: 'bonus', ALREADY: 'already', INVALID: 'invalid', SHORT: 'short' };

  function LevelSession(level, dict, saved) {
    this.level = level;
    this.dict = dict;
    this.found = (saved && saved.found) ? saved.found.slice() : [];
    this.bonusFound = (saved && saved.bonusFound) ? saved.bonusFound.slice() : [];
    // revealed[i] = hedef i için açılan harf indeksleri
    this.revealed = (saved && saved.revealed) ? JSON.parse(JSON.stringify(saved.revealed)) : {};
    this.hintsUsed = (saved && saved.hintsUsed) || 0;
    this.bestChain = (saved && saved.bestChain) || 0;
    this.chainCoins = (saved && saved.chainCoins) || 0;
    // Kolay bölümlerde (level.loose): kutuya uyan her geçerli kelime, aynı uzunluktaki bulunmamış hedefin yerine geçer.
    this.swaps = (saved && saved.swaps) ? JSON.parse(JSON.stringify(saved.swaps)) : {};
    var self0 = this;
    Object.keys(this.swaps).forEach(function (k) { self0.level.targets[k] = self0.swaps[k]; });
  }
  LevelSession.prototype.isFound = function (i) { return this.found.indexOf(this.level.targets[i]) >= 0; };
  LevelSession.prototype.isComplete = function () {
    var self = this;
    return this.level.targets.every(function (t) { return self.found.indexOf(t) >= 0; });
  };
  LevelSession.prototype.progress = function () { return this.found.length / this.level.targets.length; };

  LevelSession.prototype.submit = function (word) {
    var w = normalize(word, this.dict.lang);
    if (chars(w).length < 3) return { type: RESULT.SHORT, word: w };
    var lettersPool = counts(this.level.letters.join(''));
    if (!fits(w, lettersPool)) return { type: RESULT.INVALID, word: w };
    var ti = this.level.targets.indexOf(w);
    if (ti >= 0) {
      if (this.found.indexOf(w) >= 0) return { type: RESULT.ALREADY, word: w, index: ti };
      this.found.push(w);
      return { type: RESULT.TARGET, word: w, index: ti, complete: this.isComplete() };
    }
    if (this.level.loose && this.dict.has(w) && this.bonusFound.indexOf(w) < 0) {
      var self1 = this, wl = chars(w).length, si = -1;
      var wc = chars(w), fx = this.level.fixed;
      this.level.targets.forEach(function (t, i) {
        if (si >= 0 || self1.found.indexOf(t) >= 0 || chars(t).length !== wl) return;
        var tc = chars(t), okc = true;
        if (fx && fx[i]) fx[i].forEach(function (pp) { if (wc[pp] !== tc[pp]) okc = false; });
        if (okc) si = i;
      });
      if (si >= 0) {
        this.level.targets[si] = w; this.swaps[si] = w; this.revealed[si] = [];
        this.found.push(w);
        return { type: RESULT.TARGET, word: w, index: si, complete: this.isComplete() };
      }
    }
    if (this.dict.has(w)) {
      if (this.bonusFound.indexOf(w) >= 0) return { type: RESULT.ALREADY, word: w, bonus: true };
      this.bonusFound.push(w);
      return { type: RESULT.BONUS, word: w };
    }
    return { type: RESULT.INVALID, word: w };
  };

  // Bir kelimenin ekranda zaten görünen harf konumları (kendi ipucu + kesişen kelimeler).
  LevelSession.prototype.visiblePositions = function (i) {
    var self = this, vis = {}, rev = this.revealed[i] || [], t = this.level.targets[i], len = chars(t).length;
    var G = this.level.cross && this.level.cross.words, me = null;
    rev.forEach(function (k) { vis[k] = 1; });
    if (this.found.indexOf(t) >= 0) { for (var z = 0; z < len; z++) vis[z] = 1; return vis; }
    if (!G) return vis;
    G.forEach(function (p) { if (p.i === i) me = p; });
    if (!me) return vis;
    for (var k = 0; k < len; k++) {
      var r = me.r + (me.h ? 0 : k), c = me.c + (me.h ? k : 0);
      G.forEach(function (q) {
        if (q.i === i || q.h === me.h) return;
        var ql = chars(self.level.targets[q.i]).length, kq = q.h ? c - q.c : r - q.r;
        var on = q.h ? (r === q.r && kq >= 0 && kq < ql) : (c === q.c && kq >= 0 && kq < ql);
        if (!on) return;
        if (self.found.indexOf(self.level.targets[q.i]) >= 0 || (self.revealed[q.i] || []).indexOf(kq) >= 0) vis[k] = 1;
      });
    }
    return vis;
  };

  // Bulunmamış bir hedefte henüz görünmeyen ilk harfi açar.
  LevelSession.prototype.revealLetter = function (r) {
    var self = this;
    var open = [];
    this.level.targets.forEach(function (t, i) {
      if (self.found.indexOf(t) >= 0) return;
      var len = chars(t).length, vis = self.visiblePositions(i), n = 0;
      for (var k = 0; k < len; k++) if (vis[k]) n++;
      if (n < len) open.push(i);
    });
    if (!open.length) return null;
    // Kısa kelimeleri önceliklendir (yardım daha anlamlı olsun).
    open.sort(function (a, b) { return chars(self.level.targets[a]).length - chars(self.level.targets[b]).length; });
    var pickFrom = open.slice(0, Math.max(1, Math.ceil(open.length / 2)));
    var i = pickFrom[Math.floor((r || Math.random)() * pickFrom.length)];
    var rev = this.revealed[i] = (this.revealed[i] || []);
    var len = chars(this.level.targets[i]).length, vis = this.visiblePositions(i);
    var pos = 0;
    while (vis[pos] && pos < len) pos++;
    rev.push(pos);
    this.hintsUsed++;
    var res = { index: i, pos: pos };
    // Tüm harfler açıldıysa kelime bulunmuş sayılır.
    var all = true; vis = this.visiblePositions(i);
    for (var k2 = 0; k2 < len; k2++) if (!vis[k2]) all = false;
    if (all) {
      this.found.push(this.level.targets[i]);
      res.autoFound = true; res.complete = this.isComplete();
    }
    return res;
  };

  // Tek hamlede bütün bir kelimeyi açar.
  LevelSession.prototype.revealWord = function (r) {
    var self = this;
    var open = [];
    this.level.targets.forEach(function (t, i) { if (self.found.indexOf(t) < 0) open.push(i); });
    if (!open.length) return null;
    var i = open[Math.floor((r || Math.random)() * open.length)];
    var len = chars(this.level.targets[i]).length;
    this.revealed[i] = [];
    for (var p = 0; p < len; p++) this.revealed[i].push(p);
    this.found.push(this.level.targets[i]);
    this.hintsUsed += 2;
    return { index: i, complete: this.isComplete() };
  };

  LevelSession.prototype.stars = function () {
    if (this.hintsUsed === 0) return 3;
    if (this.hintsUsed <= 2) return 2;
    return 1;
  };

  LevelSession.prototype.serialize = function () {
    return { found: this.found.slice(), bonusFound: this.bonusFound.slice(), revealed: JSON.parse(JSON.stringify(this.revealed)), swaps: JSON.parse(JSON.stringify(this.swaps)), hintsUsed: this.hintsUsed, bestChain: this.bestChain || 0, chainCoins: this.chainCoins || 0 };
  };

  // ---------- Tarih yardımcıları (yerel saat) ----------
  function dayKey(d) {
    d = d || new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  function dayDiff(aKey, bKey) {
    var pa = aKey.split('-').map(Number), pb = bKey.split('-').map(Number);
    var a = Date.UTC(pa[0], pa[1] - 1, pa[2]), b = Date.UTC(pb[0], pb[1] - 1, pb[2]);
    return Math.round((b - a) / 86400000);
  }

  // ---------- Günlük görevler ----------
  var TASK_POOL = [
    { id: 'words', metric: 'words', goals: [8, 12, 18], reward: 40 },
    { id: 'levels', metric: 'levels', goals: [2, 3, 5], reward: 50 },
    { id: 'bonus', metric: 'bonus', goals: [2, 4, 6], reward: 40 },
    { id: 'stars3', metric: 'stars3', goals: [1, 2, 3], reward: 50 },
    { id: 'long', metric: 'long', goals: [2, 3, 4], reward: 45 },
    { id: 'shuffle', metric: 'shuffle', goals: [3, 5], reward: 25 },
    { id: 'daily', metric: 'daily', goals: [1], reward: 60 },
    { id: 'rush', metric: 'rush', goals: [1], reward: 40 },
  ];
  function dailyTasks(key, unlockedRush) {
    var r = rng('tasks-' + key);
    var pool = TASK_POOL.filter(function (t) { return unlockedRush || t.id !== 'rush'; });
    return shuffle(pool, r).slice(0, 3).map(function (t) {
      var g = t.goals[Math.floor(r() * t.goals.length)];
      return { id: t.id, metric: t.metric, goal: g, reward: t.reward + (g > t.goals[0] ? 15 : 0) };
    });
  }

  // 7 günlük ödül takvimi
  var DAILY_REWARDS = [
    { coins: 50 }, { coins: 75 }, { hints: 1 }, { coins: 100 }, { coins: 120 }, { hints: 2 }, { coins: 250, hints: 1 },
  ];

  // Günlük ödül alınabilir mi? Seri ve gün indeksini hesaplar.
  function dailyRewardState(save, todayKey) {
    var last = save.lastRewardDay;
    if (last === todayKey) return { canClaim: false, dayIndex: (save.rewardStreak - 1) % 7, streak: save.rewardStreak };
    var streak = save.rewardStreak || 0;
    if (!last || dayDiff(last, todayKey) !== 1) streak = 0; // seri kırıldı
    return { canClaim: true, dayIndex: streak % 7, streak: streak };
  }

  // ---------- Haftalık görevler (ISO hafta) ----------
  function weekKey(d) {
    d = d || new Date();
    var t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    var y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    var w = Math.ceil(((t - y0) / 86400000 + 1) / 7);
    return t.getUTCFullYear() + '-W' + (w < 10 ? '0' : '') + w;
  }
  var WEEK_POOL = [
    { id: 'w_words', metric: 'words', goals: [60, 90], reward: 150 },
    { id: 'w_levels', metric: 'levels', goals: [12, 20], reward: 180 },
    { id: 'w_bonus', metric: 'bonus', goals: [15, 25], reward: 150 },
    { id: 'w_stars3', metric: 'stars3', goals: [8, 12], reward: 160 },
    { id: 'w_daily', metric: 'daily', goals: [4, 6], reward: 200 },
    { id: 'w_golden', metric: 'golden', goals: [5, 8], reward: 160 },
    { id: 'w_rush', metric: 'rush', goals: [3, 5], reward: 150 },
  ];
  function weeklyTasks(key, unlocked) {
    unlocked = unlocked || {};
    var r = rng('week-' + key);
    var pool = WEEK_POOL.filter(function (t) {
      if (t.metric === 'rush') return !!unlocked.rush;
      if (t.metric === 'daily') return !!unlocked.daily;
      if (t.metric === 'golden') return !!unlocked.golden;
      return true;
    });
    return shuffle(pool, r).slice(0, 3).map(function (t) {
      var g = t.goals[Math.floor(r() * t.goals.length)];
      return { id: t.id, metric: t.metric, goal: g, reward: t.reward + (g > t.goals[0] ? 50 : 0) };
    });
  }

  // ---------- Özel bölüm mekanikleri (kademeli açılır) ----------
  // Bölüm numarası (1'den başlar) → mekanik ilk kez bu bölümde görünür.
  var MECHANICS = { golden: 17, gift: 10, challenge: 25, chain: 41 };
  // Bölüme özgü özellikler; tamamen bölüm indeksinden türetilir (kayıt gerektirmez, tekrarlanabilir).
  function levelFeatures(index, level) {
    var n = index + 1, r = rng('feat-' + index), f = { golden: -1, gift: false, challenge: null, chain: n >= MECHANICS.chain };
    if (n >= MECHANICS.gift && n % 10 === 0) f.gift = true;
    if (n >= MECHANICS.golden && !f.gift && (n === MECHANICS.golden || n % 3 === 2) && level && level.targets.length >= 3) {
      // En kısa ve en uzun dışındaki bir kelime altın olur (ne çok kolay ne çok zor)
      var mid = [];
      for (var i = 1; i < level.targets.length - 1; i++) mid.push(i);
      f.golden = mid[Math.floor(r() * mid.length)];
    }
    if (n >= MECHANICS.challenge && !f.gift && (n === MECHANICS.challenge || n % 5 === 3) && level) {
      var opts = [];
      if (level.bonus.length >= 2) opts.push({ type: 'bonus', goal: Math.min(3, level.bonus.length >= 4 ? 3 : 2) });
      opts.push({ type: 'nohint', goal: 1 });
      if (f.chain && level.targets.length >= 4) opts.push({ type: 'chain', goal: 3 });
      f.challenge = opts[Math.floor(r() * opts.length)];
    }
    return f;
  }
  function challengeMet(ch, s) {
    if (!ch) return false;
    if (ch.type === 'bonus') return s.bonusFound.length >= ch.goal;
    if (ch.type === 'nohint') return s.hintsUsed === 0;
    if (ch.type === 'chain') return (s.bestChain || 0) >= ch.goal;
    return false;
  }
  // Renk Zinciri: art arda hızlı bulunan kelimeler zinciri büyütür.
  var CHAIN_WINDOW = 8000;
  function chainStep(prevChain, lastAt, now) {
    if (lastAt && now - lastAt <= CHAIN_WINDOW) return prevChain + 1;
    return 1;
  }
  function chainBonus(chain) { return chain >= 2 ? Math.min(10, (chain - 1) * 2) : 0; }

  return {
    LANGS: LANGS, normalize: normalize, chars: chars, counts: counts, fits: fits,
    rng: rng, shuffle: shuffle, hashStr: hashStr,
    Dictionary: Dictionary, difficulty: difficulty, tierOfIndex: tierOfIndex, buildLevel: buildLevel,
    generateLevels: generateLevels, seededLevel: seededLevel, crossLayout: crossLayout,
    LevelSession: LevelSession, RESULT: RESULT,
    dayKey: dayKey, dayDiff: dayDiff, dailyTasks: dailyTasks, TASK_POOL: TASK_POOL,
    DAILY_REWARDS: DAILY_REWARDS, dailyRewardState: dailyRewardState,
    weekKey: weekKey, weeklyTasks: weeklyTasks, WEEK_POOL: WEEK_POOL,
    MECHANICS: MECHANICS, levelFeatures: levelFeatures, challengeMet: challengeMet,
    CHAIN_WINDOW: CHAIN_WINDOW, chainStep: chainStep, chainBonus: chainBonus,
  };
});
