/*
 * Kelime Yolculuğu – parçacık efektleri (konfeti, boya sıçraması, parıltı).
 * Tek bir tuval; yalnızca parçacık varken çizim döngüsü çalışır (pil dostu).
 */
(function (root) {
  'use strict';
  var COLORS = ['#14A8AE', '#8E7CE6', '#F2705F', '#E9B03A', '#EE7C94', '#4C9ED9', '#3DBF8F', '#F59A62'];
  var canvas, g, dpr = 1, W = 0, H = 0, parts = [], running = false, low = false, last = 0;

  function init() {
    canvas = document.getElementById('fx');
    g = canvas.getContext('2d');
    resize();
    root.addEventListener('resize', resize);
  }
  function resize() {
    dpr = Math.min(root.devicePixelRatio || 1, low ? 1 : 2);
    W = root.innerWidth; H = root.innerHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function cap(n) { return low ? Math.ceil(n * 0.35) : n; }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }

  function loop(ts) {
    var dt = Math.min(0.033, (ts - (last || ts)) / 1000); last = ts;
    g.clearRect(0, 0, W, H);
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i];
      p.life -= dt;
      if (p.life <= 0) { parts.splice(i, 1); continue; }
      p.vy += p.grav * dt; p.vx *= p.drag; p.vy *= p.drag;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      var a = Math.min(1, p.life / p.fade);
      g.globalAlpha = a;
      g.fillStyle = p.color;
      if (p.kind === 'confetti') {
        g.save(); g.translate(p.x, p.y); g.rotate(p.rot);
        g.scale(1, Math.abs(Math.cos(p.rot * 1.7)) * 0.8 + 0.2);
        g.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        g.restore();
      } else if (p.kind === 'star') {
        g.save(); g.translate(p.x, p.y); g.rotate(p.rot);
        var s = p.size * (0.6 + 0.4 * a);
        g.beginPath();
        for (var k = 0; k < 8; k++) { var r = k % 2 ? s * 0.35 : s; var an = k * Math.PI / 4; g.lineTo(Math.cos(an) * r, Math.sin(an) * r); }
        g.closePath(); g.fill(); g.restore();
      } else {
        g.beginPath(); g.arc(p.x, p.y, p.size * (0.5 + 0.5 * a), 0, Math.PI * 2); g.fill();
      }
    }
    g.globalAlpha = 1;
    if (parts.length) root.requestAnimationFrame(loop);
    else { running = false; last = 0; g.clearRect(0, 0, W, H); }
  }
  function kick() { if (!running) { running = true; root.requestAnimationFrame(loop); } }

  var FX = {
    init: init,
    setLow: function (v) { low = !!v; if (canvas) resize(); },
    // Kelime bulununca: boya damlası patlaması
    splash: function (x, y, color, n) {
      n = cap(n || 18);
      for (var i = 0; i < n; i++) {
        var an = Math.random() * Math.PI * 2, sp = 120 + Math.random() * 260;
        parts.push({ kind: 'dot', x: x, y: y, vx: Math.cos(an) * sp, vy: Math.sin(an) * sp - 60, grav: 600, drag: 0.96,
          size: 3 + Math.random() * 5, color: Math.random() < 0.7 ? color : pick(COLORS), life: 0.7 + Math.random() * 0.4, fade: 0.4, rot: 0, vr: 0 });
      }
      kick();
    },
    sparkle: function (x, y, n, color) {
      n = cap(n || 8);
      for (var i = 0; i < n; i++) {
        var an = Math.random() * Math.PI * 2, sp = 40 + Math.random() * 120;
        parts.push({ kind: 'star', x: x, y: y, vx: Math.cos(an) * sp, vy: Math.sin(an) * sp, grav: 0, drag: 0.93,
          size: 4 + Math.random() * 6, color: color || '#F4CF7E', life: 0.6 + Math.random() * 0.4, fade: 0.5, rot: Math.random() * 3, vr: 3 });
      }
      kick();
    },
    confetti: function (n) {
      n = cap(n || 140);
      for (var i = 0; i < n; i++) {
        var fromLeft = i % 2 === 0;
        parts.push({ kind: 'confetti', x: fromLeft ? -10 : W + 10, y: H * (0.55 + Math.random() * 0.3),
          vx: (fromLeft ? 1 : -1) * (250 + Math.random() * 450), vy: -(450 + Math.random() * 550), grav: 700, drag: 0.985,
          size: 8 + Math.random() * 8, color: pick(COLORS), life: 2.2 + Math.random() * 1.4, fade: 0.6, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 14 });
      }
      kick();
    },
    rain: function (n) {
      n = cap(n || 80);
      for (var i = 0; i < n; i++) {
        parts.push({ kind: 'confetti', x: Math.random() * W, y: -20 - Math.random() * H * 0.5, vx: (Math.random() - 0.5) * 80, vy: 80 + Math.random() * 120,
          grav: 120, drag: 0.995, size: 7 + Math.random() * 7, color: pick(COLORS), life: 3 + Math.random() * 1.5, fade: 0.8, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 10 });
      }
      kick();
    },
    // Altın uçuşu: (x1,y1) → (x2,y2)
    coinFly: function (x1, y1, x2, y2, n, onArrive) {
      n = Math.min(n || 8, low ? 4 : 10);
      var layer = document.getElementById('flyLayer');
      for (var i = 0; i < n; i++) (function (i) {
        var el = document.createElement('div');
        el.className = 'fly-coin';
        el.style.transform = 'translate(' + (x1 - 14) + 'px,' + (y1 - 14) + 'px)';
        layer.appendChild(el);
        var ox = (Math.random() - 0.5) * 120, oy = (Math.random() - 0.5) * 120;
        setTimeout(function () {
          el.style.transition = 'transform .25s ease-out';
          el.style.transform = 'translate(' + (x1 + ox - 14) + 'px,' + (y1 + oy - 14) + 'px)';
          setTimeout(function () {
            el.style.transition = 'transform .5s cubic-bezier(.55,-0.2,.75,.5), opacity .5s';
            el.style.transform = 'translate(' + (x2 - 14) + 'px,' + (y2 - 14) + 'px) scale(.6)';
            setTimeout(function () { el.remove(); if (onArrive) onArrive(i); }, 500);
          }, 260);
        }, i * 50);
      })(i);
    },
    COLORS: COLORS,
  };
  root.CWFx = FX;
})(window);
