/*
 * Reklam / satın alma ayarları. 2. aşamada reklam KAPALI (provider: 'none').
 * 4. aşamada bu dosya reklam-ayarlari.json'dan üretilecek.
 */
window.CW_MONET_CONFIG = { provider: 'none' };
