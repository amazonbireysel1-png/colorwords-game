/*
 * Kelime Yolculuğu – reklam katmanı (sağlayıcıdan bağımsız).
 *
 * Mimari:
 *   Oyun kodu  →  CWAds (kurallar: sıklık, zamanlama, reklamsız sürüm)  →  Sağlayıcı (none | mock | admob)
 *
 * Oyun kodu yalnızca şu iki çağrıyı yapar:
 *   CWAds.betweenLevels(ctx)          → bölüm arasında, kurallar izin verirse geçiş reklamı
 *   CWAds.rewarded(placement) → Promise<{rewarded:boolean, reason?}>  (yalnızca oyuncu isteyince)
 * Sağlayıcı hata verirse veya hiç yoksa oyun normal devam eder (Promise asla reddedilmez).
 */
(function (root) {
  'use strict';

  // ---- Varsayılan ayarlar (www/js/monet-config.js ile ezilir) ----
  var CFG = {
    provider: 'none',            // 'none' | 'mock' (geliştirici testi) | 'admob' (4. aşama)
    interstitial: {
      enabled: true,
      firstAfterLevel: 12,       // ilk 12 bölümde hiç geçiş reklamı yok
      everyNLevels: 4,           // en az 4 bölümde bir
      minIntervalSec: 240,       // iki geçiş reklamı arasında en az 4 dk
      minSessionSec: 180,        // oturumun ilk 3 dakikasında yok
      maxPerDay: 8,
    },
    rewarded: { maxPerDay: 12 },
  };
  function merge(dst, src) { for (var k in src) { if (src[k] && typeof src[k] === 'object' && !Array.isArray(src[k])) { dst[k] = dst[k] || {}; merge(dst[k], src[k]); } else dst[k] = src[k]; } return dst; }
  if (root.CW_MONET_CONFIG) merge(CFG, root.CW_MONET_CONFIG);

  // ---- Durum (kayıt dosyasında tutulur, app.js bağlar) ----
  var state = null;           // { adsRemoved, day, interToday, rewardToday, levelsSinceInter, lastInterAt }
  var sessionStart = Date.now();
  var now = function () { return Date.now(); };

  function rollDay(dayKey) {
    if (state.day !== dayKey) { state.day = dayKey; state.interToday = 0; state.rewardToday = 0; }
  }

  // ---- Sağlayıcılar ----
  var providers = {
    none: {
      name: 'none',
      init: function () { return Promise.resolve(false); },
      ready: function () { return false; },
      showInterstitial: function () { return Promise.resolve(false); },
      showRewarded: function () { return Promise.resolve({ rewarded: false, reason: 'unavailable' }); },
    },
  };
  var provider = providers.none;

  var Ads = {
    CFG: CFG,
    registerProvider: function (name, impl) { providers[name] = impl; },
    attach: function (saveState) {
      state = saveState;
      if (state.levelsSinceInter == null) state.levelsSinceInter = 0;
      if (state.lastInterAt == null) state.lastInterAt = 0;
    },
    init: function () {
      provider = providers[CFG.provider] || providers.none;
      return Promise.resolve().then(function () { return provider.init(CFG); }).catch(function () { provider = providers.none; return false; });
    },
    providerName: function () { return provider.name; },
    adsRemoved: function () { return !!(state && state.adsRemoved); },
    setAdsRemoved: function (v) { if (state) state.adsRemoved = !!v; },

    // Kural motoru: geçiş reklamı şu an gösterilebilir mi? (saf fonksiyon; test edilebilir)
    canShowInterstitial: function (ctx) {
      var c = CFG.interstitial;
      if (!state) return { ok: false, why: 'no-state' };
      rollDay(ctx.dayKey);
      if (state.adsRemoved) return { ok: false, why: 'ads-removed' };
      if (!c.enabled) return { ok: false, why: 'disabled' };
      if (ctx.mode !== 'level') return { ok: false, why: 'mode' };              // günlük/koşu sonunda yok
      if (ctx.levelNumber < c.firstAfterLevel) return { ok: false, why: 'early' };
      if (ctx.firstTimeGallery) return { ok: false, why: 'celebration' };       // tablo kutlamasını bölme
      if (state.levelsSinceInter < c.everyNLevels) return { ok: false, why: 'frequency' };
      if ((ctx.now || now()) - state.lastInterAt < c.minIntervalSec * 1000) return { ok: false, why: 'interval' };
      if ((ctx.now || now()) - sessionStart < c.minSessionSec * 1000) return { ok: false, why: 'session' };
      if (state.interToday >= c.maxPerDay) return { ok: false, why: 'daily-cap' };
      return { ok: true };
    },
    // Bölüm bitince çağrılır (oyuncu "Sonraki"ye bastıktan sonra; oyun ortasında asla).
    betweenLevels: function (ctx) {
      if (!state) return Promise.resolve(false);
      state.levelsSinceInter++;
      var chk = this.canShowInterstitial(ctx);
      if (!chk.ok || !provider.ready('interstitial')) return Promise.resolve(false);
      return provider.showInterstitial().then(function (shown) {
        if (shown) { state.levelsSinceInter = 0; state.lastInterAt = now(); state.interToday++; }
        return !!shown;
      }).catch(function () { return false; });
    },
    rewardedAvailable: function () {
      return !!state && state.rewardToday < CFG.rewarded.maxPerDay && provider.ready('rewarded');
    },
    // Ödül yalnızca sağlayıcı "izlendi" derse verilir.
    rewarded: function (placement, dayKey) {
      if (!state) return Promise.resolve({ rewarded: false, reason: 'no-state' });
      rollDay(dayKey);
      if (state.rewardToday >= CFG.rewarded.maxPerDay) return Promise.resolve({ rewarded: false, reason: 'daily-cap' });
      if (!provider.ready('rewarded')) return Promise.resolve({ rewarded: false, reason: 'unavailable' });
      return provider.showRewarded(placement).then(function (r) {
        r = r || {};
        if (r.rewarded) state.rewardToday++;
        return { rewarded: !!r.rewarded, reason: r.reason };
      }).catch(function (e) { return { rewarded: false, reason: 'error' }; });
    },
    _setNow: function (fn) { now = fn; }, _setSessionStart: function (t) { sessionStart = t; },
  };
  root.CWAds = Ads;
})(typeof window !== 'undefined' ? window : globalThis);
