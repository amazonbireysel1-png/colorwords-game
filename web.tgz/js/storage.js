/*
 * Kelime Yolculuğu – kalıcı kayıt.
 * - Birincil: localStorage (Android WebView'de uygulama verisinde kalıcıdır).
 * - Native'de ek olarak Capacitor Preferences (SharedPreferences) aynası tutulur.
 * - Her yazımda bir yedek kopya ve sağlama toplamı saklanır; bozuk kayıt yedekten kurtarılır.
 */
(function (root) {
  'use strict';
  var KEY = 'cw_save_v1', BAK = 'cw_save_v1_bak';

  function checksum(str) {
    var h = 5381;
    for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }
  function wrap(obj) { var s = JSON.stringify(obj); return JSON.stringify({ c: checksum(s), d: s }); }
  function unwrap(raw) {
    if (!raw) return null;
    try {
      var w = JSON.parse(raw);
      if (!w || typeof w.d !== 'string' || checksum(w.d) !== w.c) return null;
      return JSON.parse(w.d);
    } catch (e) { return null; }
  }
  function lsGet(k) { try { return root.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { root.localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function lsDel(k) { try { root.localStorage.removeItem(k); } catch (e) {} }

  function prefs() {
    var C = root.Capacitor;
    return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.Preferences ? C.Plugins.Preferences : null;
  }

  var Storage = {
    // Senkron yükleme (localStorage); native aynadan daha yeni kayıt varsa loadNative ile birleştirilir.
    load: function () {
      return unwrap(lsGet(KEY)) || unwrap(lsGet(BAK));
    },
    loadNative: function () {
      var P = prefs();
      if (!P) return Promise.resolve(null);
      return P.get({ key: KEY }).then(function (r) { return unwrap(r && r.value); }).catch(function () { return null; });
    },
    save: function (obj) {
      obj.savedAt = Date.now();
      var raw = wrap(obj);
      var prev = lsGet(KEY);
      if (prev && unwrap(prev)) lsSet(BAK, prev);
      var ok = lsSet(KEY, raw);
      var P = prefs();
      if (P) P.set({ key: KEY, value: raw }).catch(function () {});
      return ok;
    },
    clear: function () {
      lsDel(KEY); lsDel(BAK);
      var P = prefs(); if (P) P.remove({ key: KEY }).catch(function () {});
    },
    _wrap: wrap, _unwrap: unwrap, KEY: KEY, BAK: BAK,
  };
  root.CWStorage = Storage;
})(window);
