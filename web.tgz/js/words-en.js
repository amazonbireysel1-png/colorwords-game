/*
 * Color Words – English starter dictionary (altyapı örneği).
 * İngilizce bölümler çalışma zamanında bu sözlükten tohumlu olarak üretilir.
 * Tam sürüm için listeyi genişletmeniz yeterlidir.
 */
(function (root) {
  root.CW_WORDS_EN = `
art arm ant ape ate bag bat bar bed bee bet bin bit box boy bud bus cab can cap car cat cow cry cup cut dad day den dew dig dog dot dry ear eat egg elf end era eye fan far fat fig fin fir fit fix fly fog fox fun fur gap gas gem gum hat hen hit hog hop hot hug ice ink jam jar jet joy key kid kit lab lap leg lid lip log map mat mud nap net nut oak oar oat odd oil one owl pan pat pea pen pet pie pig pin pit pot ram rat raw red rib rod rot row rub rug run sad sat saw sea set sip sit sky son spa sun tan tap tar tea ten tie tin toe top toy tub two van war wax web wet win yak yes zip
able acre aunt bake bald band bank barn bead bean bear beat bird boat bold bone book cake calm camp cane card care cart cast cave coat code coin cold cone cord core dart date dear deer desk dial dine dirt dish dove drum duck dust earn east edge fair farm fast fern fire fish flag foam fork game gate gift goat gold harp heat herd hike hint hive home horn kite lake lamp lane leaf lime line lion loaf maps mars mint moon nest note oars palm park pear pine plan plum pond race rain rate read reed rest ring road rose sail salt sand seat seed shoe snow soap song star tail tale team tear tent tide tile time tone tree wand wave wind wing wolf yarn
alert alien angel anger apple arise baker beach bread brain cable camel candy cedar chair charm chart cider clean cloud coast crane cream crest dance dream eagle earth fairy flame float frost grape grain heart honey horse ideal island lemon light magic melon metal night ocean olive onion paint pearl petal piano plant plate queen rider river robin salad scale shore smile snail space spice stone storm table tiger toast trace train trail treat water whale
garden planet silver marble pencil rocket winter spring flower butter candle castle dragon forest island orange parade pirate rainbow sunrise teacup lantern painter treasure
`;
})(typeof window !== 'undefined' ? window : globalThis);
