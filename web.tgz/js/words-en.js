/*
 * Color Words – English dictionary (~3067 common words, 3-8 letters, base forms).
 * NOT verified against an official dictionary; doubtful words go to EXCLUDE.
 */
(function (root) {
  root.CW_WORDS_EN = `
able about above absence accent account ace acid acorn acre acrobat act action active actor actual adapt add
address adopt adult advance advice after again against age aged agency agent ago agree ahead aid aim air
airport alarm album alcohol alert alien alike alive all allow almost alone along already also alter always
amazing amber amount ample analyst anchor ancient and angel anger angle angry animal ankle annual answer ant
anxiety any anybody anymore anyone apart ape appear apple apply apricot apron arc arch archive arctic are area
arena argue arise ark arm armor army aroma around arrange array arrow art article artist ash aside ask assault
asset ate athlete atom attempt attic attract auction audio aunt autumn average avoid awake award aware away
awe awful axe baby back bacon bad badge bag bagel bake baker balance balcony bald ball ban band bandage bank
banner bar bare bargain bark barn barrel base basic basil basin basis basket bat batch bath battle bay beach
bead beam bean bear beard beast beat beauty bed bee beef before beg begin behave behind being bell belly
belong beloved belt bench bend benefit berry beside best bet better beyond bicycle bid big bike bill bin bind
biology bird birth bishop bit bite bitter black blade blame blank blanket blast blaze bleak blend bless
blessed blind blink bliss blizzard block bloom blossom blow blown blue boar board boast boat body bold bolt
bond bone bonus book boom boost boot booth born boss bottle bottom bounce bound boundary bow bowl box boy
brain brake branch brand brass brave bread break breath breed brick bride bridge brief bright brim bring brink
brisk broad broke broken brook broom brother brown brush bubble buck bucket bud buddy budget buffer bug build
built bulb bull bunch bundle burden burn burst bus bush busy but butter button buy cab cabin cabinet cable
cacti cactus cafe cage cake calf call calm came camel camera camp campus can canal candle candy cane canoe
canvas cap car carbon card care career cargo carpet carrot carry cart cartoon carve case cash cast castle
casual cat catch cattle cause caution cave cedar ceiling cell center central century chain chair chalk chamber
champ chance change channel chapter charge charity charm chart chase cheap check cheek cheer cheese chef
cherry chess chest chick chicken chief child chill chime chimney chin chip choice chop chosen chunk church
cider cigar circle circuit citizen citrus city civic claim clam clap clash class classic claw clay clean clear
clerk clever click client cliff climate climb climber cling clip cloak clock close closet cloth clothes cloud
clover clown club clue cluster coach coal coast coat cobra cocktail cocoa code coffee coil coin cold collect
college color column combine come comedy comet comfort comic command comment common compass compete complex
concert conduct cone connect consent contact content contest control convert cook cookie cool cop cope copper
copy coral cord core corn corner correct cost cottage cotton couch cough could count counter country county
couple courage course court cousin cover cow cozy crab crack craft crane crash crater crawl crazy cream create
credit creek creep crest crew crisis crisp crop cross crow crowd crown crumb crush crust cry crystal cub cube
cubic culture cunning cup cure curious curl current curve cushion custom cut cute cycle cyclist dad daily
dairy daisy dam damage dame damp dance dancing danger dare dark dart dash data date dawn day daylight days
dead deadline deaf deal dealer dealt dear death debate debut decade decay decent decide deck deed deep deeper
deer default defend defense define degree delay delight deliver delta demand demo den dense density dent
deposit depth derby desert design desk desktop destiny detail device dew dial diamond diary dice did die diet
dig digital dim dime dine dinner dip diploma direct dirt dirty dish ditch dive divide dizzy dock doctor dodge
does dog doing doll dollar dolphin domain dome done donkey donor door dormant dose dot double doubt dough dove
down dozen draft drag dragon drain drama drank draw drawer drawing drawn dream dreamy dress dressing drew
dried drift drill drink drip drive driver drop drown drum drums dry dryer dub duck dude due duel duet dug dull
dune durable during dusk dust dusty duty dwarf dye dynamic each eager eagle ear early earn earth ease easel
easily east eastern easy eat echo economy edge edition editor eel effect effort egg ego eight either elbow
elder elect elegant element eleven elf elite elk elm else embrace emerge emotion emperor empire empty enable
enchant end ending endless enemy energy engaged engine enhance enjoy enjoyed enough ensure enter entire entry
episode equal equator era error escape essay eve even evening event ever every evident evil ewe exact exactly
exam examine example excuse exhibit exist exotic expand expert explain explore export express extra extreme
eye fable fabric face fact factor faculty fad fade fail faint fair fairly fairy faith fake fall fallen false
fame family famous fan fancy fantasy far farm farmer fashion fast faster fat fatal fate father fawn fax fear
feast feather feature fed federal fee feed feel feet fell fellow felt fence fern ferry fever few fewer fiber
fiction field fierce fife fifteen fifth fifty fig fight figure file fill film filter fin final finally finance
find fine finger finish fir fire firm first fish fishing fist fit fitness five fix flag flame flash flat
flavor flax flea fled fleet flesh flew flick flight fling flip float flock flood floor flour flow flower
flowing flown flu fluid flush flute fly flying foam focal focus foe fog foggy fold foliage folk follow fond
food fool foot footage for force ford forest forever forge forget fork form formal former formula fort forth
fortune forty forum forward fossil foster foul found four fourth fowl fox fragile frame frank free freedom
freezer fresh fridge fried friend friendly frog from frost frosty frozen fruit fruitful fry fuel full fully
fun fund funeral funny fur fuse future gag gain galaxy gale gallery gallon game gang gap gape garage garden
garlic garment gas gasp gate gather gauge gave gaze gear gel gem general gentle genuine gesture get ghost
giant gift gin ginger girl give given glacier glad glance glass glaze gleam glimpse global globe gloom glory
glove glow glue goal goat goblet god going gold golden golf gone good gorilla got gown grab grace grade grain
grand grant grape graph grasp grass grave gravel gravity gray great greatly greed green greet grew grid grief
grill grin grind grip grocery groom gross ground group grove grow growing growl grown growth guard guess guest
guide guilt guitar gulf gull gum gun gust gut guy gym habit habitat had hail hair half halfway hall halt ham
hammer hammock hand handle hang happen happy harbor hard hardly hare harm harmony harp harsh harvest has hash
haste hat hatch hate haul haunt have hawk hay hazard head heading heal health healthy heap hear heart hearty
heat heaven heavily heavy hedge heel height held hello helm helmet help helper helpful hemp hen hence her herb
herd here hero herself hid hidden hide high highway hike hill him himself hint hip hire his history hit hive
hockey hog hold hole holiday holy home honest honey honor hood hook hoop hop hope horn horse hose host hostile
hot hotel hour house how hub hue hug huge hull hum human humor hundred hung hungry hunt hunter hunting hurry
hurt husband hut hybrid hymn ice iceberg icon icy idea ideal ignore ill image imagine immense imp impact
import improve inch include income indeed index indoor inform initial ink inn inner input inquiry insect
inside install instant intact intense interim invent invited involve ion iron irony island isle item itself
ivory ivy jab jacket jade jail jam jar jaw jay jazz jelly jersey jest jet jewel jig jigsaw job jog join joint
joke joker jolly jolt journey joy judge jug juice jumbo jump jungle junior junk juror jury just justice keel
keen keep keeps kelp kept kernel kettle key kick kid kidney kill kin kind king kingdom kiss kit kitchen kite
kitten knee kneel knew knife knit knob knock knot know knowing known lab label labor lace lack lad ladder lag
lake lamb lamp land lane lantern lap lard lark laser lash last lasting late lately later laugh launch law lawn
lawyer lay layer lazy lea lead leader leaf league leak lean leap learn lease least leather leave lecture led
ledge left leg legal legally legend leisure lemon lend length lens less lesson let letter level lever liar
liberty library license lick lid lie life lift light lighter like lily limb lime limit limited line linear
linen link lion lip liquid list lit little live lively liver lizard load loaf loan lobby local lock lodge loft
log logic logo lone lonely long look loop loose lord lose loss lost lot loud love lover low lower loyal luck
lucky lumber lump lunar lunch lung lure lush machine mad made magic magical magnet maid mail mailbox main
major make maker male mall malt mammal man manager mane mango manner mansion many map maple maps marble march
mare margin marine mariner mark market marry mars marsh mart mask mass massive mast master mat match mate
matter may mayor maze meadow meal mean meaning measure meat medal media medical meeting melon melt member memo
memory men mental mention menu mercy mere merge merit merry mesh message met metal meter method mid middle
midnight might mighty migrate mild milk mill million mind mine mineral minimum minor mint minus minute mirror
miss mission mist mix mixed mixture moat mob mobile mode model modem modern modest moist mold mole moment
money monitor monk monkey month monthly mood moon moor mop moral more morning moss most mostly moth mother
motion motor mount mouse mouth move movie much mud muddy mug mule muscle museum music musical must mutual
mystery myth nail naive name nap nape narrow nation natural nature naval navy near nearby nearest nearly neat
neck need needle neither nephew nerve nest net network neutral never new newly news next nice nickel night nil
nimble nine noble nobody nod node noise none noon nor norm normal north nose not note noted nothing notice
noun novel now nuclear number nun nurse nursery nut nutty oak oar oars oasis oat oath oatmeal obey object
obtain obvious ocean odd odor off offer office officer often oil old olive once one onion online only onto
open opening opera operate opinion optimal option oral orange orb orbit orchard orchid order ore organ organic
origin other ought our out outcome outer outfit outlet output outside oval oven over overall owe owl own owner
oxide oxygen ozone pace pack pact pad page paid pail pain paint painter pair pajamas pal palace pale palette
palm pan pancake pane panel panic panther paper par parade parcel parent park parrot part partly partner party
pass passage passion past pasta pastry pasture pat patch path patient patrol pattern pause paw pawn pay
payment pea peace peach peak peanut pear pearl peas pebble peck pedal peel peer peg pelican pen pencil penguin
penny pepper perch perfect perhaps period person pest pet petal phase phone photo phrase piano pick picnic
picture pie piece pier pig pike pile pill pillow pilot pin pinch pine pink pioneer pipe pirate pit pitch pixel
pizza place plain plan plane planet plank plant plastic plate play player playful plaza plea plead pleasant
please pleasure pledge plenty plot plow pluck plug plum plumb plumber plume plus plush pocket pod poem poems
poet poetry point pointed poise polar pole police policy polish polite polka poll polo pond pony pool poor pop
popular porch pork port portion pose post poster pot potato pottery pouch poultry pound pour powder power
powerful practice prank pray precise predict prefer prepare present press pretend pretty prevent prey price
pride primary prime prince print printer prior prison private prize pro probe problem process produce product
profile profit program project promise prompt prone proof prop proper protect protein proud prove provide
prune pub public pull pulse pump punch pup pupil puppy pure purple purse pursue pursuit push put puzzle quack
quality quarter queen query quest quick quickly quiet quietly quilt quirk quit quite quiz quote rabbit race
rack radar radical radio raft rag rage raid rail railway rain rainbow raise rake rally ram ramp ran ranch rang
range rank rap rapid rapidly rare rarely rash rat rate rather ratio rave raven raw ray reach react read reader
reading ready real reality really realm reap rear reason rebel recall receipt recent recipe record recover red
reduce reed reef reel reflect reform refresh refuse region regular reign rein relate related relax relay
release relief rely remain remind remote removal remove renew rent repair repeat replace reply report request
require rescue reserve resolve respect rest restore result retail retreat return reunion reveal revenue
reverse review reward rhythm rib rice rich rid riddle ride rider ridge rife rifle rig right rigid rim ring
rinse riot rip ripple rise risk risky rival river road roam roar roast roasted rob robe robin robot rock
rocket rocky rod rode role roll rolling romance roof room root rope rose rot rouge rough round route routine
row royal rub rubber rubbish rude rug rugby ruin rule ruler ruling rum run runaway runner rural rush rust
rustic rye sack sad saddle safe safety sag sage said sail sailing saint sake salad sale salmon salt same
sample sand sandal sandbox sane sang sank sap sat sauce sausage save saw say scale scan scar scare scarf
scatter scene scent scholar school science scooter scope score scout scratch screen screw script sea seal seam
search seaside season seat second secret section secure see seed seek seeking seem seen seize select self sell
senator send senior sense sent series serious serve server service session set sets setting settle seven
seventh sew shade shadow shaft shake shall shallow shame shape share sharing shark sharp shave she shed sheep
sheet shelf shell shelter shift shimmer shin shine shining shiny ship shirt shock shoe shop shore short
shortly shot shout show shower shown shrub shut shuttle shy sick side sift sigh sight sign signal silence
silent silk sill silly silver similar simple sin since sincere sing singer single sink sip sir sister sit site
sitting six sixth sixty size skate skeleton sketch ski skill skilled skip skirt skull sky slam slap slate sled
sleep sleeper slender slice slid slide slight slim slip slipper slope slot slow slug sly small smart smash
smell smile smiling smoke smooth snack snail snake snap sneak snow snowman soak soap soar sob soccer social
society sock soda sodium sofa soft soil solar sold soldier sole solemn solid solve solver solving some someone
son song soon sorbet sore sorry sort soul sound soup sour south sow soy spa space span spare spark sparkle
speak speaker special species speed spell spend sphere spice spider spike spin spine spirit spit splash
splendid spoken sponsor spoon sport spot spray spread spring sprinkle spur spy squad square squeeze stable
stack stadium staff stage stair stake stamp stand standard star stare starlit start state static station
status stay steady steak steam steel steep steer stem step stereo stern stew stick sticky stiff still sting
stir stitch stock stomach stone stool stop storage store stories storm story stove strange straw stream street
stress stretch strict strip stripe strong stub student studio study stuff style sub subject submit success
such sudden sugar suggest suit suite sum summer summit sun sung sunny sunrise sunset super supply support
supreme sure surely surf surface surge surgery surplus surprise survey survive suspect swam swamp swan swap
swarm swear sweat sweater sweep sweet swept swift swim swimmer swing switch sword symbol symptom syrup system
tab table tablet tack tackle tad tag tail take tale talent talk tall tame tan tangled tango tank tap tape tar
target task taste tax taxi tea teach teacher teacup team tear tell tempo ten tend tender tenor tension tent
term terrain test text textile than thank that thaw the theater them theme then therapy they thick thicker
thief thigh thin thing think third thirty this thorn those thought thread threat three threw thrive throne
throw thumb thunder thus tick ticket tide tidy tie tiger tight tile till timber time timer tin tiny tip tire
tired tissue title toad toast today toe toes toggle token tomato ton tone tongue tonic tonight too took tool
tooth top topic tops torch tore torn toss total touch tough tour tourist toward towel tower town toy toys
trace track trade trading traffic trail train trainer trait trap trapeze trash travel tray treasure treat
treaty tree trek trend trial tribe trick tried trim trio trip troop trouble trout truck true truly trump
trumpet trunk trust truth try tub tuba tube tuck tug tulip tuna tune tunnel turf turkey turn turtle tutor
twelve twenty twice twilight twin twist two type typical ugly ultra umbrella uncle under unicorn uniform union
unique unit unite unity unless until unusual update upgrade upon upper upset upward urban urge urn usage use
used useful useless user usual utility vacancy vaccine vain valid valley value valve van vanish vapor variety
various vase vast vat vault vehicle veil vein velvet vendor venture venue verb verdict verse version very vest
vet veteran victim victory video vie view vigor viking villa village vine viola violent violet viral virtual
virtue visa visible vision visit visitor vista visual vital vivid vocal voice void volume vote voter vow
voyager wade wag wage wagon waist wait wake walk wall walnut waltz wand wander want war ward warm warmth warn
wart wary was wash wasp waste watch water wave wavy wax way weak wealth weapon wear weary weave web wed
wedding wedge weed week weekend weekly weigh weight weird welcome well went were west western wet whale what
wheat wheel when where which while whirl whisper white who whole whom whose why wide widen widow width wife
wig wild wildlife will willing wilt win wind window windy wine wing wink winter wipe wire wisdom wise wish wit
with witty wizard woe wok wolf woman women won wonder woo wood wooden wool word wore work worker workout world
worm worn worried worry worth wound woven wrap wrist write writer written wrong yacht yak yam yap yard yarn
yawn year yell yellow yes yet yew yield yoga yolk you young your youth zap zeal zebra zero zest zip zipper
zone zoo zoom
`;
  root.CW_WORDS_EN_EXCLUDE = `
`;
})(typeof window !== 'undefined' ? window : globalThis);
