/*
 * Color Words – Türkçe sözlük (özgün derleme, kamu malı ortak kelimeler).
 * Biçim: küçük harf, boşlukla ayrılmış. Yeni kelime eklemek için listeye yazmanız yeterli;
 * motor kelimeleri otomatik olarak büyük harfe (tr-TR) çevirir ve tekrarları atar.
 */
(function (root) {
  var WORDS = `
aba abi acı ada ağa ağı ahu akı alt ama ana ani ant ara arı ark arz asa ası aşı aşk ata ayı
bal bas baş bat bay bel ben bey bez bin bir biz boş boy boz bul buz can cam cep cin çam çan
çay çek çil çit çok dağ dal dam dar dev dil diş diz don dua dut ela erk fal fan fil fiş gaz gel
gem gen gez göl göz güç gül gün hal han hap has hat hav hep her his hız ilk ile iri iki iyi
ırk ısı kal kan kar kas kat kaz kek kel kem kep kes kil kim kin kir koç kol kor koy kök kör köy
kul kum kur kuş kut küp lal mal mat mor mum nal nar nem net not oba oda ora ova oya pak pas pay
pek pes pil pul ray rol sal san sap sat saz sek sel sen ser ses set sır sis siz sol son sos söz
sus süt şal şan şef şen şık şiş şok tak tam tan tar tas taş tat tay tek tel ten ter tez tok ton
top toz tuz tül tür ulu üst var yağ yan yar yas yaş yat yay yaz yel yem yen yer yol yön yük yün
yüz zar zil zor ret ser sin sim tin nal kır kıl kız kış kip lan sar sek tik kat lir lira ilt
ört art ark erk tok yık yık sil iyi ani ayla ılık

abla acil adam adet akıl alan alet alım alın anne arka asil aslan atak atlas ayak ayna ayran
baba bacak badem bahar bakır balık balon banka bardak barış başak bayrak bebek beden bekle
belki benek beyaz biber bilet bilgi bina birlik bitki boncuk boya boyun bölüm börek bulut
burun buzul cadde cami canlı ceket ceviz cuma çadır çakıl çanta çatal çatı çay çember çiçek
çile çilek çizgi çocuk çorba çorap dalga damla dans davul defne defter deniz derin dere ders
devam dikiş dilek direk doğa dolap dolu dost döner dönem dünya düğme düğün ekin ekmek elma
emek enerji erik eski etek evet evren fare fener fidan fikir fincan fındık fırın fırça gazete
gece gemi genç gerek gergedan gezi gitar göbek gök gölge gömlek güneş güzel hafta hala halı
hamak hamur harf harita hava havuç hayal hayat hazine hece hedef hediye hızlı hikaye hurma
ılgın ışık ılık ırmak ince inci inek insan irmik isim iskele kabak kader kadın kafes kağıt
kahve kalem kalp kamp kanat kapı karar kardeş karga karın kartal kaşık kavun kaya kayak kayık
kazan kedi kelime kemer kemik kenar kepçe kerevit kese kestane keçi kılıç kırmızı kiraz kitap
koala kova koyun kömür köpek köprü kral kulak kule kumru kupa kurabiye kuzu kuyu küre lale
lamba leke lezzet liman limon lokum mahalle makas mama mangal manav mantar marul masa masal
matem melek melodi meltem merak mercan mersin meyve mısır mide mimar misafir mektup mevsim
nane neşe nehir nergis nine nokta numara oduncu okul okyanus olta orman otel oyun oyuncak
ölçek ördek örnek örtü ötmek ödül öğle öykü özel pamuk pasta patika patates pazar pekmez
pencere perde peri pınar pide pilot pirinç pişmek portakal posta pötikare radyo raket renk
resim rüzgar saat sabah sabun saksı salata salça sandık sanat sandal saray sarı sarmaşık
satır sayfa sebze sedir sehpa selam sepet seren serin sevgi sevinç sıcak sihir simit sincap
sınav sinema sirke soba sofra sokak somun sonbahar sorun soru sözcük su su sucuk sulu sungur
şapka şarkı şehir şeker şelale şemsiye şimşek şeftali şerit tabak tabela tahta takvim tarla
tatil tatlı tavan tavuk taze tekne tekir telefon temiz tencere tepe terazi tilki tirşe toprak
torba tren tuğla turna turta tuzluk tülbent üzüm vapur vazo yaban yağmur yakut yaprak yarış
yastık yatak yavru yayla yazı yelek yelken yemek yemiş yengeç yeşil yıldız yılan yokuş yolcu
yonca yorgan yosun yumurta yumak yunus yüzük zambak zeytin zil zümrüt zarf zebra zeka zemin

ada adak adım ağaç ağır akın akış alay alıç alkış ant anı ara arsa aşık atkı avlu ayar aydın
ayva azık bağ bağış bakla balta bant baraj bark basit başlık batı bayır bayram bek bekçi
beri bez bıçak bilye bindi biraz bitik boru bostan boşluk bucak buğday buhar bulgur buse
büyük ceylan cilt civciv çalı çam çan çark çarşı çatı çeşme çıra çini çivi çoban dadı dalak
dama damat dana dede deli denk deri deve dilim dinç dinî doğu dolma dolu domates dona dünya
düz ekim ekip elek elçi emin erken esin esir eşek eşik etli ezgi ezme fasıl fayton fener fes
fıçı fidan fiil firkete fiyat gaga gala ganimet gar garip gelin gemi gezi gidon gine giysi
gizem göçmen gönül gözlük gümüş güneş gürgen hacı halat halka hamal hamsi hane hangar hasat
hasır hazır heves hindi hisar horoz hurma iğne ikna ilaç ilan ilgi ilik imza inat inşa ipek
ipucu ısırgan ıspanak izci kafa kale kalın kamış kanal kanepe kantar kapak kapan karton
kasa kasım katar kavak kavga kayın kaymak keman kepenk kese kesik kırık kısa kilim kilit
kira kireç kivi koca kokteyl konak konser kontrol korsan koşu kova köpük köşe kumru kurt
kutu kuyruk kümes küpe küre lahana lider likör lise lokanta loş maden mağara makine maksat
manda manat mart masum maya mekan menekşe meşe metin mezar mimik minder misket mola motor
muz nadir nakış namus nefes nesil nişan oran orak ordu orta otlak oya oyma ölçü öncü önlük
örgü pabuç palet pancar papatya para parça park parmak pasaj paten pazı pelin perşembe pesto
petek pide pilav pire posta pul puma rakam ramazan rasat reçel rehber renkli resim rota
ruh sahil sahne saka saklı sakız salı salon sami sarnıç satranç sayı seda sekiz semer senet
sergi serçe servi sıra sırma silgi sinek sise sitem siyah sofa sokak soğan sonra sopa söğüt
söylem sulu sure suskun süngü süs süzgeç şakak şahin şamdan şarap şato şaşkın şeref şerbet
şiir şimdi şirin şükür tahin takım takı talip tane tarak tarih tasa tava tavla tavus tebrik
tekel tekir telaş tema tepsi teras terim terzi testi tıpkı tilki tiyatro tohum tokat toka
topaç topuk tören tuval tuzak tülbent tümsek turna tutam tüy uçak uçurtma ufuk ulak umut
usta uyku uzay uzun ülke ünlü üzgün vadi vakit valiz varil vatan veda vergi vezir yağız
yakın yalı yama yamaç yankı yapı yarım yasa yaşam yatı yavaş yazın yedi yeni yetenek yiğit
yokuş yorum yöre yudum yufka yular yuva yüce zaman zengin zerre zevk zirve zurna

akrep alev alim altın anahtar anlam arena arı arma asker aşçı atlet ayın aynı aziz balina
bando baret baston batak bayan benzin beşik beton bıyık bilim birey bolluk bomba bonus
boğa bucak bulmaca çalgı çamur çarşaf çene çerez çeyrek çınar çiftçi çizme dakika dalgıç
damak dergi destan dikkat diploma doktor dolar dörtlü düdük ebru egzersiz ekran elmas
emlak erkek esnaf etkinlik fasulye filo fiyonk fotoğraf galeri gazete gelincik geyik gidiş
gitar gökyüzü gölet gözcü gurur halay hamam harika hasta hatıra hayvan hekim heykel ibrik
ikiz ilkbahar irade istasyon kaktüs kalkan kaplan karınca kasa kaynak kazak kelebek kervan
kılavuz kısrak kirpi kolye kumbara kumsal kuşak lacivert lastik leylek lokma macera mandal
mandalina martı mavi mendil merdiven mermer meydan mihrap mozaik mürekkep nakış nilüfer
okur orkide otobüs ozan örümcek pala papağan pazen pembe pergel pervane petrol piknik pinpon
piyano plaj radar reçete rengin saklambaç salıncak sandalye sarmal sedef selvi serap sırt
soğuk sonsuz sözlük sulak şato şeftali şekil tahıl takla tambur tarçın taslak tebeşir
tespih tırtıl tilki tokmak tomurcuk topaç tramvay trompet tutku turuncu tuzla uçurum umut
uzman üniforma vanilya vişne yalçın yaratık yatak yazıt yengeç yolculuk yorgan yumru

al at ek el et ev iç is it ok on ot öç ön sa su üç ün
ala ali ara asi ata eti ezan izi ola ona ora öte sıla tane taze anla atla ekle ısla kesi
ilet inat irs kaş kaya kara kart kasa kast kate kati kent kere kesat kral kurs lake leke
nara nane nisan nota rast rest reis sami sara sarı sart sıra sine site son tara tari tasa
tarak taraf tarla tatar tekne teke tela tenis terk tesir tren tuna tura tutar arsa arkası
arka artı asal asla astar ater atık atlar atma ayak eksi ekşi elek elle emek ense erik esas
esen eski etek eter evre ılık ırak ırak ilik inek inse kale kalp kamu kana kanat kani kapı
karı kase kasık kasım katı kaya kazı kele keski kılık kına kira kişi koca koku kolay kona
konu kora koro kum kumar kurt kuru kusur lisan lime lira mana mart masa mera mesai mesken
meta metre mira nakit nakil nesil nimet onay orak oran orta ölü örs öte rakı ramak rasat
reng renk saat sabır sade saka sakin salı salık sanat sanık santim sarık sayı seci sekme
sele seme semt sene sere serin seri sert sesli seyir sıcak sınır sinir sire sitar sitem
soka sola soran sorun sual sulu suna süre süt şair şaka şark şart şeker şema şerit şifa
şiir şiş taka takas takı takım taki talan talk tamir tane tanı tarih tarz taşı tatlı tavır
tayin tekin tekir tema temel temiz tenor tepe terim terlik tesir teyze tırak tiril tokat
tona tonik tora tören tura turan tuş tutam tuza ulak ulama ulus uslu usul ütü vali vana vasat
vatan vekil vira yakı yalan yama yanak yanık yara yarı yaşlı yatak yayla yazar yedek yeis
yeme yemin yenik yeter yetim yıkık yine yokuş yolcu yorgun yular yulaf zarar zarf zayıf
zeki zekat zil

alkış alakart anket ankara antre arena ateş atkı atlet aylık aynı ayrıca iskele istek
kalite kartal kasket kestane keten kırat kırta lastik leziz meslek metal mesaj neşter
nektar ortak oturak raket saklı salkım salta sanal seksen selam sekreter seren sergi
sinsi sirke siren sıkı sıkıntı sıtma silah sitare soslu takat taktik talas tasarı taslak
tekrar telsiz tenekesi terlik terso tesis tetik tiksi tilki tirat tonla torba trak trans
akarsu akşam alacak aralık arıza asılı aslan atası atık atkı ayrık

kale kalem kalemi kaleme kaler laleli elalem malak anlak nakle teslim selamet melis
saten sanat sanatçı tasa satı satın satıcı astı anısı asit asır asıl aşı aşır
erkan erkek kasten taksi taksit takas sakat saka sekte teksas kestik
kalın kalıp kalk kalkan kalkın kalıntı kanal kalan kalma kamera kanat kantin
dere deri derin dere dert dertli derse dersi ders dekan deste dest destan deri
mera merak merkez meslek mesele mesela meta metan metin mektep melek
liman lise list liste lisan litre limit lima lime
neden nede nesne nesil nemli neşe neşeli
ilim ilmek ilke ilmi ilan ilaç ilan
tren trek tren tırnak tırmık
kartal karton karanlık karamel karabiber
deniz denet denek denk
sarmal sarma sarım sarnıç sarkıt sarraf
yemek yemiş yemin yengeç yenge yenik
sıra sırt sırma sırık sınır
tane taner tanker tank tanık tanım
emlak emek emin emir emre
edat edep eden eder ekmek ekin ekim ekip ekli eksik
akrep akraba akar akarsu akıl akım akın akıntı akis akit
nişan nişasta nikah nine nimet nisan
anket anlık anlam anılar anıt anten ant antik
ırmak ısırık ılıca
balık bakır bakış bakkal bakla
kedi kader kadeh kadın kadim kadife
mantı mantar mantık manto manav
ninni nisan
yaprak yapı yapım yarış yarık
`;
  // Derleme sırasında elenen (çekimli, özel isim veya şüpheli) girdiler.
  var EXCLUDE = `
ankara rengin ayla ısla atla anla bekle ekle kalk kalkın sara sere tonla taka tela vira velet zamk kesat kasten lake lime nara ora sine sitare salık sulak kırat ulama tasarı yular kesi gine yeme atası 
ilt lan kırta tırak tiril sire seci seme soka suna tona tora tuza yeis reng kele inse ırak
atlar ater ali izi eti ona ola kana kani kati kate lima list nede trek taner anılar melis
nakle teksas astı anısı kestik kaleme kalemi derse dersi sami turan tuna arkası sola soran
bindi sise dona ayın tiksi trak trans terso tenekesi salta dinî
eden eder emre kaler tari taki kona kalan erkan
dügme battal oltası samuru yazılmak
`;

  var WORDS2 = `
almak atmak açmak akmak aramak asmak bakmak basmak batmak bilmek binmek bitmek boğmak bozmak
bölmek bulmak burmak bükmek çalmak çekmek çizmek çökmek çıkmak dalmak demek dermek deşmek dikmek
dilemek dinmek dizmek doğmak dokmak dolmak doymak dönmek dövmek duymak düşmek düzmek elemek emmek
esmek etmek geçmek gelmek germek gezmek girmek gitmek görmek gülmek inmek içmek itmek izlemek
kalmak kapmak kaçmak kazmak kesmek kırmak kısmak koşmak kovmak koymak kurmak kusmak küsmek kaymak
konmak okumak olmak ölmek örmek ötmek öpmek pişmek salmak sarmak saymak seçmek sevmek sıkmak
sızmak sürmek silmek sökmek sönmek soymak sormak tutmak takmak taşmak tatmak uçmak ulaşmak uymak
uyumak uzamak vermek vurmak yakmak yanmak yapmak yatmak yazmak yenmek yıkmak yitmek yolmak yüzmek
yürümek okşamak kokmak kızmak bağırmak ağlamak anlamak atlamak aldatmak alıştırmak arıtmak besleme bakınmak bırakmak
bilemek boyamak bölüşmek buluşmak çağırmak çalışmak çarpmak çevirmek çözmek dağıtmak dayamak dinlemek doldurmak dokunmak
duraklamak düşünmek eğlenmek giymek gülümsemek hazırlamak hatırlamak iyileşmek kaybetmek kazanmak kıskanmak konuşmak korumak koklamak
koşturmak kullanmak oynamak öğrenmek öğretmek paylaşmak sallamak saklamak sarılmak savurmak sınamak soğumak sulamak sürüklemek
tırmanmak tutuşmak uyanmak üflemek yaşamak yazılmak yıkamak yoğurmak yürütmek zıplamak kaplan geyik tavşan kurbağa
timsah zürafa penguen flamingo kanguru papağan leylek serçe güvercin kumru karga baykuş şahin doğan
kartal yunus balina ahtapot denizatı karides midye yengeç solucan örümcek karınca sinek böcek kelebek
çekirge hamsi sardalya palamut levrek çipura alabalık köpek kuzu koyun keçi boğa öküz manda
tavuk horoz hindi ördek civciv eşek katır deve sansar kirpi fare sıçan yarasa sincap
maymun goril panda aslan zebra gergedan antilop kuğu turna sığırcık bülbül kanarya guguk karabatak
martı pelikan akbaba atmaca şahin tilki çakal porsuk gelincik su samuru kunduz ekmek peynir
zeytin domates biber patlıcan kabak havuç soğan sarımsak marul ıspanak pırasa mercimek nohut fasulye
bulgur pirinç makarna çorba köfte kebap pide börek gözleme mantı baklava lokum helva dondurma
şeker çikolata bisküvi kurabiye pasta reçel tereyağı yoğurt ayran kaymak yumurta tarçın kimyon nane
maydanoz dereotu elma armut kayısı şeftali kiraz vişne üzüm incir portakal mandalina limon çilek
karpuz kavun erik ayva hurma badem fındık ceviz fıstık kestane enginar kereviz turp pancar
bamya semizotu mısır patates tahin pekmez salça turşu zeytinyağı sirke baharat kirpik burun ağız
dudak boyun omuz dirsek bilek parmak tırnak göğüs karın kalça bacak topuk deri kemik
akciğer böbrek beyin damar yanak çene alın bilek sırt kürek gırtlak dağ tepe vadi
ova orman deniz göl nehir ırmak dere pınar şelale mağara kıyı sahil kumsal kaya
toprak çamur çöl buzul volkan gökyüzü bulut yağmur fırtına şimşek yıldırım kırağı güneş yıldız
gezegen uydu evren çiçek papatya menekşe sümbül karanfil zambak orkide nergis yasemin ağaç çınar
meşe kavak söğüt fidan yaprak tohum çimen yonca masa sandalye koltuk kanepe yastık yorgan
battaniye halı kilim perde pencere anahtar duvar tavan zemin merdiven balkon mutfak banyo salon
bahçe garaj apartman dolap çekmece raf ayna lamba avize soba ocak fırın tencere tava
kaşık çatal bıçak tabak bardak fincan sürahi demlik semaver tepsi sepet sandık çanta valiz
cüzdan şemsiye takvim defter kalem silgi cetvel makas kitap gazete dergi mektup tablo heykel
kalemlik kitaplık çiçeklik tuzluk şekerlik havlu sabun tarak fırça battal elbise gömlek pantolon etek
ceket palto kazak hırka yelek şapka eldiven çorap terlik çizme kemer kravat gözlük pijama
mayo atlet doktor hemşire öğretmen öğrenci mühendis mimar avukat polis asker pilot şoför aşçı
berber terzi marangoz demirci balıkçı çiftçi çoban bakkal manav kasap fırıncı ressam yazar oyuncu
sporcu futbolcu çiçekçi gazeteci kitapçı şekerci sütçü simitçi tamirci hakim bekçi okul hastane eczane
market çarşı pazar sinema tiyatro müze stadyum istasyon liman köprü tünel cadde sokak meydan
şehir kasaba mahalle başkent otel lokanta kafe güzel çirkin büyük küçük uzun kısa geniş
ince kalın hafif ağır hızlı yavaş sıcak soğuk serin taze eski yeni genç yaşlı
temiz kirli tatlı tuzlu ekşi sert yumuşak güçlü zayıf zengin fakir mutlu üzgün kızgın
neşeli cesur korkak akıllı dürüst nazik sakin sessiz gürültü renkli parlak koyu boş düz
eğri yuvarlak üçgen dikdörtgen bir iki üç dört beş altı yedi sekiz dokuz yirmi
otuz kırk elli altmış yetmiş seksen doksan yüz bin dakika saniye sabah öğle akşam
gece bugün yarın salı çarşamba perşembe mevsim ilkbahar yaz sonbahar kış ocak şubat mart
nisan mayıs haziran temmuz ağustos eylül ekim kasım aralık kırmızı mavi sarı yeşil turuncu
pembe beyaz siyah kahve lacivert turkuaz bordo altın gümüş gitar piyano keman flüt davul
trompet kanun şarkı türkü melodi ritim nota orkestra konser futbol voleybol tenis yüzme güreş
bisiklet kayak paten telefon klavye ekran kamera radyo internet mesaj program harf kelime bulmaca
araba otobüs vapur gemi uçak motor kamyon taksi tramvay metro kayık sandal tekne yelkenli
araç durak bilet adalet adım aile akşam alışveriş anlam arkadaş armağan aşk ayna bayram
bahçe başarı bilgi bilim bölge cesaret cevap çaba çözüm değer dünya düzen emek erdem
esenlik gelecek gelenek gerçek görev gurur hayal hazine hikaye huzur ilgi kader karar komşu
kuvvet kültür macera merak mutluluk nezaket nimet özgürlük sabır sağlık saygı sevgi sevinç sorun
sürpriz tarih umut vatan yardım yarışma yetenek yolculuk zafer zaman başlık bayrak çember çerçeve
çıkış dalga damla davet durum ekip eşya fikir giriş görüş gölge görsel hafıza harita
hareket hedef hizmet ihtiyaç imkan işaret kampanya kapsam karşılık kutlama lokma mesafe misafir model
nokta olay oran örgü paket parça pazarlık seçenek seyahat sınır sistem takım temel tören
turnuva uyarı yayın yazı yorum aktör arsa asansör balkon bavul bilezik boncuk broş çakmak
çatı çıngırak dikiş dügme düğme fener fıçı gaga halat harç ibrik iğne kadeh kalıp
kamyon kepçe kilit kova kürek mıknatıs mızrak mikrofon oltası pamuk perçin pusula raket saksı
sandalet sopa şişe tabure tokmak tuğla ütü vida yelpaze zımba zincir ağabey abla amca
dayı hala teyze dede nine torun yeğen bebek çocuk kardeş gelin damat arkadaş komşu
`;
  var WORDS3 = `
aday adet akım alay alev algı anıt arma atak atış avcı avuç ayar aydın
ayrı azim azık acemi acele adalet ağır ağıt ahlak ahşap akıcı aktif alçak alıcı
alkol altar antik apaçık arayış arzu asker atmaca ayıp aylak bahis bakım baldır berrak
beyin biçim bölük boyut buyruk büyü büro bütün cadı cesur ceza cömert cumhur cevher
cilt cins ciddi cihaz cımbız çağ çaba çağrı çakıl çalı çamaşır çanak çapa çarşaf
çekiç çelik çeşit çeşme çete çift çıban çıkın çırak çivi çizgi çöp çukur çürük
daire dalga damar dantel dayak depo derece dernek destan devir devlet diğer dikkat dilim
dişli diyar doku domuz doruk dostluk doğal durak duygu düğüm düğün düzen ecza efsane
eğik eğitim ekin eklem elçi elek emir endişe enine erkek erzak esas eser esir
eşik eşit evrak ezber fabrika fakat fanus fark fayda felek figür film final fiyat
forma fotoğraf fren fırsat fıskiye galip garip gedik gelir gençlik genel gerek geri gezi
gıda gidiş gizem gizli giyim göçmen gönül görüntü güç güney güvenlik gürültü haber hakem
halka hamur hane harç hasat hasta hatıra hayat hayvan hazır hedef hekim hesap heyecan
hırs hızar hisse hoca hoşgörü hudut hukuk hurda huzur ısıtıcı ıslak ibre ihale ikili
iklim ilaç ilişki imza inanç intiba iplik ipek irade isyan işçi iyilik izin kabin
kabul kadro kafa kalıp kalite kalkan kamu kanal kanun kapak karşı kasa kavga kazan
kazı kenar kepenk kesim kıdem kılıç kıyı kırık kısım kıyafet kibar kimlik kiracı kireç
klasik kolay kolon komik konak koru kural kurum kuşak kutu kuyu küçük kürek kütük
lahana lamba lazım lenf lezzet lider liste lüks maaş madde mağaza mahkeme makine mandal
marka meşgul mevcut milli misal mizah moda mucize muhtar müdür mükemmel mümkün müzik nabız
nakit namus nasıl nefes nesil nesne nöbet nüfus obje odak olay onur ordu oturum
ödev öğün ölçü ömür önce öncü önder önlem örnek özel özet özgür pabuç panik
panel para parti pasaport pehlivan piyasa plan prens pürüz rakam rakip randevu rapor reçete
rehber resmi rica rüya sabit sahip sahne saman sanayi santral saray savaş sayfa sebep
seçim sefer semt seri servis sıfır sınav sınıf sigara sivri siyasi sonuç soygun sulak
sunum sürat süre süreç süslü şans şart şehit şiir şirket şüphe taban tahta talep
tamam tarım tasarım tavır tayfa tehlike tema tepe terim tesis teşekkür tıp toplum toplu
tuhaf turist tutum tüccar tüfek tüketim türlü ufuk ulaşım ulus unsur usta usul uyum
uzman ücret ümit ünlü ürün üslup üye vagon vakit vali vasıta vazife veda vergi
veri vitrin vücut yaban yakın yalan yamaç yangın yapı yarar yasa yatak yayın yazıcı
yedek yenilik yetki yoğun yöntem yurt yüzey zarar zehir zihin ziyaret zorunlu jilet jeton
jüri jandarma jeolog kabuk kadife kafes kakao kalabalık kalender kamara kanatlı kanguru karakol karamel
karanlık karpuz kasırga katlı kavşak kayısı kaynar kelepçe kervan kesinti kıvılcım kırlangıç kısıtlı kolonya
koridor korkuluk kovan kozalak küpe kurbağa kurbağalık kuşkonmaz laboratuvar lağım lavabo limonata lokum lüfer
magazin makarna makyaj mantar maraton marifet masaj maskot matbaa mazot meclis melodi menteşe mercek
merdane mermer mesken meteor metrobüs mikroskop minare minder mısır mühür müsabaka mutfak mürekkep nakliyat
nargile nöbetçi nişan nişasta nükte oksijen olasılık oluk omurga organ orman otlak oturak otopark
oyuncak ödünç özenti paçavra paha palamut pamuk panjur papyon paravan pasaj patika pehlivan pelerin
pense perde peşin pırlanta pilav piknik pinti pirinç pişman plaka podyum polen portre pratik
prova püskül raf rahat rehin reklam ressam rezerv rıhtım rötar ruhsat rutubet saban sabır
sakal sakız salgın salıncak samimi sandviç sapan saplı sargı sarkık seccade sedef sedir sekme
selvi semaver sepet serçe sergi serin sevda seyrek sıklet sıra sığınak sığır sırdaş sinema
sirk siper sivilce soğan soygun sporcu stüdyo sucuk sunta susam süpürge sürgün sütlü şafak
şahıs şaka şantiye şarküteri şato şekil şelale şerbet şeref şimşek şoför şölen tabela tabir
tablet tabut tahıl takvim talih tamlama tarak tarçın tarife tarz taşıt tavla tebrik tekerlek
tekne telaş telgraf tencere teneke tepsi terazi tercih terlik tesbih teyp tezgah tırnak tiyatro
tohum tokmak tomruk tombul topaç toprak torun tören tuğla tulum tuzak tütün uçurtma uçurum
ulak uykusuz uzak uzay ünvan üzengi üzücü vadi vaha vaiz vakıf varlık vazo vefa
velet viraj vurgun yağmur yağlı yaka yalı yankı yanıt yapraklı yarasa yasak yastık yatılı
yavru yaylı yazar yelken yenge yetim yığın yıkım yiğit yoğurt yorgan yosun yumruk yuvarlak
yuva yük yünlü zabıta zafer zahmet zamk zanaat zarf zarif zeka zekat zencefil zeytin
zimmet zindan ziraat zurna
`;
  var WORDS4 = `
ablalar aceleler adamlar adetler afet afetler ağaçlar ağıl ağıllar ağızlar ağrı ağrılar
ahır ahırlar ahlaklar ahşaplar akıllar akımlar aksam aksamlar akşamlar alanlar alaylar
alem alemler aletler algılar alınlar alkışlar altınlar alıçlar amaç amaçlar amcalar anılar
anıtlar anlamlar anneler ansızın apan apanlar arabalar arkalar arpa arpalar arsalar
artılar askerler aslanlar aşçılar aşama aşamalar atlaslar atletler avuçlar ayaklar ayaz
ayazlar ayet ayetler aynalar ayrıt ayrıtlar azimler babalar bacaklar bademler bağlar
bağışlar baharlar bahçeler bakırlar balıklar baltalar bandaj bankalar barışlar basın
basınlar baskı baskılar bataklar bebekler bedenler bekçiler bekir bekirler bela belalar
belge belgeler bence benceler beyazlar biberler bicak bicaklar biletler bilgiler bilimler
binalar bireyler bitkiler bodur bodurlar bombalar borç borçlar borular boyalar bozuk
bozuklar böcekler bölgeler bölümler börekler bugünler bulutlar burunlar buzullar büyükler
bürolar caddeler camiler camii camiiler canlar cesurlar ceketler cevaplar cevizler
cihazlar cümle cümleler çadırlar çabalar çağlar çakıllar çalgılar çantalar çapalar
çarşılar çatallar çatılar çekiçler çekim çekimler çelikler çeneler çeşitler çiçekler
çiftler çiftlik çilekler çiviler çizgiler çizmeler çocuklar çorbalar çömlek çuval çuvallar
çürükler dalgalar dalış dalışlar damarlar damlalar dayılar değerler denizler dereler
derinler derviş devre devreler dikişler dilekler direkler divan divanlar doğalar doğru
doğrular dokuzlar dolaplar domuzlar dönemler dünyalar düğmeler düğünler düzenler edebiyat
ekmekler ekranlar elçiler elmalar emekler emlaklar emniyet engel engeller erikler erkekler
eserler eşekler eşyalar etekler evrenler ezgiler fakirler fareler fasıllar fenerler fide
fideler fidanlar fikirler fırınlar fırçalar fidye fidyeler fiyatlar form formlar gagalar
garajlar gazoz gazozlar geceler gelinler gelirler gemiler gençler gergin gezgin gıdalar
gitarlar gizemler göbekler göğüsler gölgeler gönüller görevler gözler gram gramlar
gururlar güneşler gümüşler güven güvenler güzeller gübre gübreler haftalar hakemler
halılar halkalar hamamlar hamurlar hastalar havlular hayallar hayatlar hazırlar hekimler
helvalar hesaplar hevesler hızlılar hilal hilallar hisseler hocalar hudutlar hukuklar
huzurlar hürriyet ılıklar ırmaklar ışıklar ısılar ızgara iade iadeler ibadet ibreler icat
icatlar iğneler ihaleler ikram ikramlar iklimler ilaçlar ilgiler iltifat imzalar inançlar
inekler insanlar ipekler iplikler iradeler isimler israf israflar istekler izinler
jetonlar jüriler kabuklar kaderler kafalar kağıtlar kahveler kalemler kalınlar kalplar
kanatlar kanunlar kapaklar kapılar kararlar kargalar kasımlar kasıklar kaşıklar kavgalar
kavunlar kayıklar kaza kazalar kazaklar kediler kemerler kenarlar keseler kıble kıbleler
kıyılar kilise kilitler kiralar kirpiler kitaplar kocalar komşular konaklar konular kopya
kopyalar korku korkular koyunlar kömürler köprüler köpekler köşeler köyler kubbe kubbeler
kulaklar kulübe kumlar kumaş kumaşlar kurak kuraklar kurumlar kutular kuşlar kuzey
kuzeyler küçükler küllük kümesler lambalar laleler levha levhalar limanlar limonlar
listeler lokmalar madenler makaslar malzeme manzara markalar masalar maske maskeler matkap
maviler mayıslar meme memeler meraklar merhaba mermi mermiler mesajlar meşale meşeler
meyveler mezarlar mısırlar mumlar müdürler müşteri müzeler nakitler nakışlar namaz
namazlar naneler nehirler nemler nesiller nesneler noktalar nöbetler ocaklar odun odunlar
okullar olaylar omuzlar onurlar ormanlar ortalar oyunlar ödevler ödüller öğleler ölçüler
önlükler örnekler örtüler özgürler paketler paltolar pamuklar paralar parçalar parklar
pastane pazarlar pazenler perdeler pideler pilavlar pınarlar plajlar polisler postalar
pulluk radyolar rakamlar rakılar raflar renkler resimler rüyalar sabahlar sabunlar saç
saçlar sahiller sahneler saksılar salonlar samanlar sanatlar saraylar sarılar savaşlar
saygılar sazlar sebzeler sedirler sehpalar selamlar semtler sepetler serçeler sergiler
sevgiler seyirler sirkeler sivriler sobalar sofralar sokaklar somunlar sorunlar soğanlar
sömürge sucuklar sulak sulaklar sultan sunumlar surat suratlar süreler sürü sürüler sütler
şairler şakalar şallar şapkalar şarkılar şehirler şekerler şiirler şişeler şoförler
tabaklar tablolar tahtalar talihler tamirler tanıklar taraklar tarihler tarlalar tasarı
tatiller tavanlar tavuklar tazeler tembel tepeler tepsiler terziler torbalar tuğlalar
turşular tuvalet tuzlar uçaklar ufuklar uğur uğurlar umutlar unutkan uykular uyumlar
uzaklar uzmanlar üçgenler ülkeler ümitler ünlüler ürünler üzümler vadiler vakitler
valizler vapurlar vatanlar vazolar vergiler vesika veli veliler vücutlar yabanlar yalanlar
yamalar yarışlar yataklar yavrular yaylılar yazarlar yelekler yemekler yemişler yeşiller
yıl yıllar yollar yolcular yurtlar yüzükler yüzler zaferler zamanlar zarflar zehirler
zeminler ziller zorlar zurnalar
`;
  var WORDS5 = `
akrepler alıcılar alkollar almanak amiral anason andaç andaçlar arasta armutlar arpacık
asma asmalar ateşler atkılar atlı atlılar avcılar avizeler ayçiçeği ayranlar bağırsak
baklalar balonlar bamyalar barut barutlar basamak bayanlar bekar bekarlar benekler
betonlar bıçaklar bilekler bilyeler birazlar bit bitler bölükler börtü börtüler bosna
bosnalar burç burçlar buruk buruklar butik butikler cadılar cebir cebirler cenaze cephe
cepheler cerrah cevat cevatlar cirit ciritler ciltler cüce cüceler çalışkan çamurlar
çanaklar çardak çavuş çavuşlar çengel çıbanlar çıkınlar çıta çıtalar çınarlar çıraklar çiğ
çiğler çökelek çömez çömezler çubuk çubuklar dalaklar damaklar damatlar dedikodu defneler
deliler demir demirler deprem derman dershane diken dikenler dinçler dizi diziler dolmuş
dolular domino donanma dostlar dudaklar duman dumanlar duraklar duvarlar duygular düdükler
dükkan ebe ebeler ebrular efe efeler ejderha ekinler eklemler elbet elbetler emzik
emzikler epey epeyler erzaklar esans esanslar esnaflar esrar esrarlar eşarp eşarplar
fakülte fanuslar felaket fermuar fesleğen filler fitil fitiller flütler fosil fosiller
frenler fukara gazel gazeller gelişme gemici gerdan gergef geyikler gıcırtı gişe gişeler
gofret göletler gondol gönüllü grup gruplar gurbet hacim hacimler hakikat halatlar
halaylar hançer harçlar hardal harman hasatlar havuçlar havuz havuzlar hayır hayırlar
hendek hindiler hırkalar hortum hurmalar ıhlamur ılgınlar ıssız ıssızlar içki içkiler iğde
iğdeler ihtiyar ikindi ikizler imam imamlar imkanlar inciler ibrikler incirler ipler
ipucular irmikler ispir ispirler iştah iştahlar itiraf izciler jiletler kabine kafesler
kahraman kalas kalaslar kalyon kamçı kamçılar kamplar kanallar kangal kapari kasnak kaşar
kaşarlar katılar kavaklar kebaplar kehribar kekik kekikler kenevir kerpiç ketenler kıvrım
kızak kızaklar kiviler koalalar kolaylar kolyeler konsol kordon köfteler köhne köhneler
körük körükler kötü kötüler kurdele kurular kurşun kuşaklar kuyumcu lavanta leblebi lif
lifler lime limeler liralar lodos lodoslar lokumlar macun macunlar makbul martlar marullar
matemler mazotlar mezat mezatlar mideler mikrop mirket mobilya molekül motorlar mukavva
musluk muzlar mühürler nallar nalbant narlar nazar nazarlar nefesler neşeler nişanlar
nohutlar nüfuslar obur oburlar odalar okuma okumalar oltalar onbaşı oraklar ortaklar otlar
oteller ovalar öğrenme ökçe ökçeler ömürler önderler örgüler öyküler özlem özlemler
palaska pandik paraşüt parfüm parke parkeler parola pastalar pazılar pelit pelitler perçem
peruk peruklar peşinler petekler platin poşet poşetler prensler priz prizler puan puanlar
pudra pudralar pullu pullular pürüzler radyatör rahatlar raylar reçeller rende rendeler
rezil reziller rotalar roman romanlar ruj rujlar sabırlar sac saclar safran sağanak
sahipler sakalar samanlık sebil sebiller sedefler seher seherler selviler senfoni serinler
sıcaklar sıralar sırtlar sığırlar sirenler sisler siyahlar sobaş sobaşlar somon somonlar
sonuçlar sorular spor sporlar sunak sunaklar süsler şafaklar şahinler şahit şahitler
şaraplar şenlik şifalar şimdiler şirinler şölenler taç taçlar tahinler takılar talaş
talaşlar tamamlar tanımlar tanrı tanrılar tarzlar taşlar tavalar tavlalar taylar tayfalar
tefeci teker tekerler tekneler tekinler teklif teller temalar tenisler tepki tepkiler
termos teyzeler tilkiler tirbuşon tonoz tonozlar toplar törenler traş traşlar trafik
turnalar turplar tutkular tüfekler tüneller türküler uluslar umumi umumiler unlar unvan
unvanlar uskumru ustalar utanç utançlar uyarılar uzaylar üvey üveyler üzgünler vaaz
vaazlar vakıflar valide vals valslar vanalar varyant vekiller velet veletler vezirler
vidalar vinç vinçler vişneler vites vitesler vize vizeler yakıt yakıtlar yaldız yalılar
yamaçlar yanaklar yankılar yapılar yaralar yarımlar yasalar yatlar yaygı yaygılar yazılar
yemler yengeler yerli yerliler yıkama yığınlar yoncalar yosunlar yüksük yürek yürekler
yünler zararlar zeybek zihinler zirveler zorluk zuhur zuhurlar ayırmak ayrılmak beklemek
büyümek çürümek damlamak değmek devirmek donmak durmak evlenmek güvenmek inanmak istemek
kalkmak kapamak kaplamak komak korkmak oturmak ormak ölçmek özlemek pişirmek parlamak
patlamak satmak sayılmak serpmek sığmak sürünmek süslemek taşımak tanımak toplamak unutmak
yaratmak yırtmak
`;
  root.CW_WORDS_TR = WORDS + ' ' + WORDS2 + ' ' + WORDS3 + ' ' + WORDS4 + ' ' + WORDS5;
  root.CW_WORDS_TR_EXCLUDE = EXCLUDE;
})(typeof window !== 'undefined' ? window : globalThis);
